# P1 — Lidar Terrain Acquisition and High-Fidelity Terrain Map

**Repository:** `ljs294/v2-ski-area-design-challenge`  
**Package:** split revision 2.0, 21 September 2026  
**Status:** implementation plan; implementation, packaged-player tests, and independent reviews are **NOT EXECUTED** by this restructuring task.

> **Outcome:** Replace the fixed-resolution elevation-export bottleneck with verified lidar-derived bare-earth terrain, and preserve that detail in the editable, offline Unreal terrain map.

This is one of three standalone terrain-builder companion plans. **P1 = lidar terrain; P2 = cover accuracy and smoothness; P3 = procedural flora.** These IDs name workstreams in this package; they do not renumber the existing Unreal replacement plan's phases. References to a parent phase are explicitly prefixed **Parent**. The earlier TV0–TV6 environment backlog is redistributed here, not a second active backlog.

Each plan contains its own scope, contracts, tasks, acceptance checks, questions, source register, and independent-review instructions. It can be handed to Codex without the former combined master plan. Inspect the actual checkout and active parent plan before implementation; a historical reference is not proof of current local state.

## 1. Scope and independent completion

**P1 owns ground elevation and its runtime representation.** “Use lidar” means prefer an actual lidar-derived digital terrain model (bare-earth DEM/DTM). It does not require downloading or rendering a raw point cloud for every mountain. Use an existing suitable bare-earth product where available; a raw-point-cloud-to-ground pipeline is a bounded fallback only when justified. Do not mistake vegetation tops or building roofs for the ground. [D1–D3]

Included: source discovery, tiled acquisition, source-quality labeling, coordinate/datum normalization, ground-height package, terrain sampling, tiled mesh detail, seams/normals, grade updates, offline persistence, and performance evidence. A simple cooked test material is sufficient to judge terrain shape and shading in P1.

Excluded from P1: canopy-height derivation, land-cover classification, vegetation-community inference, smooth forest/grass/rock boundary masks, tree/grass/rock asset creation, PCG, and plant placement. **Those belong to P2 or P3.** P1 may retain reusable lidar source identifiers/cache references, but does not need P2's canopy processing to finish.

**Standalone finish:** a mountain acquired after packaging loads with verified ground-source detail, renders smoothly at the agreed camera distance, supports grading and offline save/reopen, and meets a measured terrain-only resource envelope. P1 does not wait for accurate cover or any vegetation models. Later combined regression is tracked in P3, not disguised as a P1 prerequisite.

### Execution authority and existing product decisions

This handoff authorizes planning, not game implementation, installs, purchases, publication, staging, or commits. The owner authorizes bounded implementation sections and alone stages/commits. Preserve dirty and untracked work. Read actual root/scoped `AGENTS.md` and `CLAUDE.md`; propose any conflicts with the native replacement direction rather than silently changing guidance.

Preserve the Windows Unreal replacement, same-window mountain preparation, offline gameplay after preparation, manual saves, committed grading, explicit Save/Load Blueprint, working-plan versus built-state separation, overlays/dot guests, and Crystal Mountain WA as the reference. The old laptop is an optional compatibility probe, not the adopted minimum specification. Do not reopen these decisions or introduce a second gameplay application. Retrieve actual approved map-size limits from the active parent plan; a small development crop is not a new product-size limit. [H1, H2]

No first-person game, physical snow system, ecological growth, multiplayer, cloud service, paid plugin, or engine fork is silently commissioned.

## 2. Evidence and the problem being fixed

The previous repository review used `main` at `1cca4e0808b96fa0fc43d48c4289a118b29b30ec`. That snapshot's guidance still described React/MapLibre/Electron; local native work was not established. Use it as a behavioral reference, not as the assumed current codebase. [R0]

`src/elevation.ts` requested one resampled USGS export, normally capped at **2,000 samples per side**, with server-failure fallback that could shrink it to 1,000 or 500. It preserved returned bounds but did not make requested output density proof of native source detail. An approximately 8 km side at 2,000 samples is roughly 4 m spacing; at 500 it is roughly 16 m. This is a possible detail-loss mechanism, not a reproduction of a particular user's map. [R1]

The new design must separate **native source spacing, delivered sample spacing, and documented accuracy**. Resampling a coarse source onto a 1 m grid does not recover missing terrain measurements. Mesh subdivision alone is not the fix.

## 3. Recommended terrain architecture

### 3.1 Source selection and failure policy

Prefer verified **USGS 3DEP lidar-derived 1 m bare-earth products**, including the seamless 1 m product where appropriate. Check the exact footprint, product/version, acquisition date, quality, and vertical datum. Washington DNR is an additional regional discovery route for Crystal; exact coverage and terms remain an implementation check. Do not promise complete 1 m coverage for every selectable mountain. [D1–D3]

Use bounded tiled downloads or source-window reads where the provider supports them, instead of simply enlarging the existing fragile monolithic request. Respect access terms, constrain concurrency, retry individual failed tiles, expose actual byte progress, and cancel cleanly. No new hosted service is assumed.

A detailed-quality selection activates only after coverage and quality checks pass. With missing high-resolution coverage, report the gap and offer retry or an explicitly labeled lower-detail result. Do not silently turn an accepted 1 m choice into a resampled coarse surface. Optional surround terrain may use clearly separate coarser data. Verify nodata and mixed-source transitions rather than filling them indiscriminately.

### 3.2 Canonical ground data

Use double-precision local east/north/up meters, a fixed documented origin, and the parent's Unreal adapter: X=north, Y=east, Z=up, in centimeters. Convert once at the presentation boundary. Source CRS, vertical datum, units, pixel registration, row orientation, and actual bounds must be explicit. Reprojection changes coordinates; assigning a CRS label does not. Keep rectangular width/height and independent horizontal sample spacing. [H1]

Keep immutable ground elevation, authored grading, and render derivatives separate. Define `effectiveGround = immutableGround + committedGrade` conceptually; the actual edit storage can be sparse patches rather than a whole-map dense delta. Neither a mesh nor an Actor becomes geographic authority. Do not add physical snow height to this contract.

Each terrain tile records provider/product/version, item IDs/checksums, epoch, CRS/datum/units, transform, dimensions, source/delivered spacing, accuracy when documented, nodata/validity, quality category, processing version, license/attribution, and bounds. Unknown quality remains unknown.

Raster samples and mesh vertices need an explicit sampling rule; do not silently reinterpret pixel centers as grid corners. Define the interpolation and triangle split used by queries, rendering, and grading. Validate source seams, normal halos, and query agreement using synthetic fixtures and real data.

### 3.3 Runtime renderer and bounded fallback

Retain the parent terrain builder's first bounded runtime-heightfield candidate: Geometry Framework C++ with `UDynamicMeshComponent`. The earlier documentation review found no built-in LOD, Nanite, or mesh-distance-field support; a finite tile/LOD layer therefore remains project work. Recheck the installed version and test actual material/shadow behavior. [E1]

If the existing builder already has a suitable runtime component, test that implementation before creating a competing one. If the candidate fails a recorded criterion, evaluate **one bounded alternative: Realtime Mesh Component Core** against the identical fixture. The earlier Core README placed runtime geometry/LODs under MIT but runtime Nanite/SDF/Lumen-card/spatial-streaming extras under paid Pro. Recheck the exact revision/edition; do not assume the paid capabilities exist in free Core. [E2]

No editor-only Landscape/Mesh Terrain showcase, remote cook, end-user Unreal Editor, hidden development runtime, or source-engine fork counts as the required packaged runtime solution. Cook the executable first, acquire an unseen supported mountain second, then load and edit it in that executable. [E3, H1]

### 3.4 Initial prototype settings—not fixed product limits

| Item | Proposed starting choice | Required verification |
|---|---|---|
| Logical terrain tile | About 256 m square | Compare component count, uploads, edits, and resource peaks. |
| Finest lattice | About 1 m when source evidence and camera scale justify it | Preserve source quality; do not describe upsampling as new accuracy. |
| LOD strides | 1/2/4/8/16 m; initially one level maximum neighbor difference | Shared samples, stitched transitions, hysteresis, and picking. |
| Screen-space error | Around 1–2 pixels as a tuning goal | Balance close-up appearance against measured resource limits. |
| Normals and borders | Shared edge values and derivative halos | No artificial cracks or normal seams across tiles or grade patches. |
| Work scheduling | Bounded plain-data background work; bounded game-thread publication | Cancellation/session fencing and no unbounded game-thread wait. |

A 257×257-vertex tile contains **66,049 vertices** and does not fit a conventional 16-bit vertex-index range; use appropriate 32-bit indexing or smaller subpatches. Do not round real ridges and cliffs away to obtain smooth shading. Cosmetic fine normals/material variation must not alter measured slopes, grading, or earthwork.

An 8 km square on a 1 m vertex lattice has **64,016,001 vertices**, **128 million triangles**, and approximately **256.064 MB for one float32 height channel** before attributes, indices, copies, collision, and other layers. These are arithmetic examples, not actual engine memory. Bound residency and transients rather than constructing the full-detail world in every representation at once.

## 4. Contract handed to P2 and P3

P1 provides a versioned **TerrainCore** data contract, not a new independently maintained application:

| Output | Meaning | Consumer |
|---|---|---|
| Package/frame identity | Stable mountain ID, origin, CRS/datum conversion, units, bounds | P2 aligns all inputs; P3 shares the same world frame. |
| Ground tile descriptors | Immutable heights, validity, quality, source metadata | P2 derives terrain-dependent evidence; P3 attaches plants to the ground. |
| Height/normal sampling | Explicit sampling semantics and query revision | P2 slope/aspect preparation; P3 placement/contact. |
| Terrain edit/change receipt | Committed revision, affected bounds/tiles, changed sampling revision | P2 invalidates relevant derivatives; P3 updates only affected plants. |
| Offline package reader | Validation, bounded IO, compatible version policy | Both plans reuse it instead of inventing another package loader. |

These are conceptual fields/interfaces to fit the actual builder, not mandatory new services/classes. Define them narrowly in P1; P2 and P3 may use fixtures conforming to the contract before full integration. P1 must accept absent ecology/vegetation sections and must not discard already-present optional sections when grading or saving an extended package.

## 5. Implementation tasks

Each task is separately scoped and authorized. “New implementation location” means proposed ownership inside the existing native/preparation modules; do not create unnecessary new modules or move unrelated files.

### P1.01 — Current-state and exact-source report

Inspect the active builder, parent plan, checkout/dirty state, toolchain, and source dependencies. Trace `src/elevation.ts` and `src/terrainIngest.ts` only as relevant historical acquisition/persistence references. Query coverage for an approximately 2 km Crystal development crop containing forest edge and exposed relief; record actual source files, quality, dates, terms, and a degraded-source fixture. The crop is not the release footprint.

**Deliverables:** compatibility/source matrix, proposed camera shots, measured-data versus resampled-data labels, one legal fixture/acquisition recipe, and the smallest next code task. **Gate:** P1.T01; no claim of site coverage from a catalog homepage alone.

### P1.02 — Ground-only contract and provider adapter

Implement bounded acquisition, retries/cancellation, real geotransforms, masks, provenance, and stage/validate/activate behavior in the terrain preparation pipeline. Prefer existing lidar-derived ground products. Define the shared frame and extension-safe package contract before P2 independently codes against it.

**Deliverables:** source adapter, TerrainCore schema/reader fixtures, quality/preflight report. **Gate:** P1.T02–T04. No canopy classification or plant assets in this task.

### P1.03 — Native import, queries, and terrain detail

Connect terrain tiles to the actual runtime builder. Implement finite LOD, borders/normals, near interaction detail, bounded residency, and a cooked diagnostic material. Prove arbitrary post-cook terrain import before expanding terrain features.

**Deliverables:** packaged small-mountain proof, terrain/query comparisons, resource log. **Gate:** P1.T05–T07. A pretty editor viewport cannot close the task.

### P1.04 — Grading, persistence, and dependency handoff

Integrate with existing grading and transaction infrastructure. Before the actual tool is available, use a bounded grade-like command to test update seams and emit revision receipts; record actual tool integration as pending rather than marking it passed. Once available, require the real tool, undo, manual save, and offline reopening. Work on a proposal or Load Blueprint must not mutate built ground.

**Deliverables:** edit/query/render readiness policy, change-receipt fixture for P2/P3, extension-preserving save behavior. **Gate:** P1.T08–T10. No full cover/vegetation implementation is needed to test the receipt.

### P1.05 — Standalone visual and scale qualification

Review close/overview/steep-side camera travel on the same mutable packaged terrain. Scale toward parent-approved map limits, capture cold/warm measurements, and check the explicit lower-quality route. Commission the single alternate renderer comparison only if a specific gate fails.

**Deliverables:** supported terrain/hardware envelope, unresolved limits, actual reviewer reports, owner visual result, P2/P3 handoff. **Gate:** P1.T11–T12. Keep combined flora regression as P3's later responsibility.

## 6. Acceptance tests and completion gate

| ID | Case | Pass condition |
|---|---|---|
| P1.T01 | Coverage and source provenance | Exact footprint/date/datum/native quality established, or uncertainty visibly reported. |
| P1.T02 | Coarse data resampled to 1 m; partial high-detail coverage | Never advertised as newly measured 1 m terrain; no unapproved fallback activation. |
| P1.T03 | Rectangular grid, axis swap, feet/meters, cell centers, datum mismatch | Correct frame/units/registration or explicit rejection; forward/inverse tests agree. |
| P1.T04 | Network failure, corrupt hash, oversize data, invalid path, cancellation | Bounded resources; no partial or stale package activation; existing package remains valid. |
| P1.T05 | New terrain acquired after cook | Packaged executable loads without editor, development server, or player-installed Node/Python. |
| P1.T06 | Steep surface and neighboring LOD changes | No artificial cracks/normal seams; real forms retained; queries align under defined tolerances. |
| P1.T07 | Fast pan/zoom and low-memory pressure | Bounded residency/publication; coherent fallback; no unbounded mesh build on game thread. |
| P1.T08 | Grade crosses a tile boundary; undo/redo | Correct coherent ground/query/render revisions, stable unaffected tiles, recoverable failure. |
| P1.T09 | Save/quit/reopen under network denial | Same ground/source/edit state with no provider contact and no full preparation rerun. |
| P1.T10 | Extended package contains P2/P3 optional data | P1 loads core alone, preserves extensions, and emits minimal edit invalidation without dependency cycles. |
| P1.T11 | Same renderer, appearance, and grading | Owner accepts playable camera result; no separate pretty/read-only renderer substituted. |
| P1.T12 | Recorded supported-size performance lane | Actual cold/warm results, limits, and unresolved combinations recorded; not a theoretical FPS claim. |

Preserve the parent's **30 FPS minimum intent / 60 FPS target**, without claiming a supported minimum GPU. Record CPU, GPU/VRAM, RAM, OS/driver, engine patch, RHI, internal/output resolution, upscaling, package versions, and camera replay. Measure cold and warm runs, complete frame timelines, p50/p95/p99, maximum stall, game/render/GPU time, and actual memory residency. The optional older laptop gets a separate compatibility result. [H1, H2]

The inherited proposed 60-FPS-lane criteria are nominal 16.67 ms frames, p95 <=20 ms, p99 <=33.3 ms, and investigation of any >=100 ms gameplay stall. These are **proposed tolerances, not owner-approved measurements or a guarantee of constant 60 FPS**. Establish the 30-FPS lane on its own measured hardware. Reserve CPU/GPU/memory headroom for later simulation and UI; a passing empty scene does not certify the integrated game.

Retain the parent's approximately five-minute standard-preparation reference and <=30 s prepared-load initial standard-fixture target as prior targets, not universal guarantees. High Detail may take longer when explicitly selected. Report preparation separately from warmed gameplay and reuse complete local packages. [H1]

**P1 is complete only when the supported ground-data path, packaged editable terrain, offline persistence, standalone acceptance, and fresh independent review are demonstrated.** P2/P3 feature work is not required to close P1. Source discovery/prototype success alone is not release qualification.

## 7. Questions and required input

### Q1 — Closest usable camera

**Question:** Does “treeline level” mean an oblique canopy-height strategy view or moving down among trunks at ground level?

**Recommendation:** canopy-height strategy view first; provisionally test 20–30 m above local ground, with selected closer diagnostic shots. Judge actual visuals rather than adopting those numbers as a universal hard limit. Do not add first-person walking/skiing. [H1]

**Needed:** before final P1.05 visual acceptance; small prototypes can proceed with labeled assumptions. P2/P3 inherit this answer; do not ask it again.

**Answer:**

### Q7 — High-detail storage policy

**Question:** Allow multi-gigabyte High Detail packages with a size estimate and user-set cap, or impose a firm per-mountain limit?

**Recommendation:** explicit High Detail choice, preflight estimate, and user-set storage cap. Never silently coarsen source data to fit. Estimate terrain, later cover/vegetation contributions, temporary workspace, and retained source cache separately; compressed disk size is not determined by the raw height arithmetic above.

**Needed:** before release storage limits in P1.05. P2/P3 contribute their resource estimates without reopening the decision.

**Answer:**

Engineering owners—not new questionnaire items—must inspect hardware, installed engine, actual accepted map-size settings, and exact Crystal coverage. Local facts should be measured rather than guessed.

## 8. Adversarial checks and reviewer assignments

| Challenge | Required rebuttal or experiment |
|---|---|
| “Lidar” means any 1 m output raster | Native ground-product lineage, source quality, and delivered-spacing negative control. |
| Raw canopy/roof elevations accidentally become terrain | Known ground fixtures and product/classification semantics; P2 owns canopy separately. |
| Renderer chosen because an editor demo looks good | Post-cook acquisition plus editable/offline packaged proof on the same representation. |
| Dynamic Mesh or free RMC automatically supplies advanced features | Version/edition capability audit and one bounded alternative, not marketing assumptions. |
| Fine terrain exhausts memory or introduces tile cracks | Finite residency, real buffer sizes, shared-border/LOD tests, and query agreement. |
| P1 cannot finish until cover and vegetation exist | Empty optional-extension fixture and independent ground-only finish gate. |
| Grading rewrites entire packages or invalidates future world identity | Local receipts, extension preservation, coherent persistence, and stale-result rejection. |

Assign a fresh **geospatial/data reviewer** to source/accuracy/CRS/provenance/security and a fresh **runtime-terrain reviewer** to packaged behavior, LOD, grading, performance, and independence from P2/P3. Both return concrete failure cases and unverified assumptions.

### Genuine independent review procedure

Use the existing requested routing only when actually available: Sol High coordinates; fresh Terra High sessions review; Astra is a sparse high-level escalation rather than a default. Verify actual model/effort and effective read-only permissions; use no more than two reviewer sessions concurrently. Filesystem, editor automation, commands, and connector permissions all matter. Reviewers return findings, not repairs. [H2]

Give reviewers the owner requirements, relevant canonical contracts, code snapshot, and source references for an unanchored first pass; then supply the proposed approach and challenge register. Record session identity, input hashes, permissions, sources checked, and experiments actually run. Reconcile each finding as ACCEPT, REJECT WITH EVIDENCE, NEEDS EXPERIMENT, or OWNER DECISION. Agreement is not a substitute for evidence.

If fresh reviewer spawning is unavailable, report `INDEPENDENT_REVIEW = BLOCKED`; never report self-review or role-play as executed independent agents. The previous package's author self-audit remains historical. The challenge checks in this split are planning requirements, not reviewer reports.

A reviewer report must state: claim challenged; severity/confidence; precise evidence; minimal failure case; whether existing tests catch it; correction or experiment; unresolved uncertainty; requirements dropped or added; and the smallest next authorized task. Record NONE for experiments not run.

## 9. Codex entry task and handoff

Start with **P1.01 only**, read-only. Return current-state drift, exact source candidates/limitations, proposed camera/fixture, affected ownership/files, and one bounded P1.02 or P1.03 implementation task. Do not start a replacement terrain renderer until the actual builder has been inspected.

Typical ownership: existing `Tools/Preparation` adapter and package writer; existing domain terrain/sampling code; native presentation terrain component; targeted fixtures/tests. Historical source locations are references, not instructions to preserve the web renderer.

At handoff, attach TerrainCore descriptor and sample fixture, frame/sampling specification, revision/change-receipt example, test results, current performance envelope, source/license manifest, and unresolved questions. P2 uses these outputs; P1 does not import P2's classifier or P3's renderer.

## Source register and evidence limits

The source references below are carried forward from the supplied v1 planning package, whose recorded research date is **21 September 2026**. This split did not refresh the repository, provider availability, asset listings, licenses, or engine documentation. Recheck mutable facts at the implementation gate. These sources support the recorded research, not an assertion that the proposed code works. H1/H2 identify historical planning evidence, not these new P1/P2 workstreams. All other bracketed IDs resolve below.

- **R0 — Repository guidance / visible application.** `AGENTS.md`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/AGENTS.md . Describes React/MapLibre/Electron and existing ownership/invariants. Inspected branch metadata and recursive main tree separately; no native project found in that response. Local/unpushed work is unverified.
- **R1 — Elevation acquisition.** `src/elevation.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/elevation.ts . Relevant identifiers: `MAX_GRID_DIMENSION`, `MIN_GRID_DIMENSION`, `sampleGridSizeFor`, `fetchWithShrink`, `fetchElevationGrid`.
- **R2 — Terrain preparation and persistence.** `src/terrainIngest.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/terrainIngest.ts . WorldCover request at 10 m; NAIP/context integration; original/derived separation; returned elevation bounds; verification after save.
- **H1 — Prior owner planning artifact, retrieved from Library.** `01_MASTER_PLAN.md`, retained Unreal v0.8 master within the v0.9 context; Library file ID `file_0000000078dc81fd8e8059fac423ddd1`. Sections 4–8 are the main runtime-terrain, geography, visual, preparation and Build contracts. This is prior planning, not implemented behavior.
- **H2 — Current handoff and answer reconciliation, retrieved from Library.** `START_HERE_CODEX_PROMPT.md` v0.9, file ID `file_0000000012d881fd86e341fa929faa7b`; `09_FOCUSED_FOLLOW_UP.md`, file ID `file_00000000684c81fd9a5e164d9c2c1e1c`; and the surfaced current `03_PHASE_PLAYBOOKS.md`. Establish Crystal Mountain WA, the optional older laptop and review routing. These originals were not edited.
- **D1 — USGS, 3DEP products and services.** https://www.usgs.gov/3d-elevation-program/about-3dep-products-services . Describes elevation/lidar products, access and use restrictions. Supports source selection, not guaranteed 1 m coverage for every site.
- **D2 — USGS, seamless 1 m DEM product.** https://www.usgs.gov/3d-elevation-program/new-product-3d-elevation-program-seamless-1-meter-digital-elevation-model-s1m . Candidate product to check against actual footprint; not evidence that the selected Crystal crop has been downloaded or verified.
- **D3 — Washington DNR lidar catalog/portal information.** https://dnr.wa.gov/washington-geological-survey/publications-and-data/lidar . Regional DEM/point-cloud discovery route; check actual dataset terms/coverage rather than assuming all DNR products are identical.
- **E1 — Epic, Geometry Scripting user guide.** https://dev.epicgames.com/documentation/en-us/unreal-engine/geometry-scripting-users-guide-in-unreal-engine . Dynamic Mesh/Geometry Framework ownership, editor/runtime distinctions, and documented missing Nanite, distance-field and built-in LOD features. Does not qualify our proposed tiled renderer.
- **E2 — TriAxis, Realtime Mesh Component Core README.** https://github.com/TriAxis-Games/RealtimeMeshComponent/blob/master/README.md . Retrieved through the GitHub connector. Core includes runtime geometry/LODs and is described as MIT; runtime Nanite and SDF/Lumen/spatial-streaming additions are listed under Pro. Compare cautiously with broader product marketing at https://triaxis.games/realtime-mesh/ . Pin exact revision/license at implementation; no plugin installed or tested here.
- **E3 — Epic, Mesh Terrain.** https://dev.epicgames.com/documentation/unreal-engine/mesh-terrain-in-unreal-engine . Experimental authoring system; this documentation is not proof of arbitrary packaged runtime creation/grade edits.
