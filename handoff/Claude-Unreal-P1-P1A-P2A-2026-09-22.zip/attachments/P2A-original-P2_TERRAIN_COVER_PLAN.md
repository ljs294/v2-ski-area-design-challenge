# P2 — Accurate and Smooth Terrain Cover Map

**Repository:** `ljs294/v2-ski-area-design-challenge`  
**Package:** split revision 2.0, 21 September 2026  
**Status:** implementation plan; implementation, packaged-player tests, and independent reviews are **NOT EXECUTED** by this restructuring task.

> **Outcome:** Replace coarse-looking and partially refined cover with better aligned, confidence-aware land-cover and canopy data, then display it smoothly without erasing real clearings.

This is one of three standalone terrain-builder companion plans. **P1 = lidar terrain; P2 = cover accuracy and smoothness; P3 = procedural flora.** These IDs name workstreams in this package; they do not renumber the existing Unreal replacement plan's phases. References to a parent phase are explicitly prefixed **Parent**. The earlier TV0–TV6 environment backlog is redistributed here, not a second active backlog.

Each plan contains its own scope, contracts, tasks, acceptance checks, questions, source register, and independent-review instructions. It can be handed to Codex without the former combined master plan. Inspect the actual checkout and active parent plan before implementation; a historical reference is not proof of current local state.

## 1. Scope and independent completion

**P2 owns what covers the ground, not the ground mesh and not plant instances.** Improve source acquisition, classification, mapped forest/clearing boundaries, canopy structure, ecological context, smooth material masks, and cover-related persistence/editing.

Included: imagery and canopy evidence, cover/type priors, full-tile refinement, independent semantic channels, alignment/quality, tiled display textures, confidence-aware fallbacks, mapped clearings, committed construction masks, and the data contract P3 will consume.

Excluded: replacing P1's elevation/mesh renderer; procedural tree/grass placement; plant assets, foliage wind/LODs, PCG spawning, or per-tree simulation. P2 may derive canopy height from lidar or use a modeled fallback, but must not replace bare ground with canopy-top elevation. An existing lidar source/cache can be reused without making P1 responsible for canopy classification.

**Standalone finish:** an accurate-enough cover layer with smooth, validated boundaries, meaningful quality labels, correct clearing behavior, and offline persistence—displayable on P1 terrain with **zero 3D vegetation**. P3 is a consumer, not a prerequisite. P2 source/classifier work can use frozen TerrainCore fixtures before P1's whole renderer is complete; final terrain-overlay acceptance uses the agreed actual frame and terrain.

### Execution authority and existing product decisions

This handoff authorizes planning, not game implementation, installs, purchases, publication, staging, or commits. The owner authorizes bounded implementation sections and alone stages/commits. Preserve dirty and untracked work. Read actual root/scoped `AGENTS.md` and `CLAUDE.md`; propose any conflicts with the native replacement direction rather than silently changing guidance.

Preserve the Windows Unreal replacement, same-window mountain preparation, offline gameplay after preparation, manual saves, committed grading, explicit Save/Load Blueprint, working-plan versus built-state separation, overlays/dot guests, and Crystal Mountain WA as the reference. The old laptop is an optional compatibility probe, not the adopted minimum specification. Do not reopen these decisions or introduce a second gameplay application. Retrieve actual approved map-size limits from the active parent plan; a small development crop is not a new product-size limit. [H1, H2]

No first-person game, physical snow system, ecological growth, multiplayer, cloud service, paid plugin, or engine fork is silently commissioned.

## 2. Evidence and the problem being fixed

The previous review inspected `main` at `1cca4e0808b96fa0fc43d48c4289a118b29b30ec`; re-establish the current checkout before changing anything. [R0]

The inherited “30 m chunks” diagnosis was not proven. The code requested **10 m WorldCover**, downloaded four-band NAIP targeting **2 m output** with a 4,000-pixel dimension cap, and derived a four-class map. Its forest refinement operated mainly within an approximately **6 m boundary corridor** around the coarse seed. Isolated forest or interior clearings outside that corridor could remain wrong. [R2–R4]

Display smoothing already existed: the four-class path used about **6 m smoothing**, initial **2 m simplification**, and a vertex-budget fallback that could simplify further or omit whole smaller polygons. Simply blurring more or choosing a smaller output pixel is therefore not a complete solution. [R5]

Inspect the actual failing package, imagery availability, caps/fallbacks, geotransforms, epoch selection, corridor classification, and display path. These were identified risks, not a reproduced cause for the specific map the owner saw.

## 3. Data contract and ownership

P2 consumes P1's TerrainCore package/frame identity, immutable ground, explicit query/normal semantics, source quality, and localized committed terrain-change receipts. P2 owns an optional versioned **CoverEcology** extension. It uses the same origin/world frame but can have its own raster spacing and tile layout. Do not force imagery pixels, mesh vertices, ecology cells, and render cells into one identical grid.

| P2 field | Meaning | Consumer/use |
|---|---|---|
| Semantic cover and confidence | Evidence for trees, shrub/low vegetation, herbaceous, bare/rock, water, built surface; heuristic versus calibrated status recorded | Display summary and P3 habitat constraints. |
| Canopy cover fraction | Estimated fraction of area occupied by canopy; not classification confidence | P3 density calibration. |
| Canopy height statistics | Defined statistic/distribution, units, epoch, method, quality, missingness | P3 stature selection, not one identical tree height per cell. |
| Vegetation-community/type prior | Regional coarse ecological grouping and source/class crosswalk | P3 plausible archetype mixtures, not exact per-stem species. |
| Substrate/material weights | Forest floor, herbaceous ground, soil, rock, water, and visual snow treatment | Smooth terrain appearance; separate from aerial tree crowns. |
| Mapped and authored exclusions | Water, mapped clearings, built surfaces where valid, committed construction masks | Display and P3 suppression; working proposals kept separate. |
| Provenance and validity | Source/version/epoch, transform, native/output spacing, masks, confidence, license/attribution | Honest quality UI, offline reconstruction, debugging. |
| Cover revision/change receipt | Changed bounds/tiles, relevant channel revisions, committed-mask revision | Bounded P3 invalidation without global regeneration. |

Keep the schema small and optional. Preserve the old forest/alpine/grassland/water summary where useful, but do not let it erase richer evidence. A height value is not a species label; class probability is not canopy fraction; nodata is not zero canopy. P3 chooses plant records; P2 contains no live instance IDs.

P2 may use a minimal subset of channels for the first accurate-cover slice. Height and community fields may be absent with explicit fallback semantics; final P2-to-P3 handoff must document what is actually available. Do not build a global vegetation simulator or model-training service before improving the current map.

## 4. Recommended data and processing pipeline

### 4.1 Source roles

The following roles are carried forward from the earlier research; confirm exact versions, footprint coverage, and terms before implementation.

| Source | Role | Limit that must remain visible |
|---|---|---|
| NAIP RGB+NIR | Fine canopy/clearing evidence and independent visual checks | Earlier official reference described 0.6 m standard after 2018 and some 0.3 m options; dates, shadows, clouds, and registration still matter. Sub-meter pixels are not sub-meter absolute accuracy. [D4] |
| Lidar-relative canopy evidence | Preferred local vegetation-height/structure estimate when data quality permits | Bare-earth ground alone has no tree heights; non-ground points can include buildings/artifacts and sparse/leaf-off returns. [D5] |
| Meta/WRI canopy maps | Practical modeled-height fallback or additional evidence | ML estimates, not a measured inventory; record version/epoch/uncertainty and attribution. [D6] |
| ESA WorldCover | Broad cover prior and explicit fallback | 10 m classes are not stem-level species or height data. [D7] |
| LANDFIRE EVT/EVH | Vegetation-community and broad height-class priors | Keep coarse ecological boundaries out of fine visible edge geometry. [D9, D10] |
| Dynamic World | Optional temporal/confidence input only when needed | Probability is not canopy fraction; processing/account terms are distinct from dataset licensing. Not a new mandatory service. [D8] |

### 4.2 Acquisition and geospatial alignment

Acquire bounded tiles/source windows at useful resolution rather than forcing the whole map into a fixed pixel cap. Distinguish native source spacing from exported/working spacing. Handle scene-query pagination, incomplete newest-year coverage, returned bounds differing from requested bounds, nodata, and mixed-resolution scenes.

Reproject into the P1 metric frame with actual transforms and appropriate resampling by field type. Preserve cell-center semantics, rectangular dimensions, independent x/y spacing, and validity masks. Do not assume matching normalized UV coordinates imply matching geographic locations.

Keep imagery, ground, canopy, and land-cover epochs. A recent clear-cut or burn in imagery can disagree with an older canopy product; expose that conflict and select a documented, confidence-aware rule rather than combining them as simultaneous truth. Optional canopy absence should still permit a labeled cover result.

### 4.3 Accurate classification before smooth display

Use a **1–2 m working grid** for the detailed tier where evidence supports it. This is a proposed processing choice, not a claim that every cell is independently measured. Work in tiles with appropriate analysis halos and bounded memory.

Start with interpretable fusion: WorldCover is a prior, valid canopy height/structure helps distinguish woody canopy from low vegetation, and NAIP indices/texture/edges refine the **entire valid tile**. Do not restrict correction to the old boundary corridor. A vegetation index alone cannot establish tree height or species. Prefer a small tested rule/model adapter over mandatory global neural-network training.

For lidar canopy processing, use consistent horizontal/vertical frames and valid ground references before height-above-ground normalization. PDAL's documented DEM-relative filter is a candidate component, not a complete canopy classifier. Filter contextual vegetation, buildings/outliers, sparse data, and out-of-bounds samples; record the chosen height statistic and support/uncertainty. [D5]

Validate on held-out image patches and small independent forest-edge/clearing annotations. Measure omission/commission, boundary displacement, and narrow-feature retention. Do not tune and validate on the same patches or claim canopy-height accuracy from plan-view imagery alone. Quantitative height validation needs appropriate independent height evidence; otherwise disclose it as unvalidated.

### 4.4 Smooth presentation without falsifying the map

Generate continuous material weights or distance-derived masks from the semantic evidence. Interpolate/filter **weights or one-hot fields**, never raw categorical IDs. Renormalize valid weights and maintain hard water/construction exclusions where required.

Prototype roughly **1–3 m visual transition widths** on detailed cover, then adjust against actual boundary uncertainty and the approved camera. Preserve narrow ski runs, isolated groves, real holes, and water edges. A coarse-data fallback may look smooth, but must still disclose its coarse evidence; procedural sub-cell edge variation cannot be labeled mapped accuracy.

Use tiled textures with gutters and appropriate mipmaps. Verify border sampling and distant mip behavior, including narrow clearings that would otherwise disappear. P3 must never derive tree presence from budget-dropped/simplified display polygons. Semantic data and committed exclusions remain authoritative.

Near-camera ground uses forest-floor/soil/rock/herbaceous materials rather than projected aerial crowns and baked canopy shadows underneath another 3D forest. Preserve imagery as evidence/reference; a future matched distant representation belongs to P3. P2 can inspect forest-floor appearance without having plant meshes.

### 4.5 Editing, readiness, and offline persistence

Do not treat “editing the cover map” as authorization for a new freehand painting product. This plan revises generation/display and integrates already-approved construction changes. A user-facing manual cover-paint tool is separate scope unless already present and required in the actual parent plan.

Keep immutable source/classification evidence, committed clearing/material overrides, working-plan previews, and derived textures separate. Preview/Load Blueprint changes no canonical cover. On Build, use the existing shared transaction—not a second cover transaction—to commit grading/clearings coherently. Publish matching cover revisions and notify P3 only for relevant affected cells plus processing halos.

Local grade edits do not trigger a whole-mountain provider fetch or classification rerun. Recompute only affected terrain-dependent channels; source canopy evidence remains identified as pre-edit evidence, while exclusions and any required placement contact are updated. Reject stale jobs by package/session/channel/edit revision.

Save canonical masks/overrides, source and processing versions, hashes, and extension descriptors. Rebuild corrupted derived display caches from the saved canonical version. Never refresh old worlds from the newest online maps during load. P2 can load without P3 data and must preserve any P3 extension it encounters.

## 5. Implementation tasks

### P2.01 — Reproduce and establish independent reference patches

Inspect `src/terrainIngest.ts`, `src/usgsTerrainCover.ts`, `src/fourClassCover.ts`, and `src/coverDisplay.ts` in the relevant current/native preparation path. Identify the actual failing map and derive baseline cover metrics/screenshots. Use the owner example if provided; otherwise label a fresh representative fixture without claiming to reproduce that defect. Freeze P1 frame/query fixtures and exact imagery/canopy provenance.

**Deliverables:** baseline, source/epoch/alignment audit, held-out patches, smallest classification improvement task. **Gate:** P2.T01–T03.

### P2.02 — CoverEcology extension and bounded acquisition

Add aligned tiled inputs, validity/quality channels, source/delivered spacing, and optional-canopy semantics. Keep the package loader/activation path shared with P1; add extension validation rather than another global schema or a breaking parent rewrite. Read only needed raster windows and reuse existing legal source cache where possible.

**Deliverables:** native-readable CoverEcology fixture, normal/fallback packages, preflight contribution. **Gate:** P2.T03–T05.

### P2.03 — Whole-tile refinement and canopy/community adapters

Implement fine cover fusion beyond original boundaries. Add one validated canopy source adapter with a missing-data fallback, and a small optional vegetation-community crosswalk. Keep inferred types visibly approximate. Document canopy fraction versus confidence and height-statistic semantics.

**Deliverables:** revised classifier, height/community fields where supported, reproducible held-out comparison. **Gate:** P2.T06–T08. No procedural plant objects in this task.

### P2.04 — Smooth cover presentation on the actual terrain

Create cooked material families/parameters, tiled weights/gutters/mips, and protected exclusions. Validate near/overview views using P1's terrain with vegetation disabled. Preserve source boundary detail while removing grid stair-stepping. Reuse P1's terrain component instead of switching renderer for the cover demo.

**Deliverables:** playable terrain-plus-cover slice, visual comparison, texture/resource measurements. **Gate:** P2.T09–T10.

### P2.05 — Construction, persistence, and P3 handoff

Integrate existing Build/undo/manual-save behavior, local channel invalidation, and stale-publication fencing. Before actual tools exist, a synthetic committed clearing can establish the contract, but record real-tool acceptance as pending. Confirm no new per-tree dependency or instance persistence has entered P2.

**Deliverables:** actual clearing/undo/save proof, versioned sampling examples, extension/change-receipt handoff. **Gate:** P2.T11–T13.

### P2.06 — Standalone acceptance and regression

Measure the terrain-plus-cover scene against P1's baseline, including cold/warm loads, dense edge detail, mip transitions, and worst-case valid footprint. Review high-quality and explicit fallback cases. Adopt quantified quality tolerances after the reference baseline is available; do not invent a universal remote-sensing accuracy threshold without evidence.

**Deliverables:** accepted cover quality/resource envelope, source/terms ledger, owner visual result, fresh review reports. **Gate:** P2.T14. Wider provider/region expansion is incremental, not a blocker to one validated environment.

## 6. Acceptance tests and completion gate

| ID | Case | Pass condition |
|---|---|---|
| P2.T01 | Existing blockiness diagnosis | Reproduction evidence or explicit unconfirmed status; no blanket “30 m data” assertion. |
| P2.T02 | Source/output resolution and fallback | Actual spacing/quality preserved; fine export not misrepresented as new detail. |
| P2.T03 | Mismatched bounds/UVs, pixel centers, anisotropic/rectangular grids | Independent alignment checks in P1 frame; no coincident-UV shortcut. |
| P2.T04 | Partial scene coverage, nodata, newest-year gaps, epoch disagreement | Explicit masks/conflicts; no silent complete-coverage claim or false zero canopy. |
| P2.T05 | Cancellation, corruption, unsupported schema, excessive size | Bounded processing and no stale/partial extension activation. |
| P2.T06 | Isolated grove/interior clearing beyond original boundary corridor | Full-tile refinement can correct both; improvement demonstrated on held-out examples. |
| P2.T07 | Meadow, building, rock, snow/shadow, sparse/leaf-off lidar | Failures measured; elevated buildings not automatically trees; uncertainty remains visible. |
| P2.T08 | Confidence, fraction, height, type separation | Semantically distinct fields and missingness; no one-tree-per-probability-pixel assumption. |
| P2.T09 | Small clearings, water, tile borders, changing mips | Smooth display retains genuine protected features; weights normalize and categories are not averaged. |
| P2.T10 | Vegetation disabled, same runtime terrain | Cover alone looks correct near and far; no reliance on plant objects hiding bad boundaries. |
| P2.T11 | Preview, Load Blueprint, Build, boundary-crossing clearing, undo | Only committed commands change canonical masks; local coherent revisions restore correctly. |
| P2.T12 | Out-of-order work and future P3 extension present | No stale reappearance or extension loss; change receipts support localized consumers. |
| P2.T13 | Save/reopen offline; missing derived textures | Same canonical cover/version, no online refresh, safe cache rebuild. |
| P2.T14 | Quality and performance against baseline | Independent reference comparisons and measured resource impact; unresolved coverage/accuracy labeled. |

Preserve the parent's **30 FPS minimum intent / 60 FPS target**, without claiming a supported minimum GPU. Record CPU, GPU/VRAM, RAM, OS/driver, engine patch, RHI, internal/output resolution, upscaling, package versions, and camera replay. Measure cold and warm runs, complete frame timelines, p50/p95/p99, maximum stall, game/render/GPU time, and actual memory residency. The optional older laptop gets a separate compatibility result. [H1, H2]

The inherited proposed 60-FPS-lane criteria are nominal 16.67 ms frames, p95 <=20 ms, p99 <=33.3 ms, and investigation of any >=100 ms gameplay stall. These are **proposed tolerances, not owner-approved measurements or a guarantee of constant 60 FPS**. Establish the 30-FPS lane on its own measured hardware. Reserve CPU/GPU/memory headroom for later simulation and UI; a passing empty scene does not certify the integrated game.

Allocate a distinct cover/texture/preparation budget within—not in addition to without limit—the accepted world budget. Record transient image bands, masks, halos, mips, and staging copies. In particular, high-resolution classification must not run every gameplay frame or on every pan.

**P2 is complete when accurate-enough mapped cover and smooth display, correct authored exclusions, offline persistence, documented optional fields, and fresh review all pass without 3D flora.** Inferred heights/types are advertised only to the level independently supported.

## 7. Questions and required input

### Q8 — The map showing the defect

**Input requested:** one screenshot at the problematic zoom plus map bounds/name and preparation/source-quality metadata when available. A safely shareable saved package is useful but not required for initial architecture work.

**Recommendation:** compare the example with a fresh Crystal fixture before changing every provider. The earlier pipeline already used 10 m WorldCover, nominally 2 m NAIP refinement, and smoothing; caps, missing imagery, corridor-only refinement, and simplification remain alternative explanations. [R2–R5]

**Needed:** before claiming the exact cause of that existing map's defect; P2.01 can begin independently with a labeled representative fixture.

**Input:**

### Existing decisions to consume, not ask twice

Use Q1 (camera) and Q7 (storage) from P1. P3's Q2 asks whether data-driven plausible reconstruction rather than an exact individual-tree inventory is acceptable. P2's default remains conservative, confidence-aware stand/cover information; a later demand for exact per-tree identification requires a new scoped data/validation task, not an implicit claim that this pipeline already supplies it.

The implementation owner should verify actual imagery/canopy terms, exact site dates/coverage, classification baseline, and meaningful accuracy tolerances. These are engineering evidence tasks rather than user guesses.

## 8. Adversarial checks and reviewer assignments

| Challenge | Required rebuttal or experiment |
|---|---|
| Smaller output pixels or more blur are sufficient | Separate measured classification improvement from display smoothness on held-out patches. |
| NAIP and terrain can share normalized UV without transform checks | Deliberately shifted/rectangular fixture and independent world-coordinate alignment. |
| Old WorldCover boundaries must remain fixed | Isolated-grove and interior-clearing examples outside the old refinement corridor. |
| Every elevated return or strong vegetation index is a tree | Building/meadow/sparse-lidar negatives, confidence and correct canopy normalization. |
| Probability, canopy fraction, and height can share one scalar | Schema semantics, calibration/uncertainty, and explicit missingness. |
| Smooth cover may erase small ski corridors | Narrow-feature tests through weights, gutters, mips, and construction overrides. |
| Fine cover requires finished procedural plants | Vegetation-disabled acceptance scene and P1-compatible standalone extension. |
| New provider data can silently replace saved old data | Versioned source/processing receipts and network-denied persistence tests. |

Assign a fresh **geospatial/cover reviewer** to alignment, class/height claims, coverage/epochs, quality validation, and licensing. Assign a fresh **runtime/display and persistence reviewer** to masks/mips, local edits, package extensions, performance, and independence from plant rendering.

### Genuine independent review procedure

Use the existing requested routing only when actually available: Sol High coordinates; fresh Terra High sessions review; Astra is a sparse high-level escalation rather than a default. Verify actual model/effort and effective read-only permissions; use no more than two reviewer sessions concurrently. Filesystem, editor automation, commands, and connector permissions all matter. Reviewers return findings, not repairs. [H2]

Give reviewers the owner requirements, relevant canonical contracts, code snapshot, and source references for an unanchored first pass; then supply the proposed approach and challenge register. Record session identity, input hashes, permissions, sources checked, and experiments actually run. Reconcile each finding as ACCEPT, REJECT WITH EVIDENCE, NEEDS EXPERIMENT, or OWNER DECISION. Agreement is not a substitute for evidence.

If fresh reviewer spawning is unavailable, report `INDEPENDENT_REVIEW = BLOCKED`; never report self-review or role-play as executed independent agents. The previous package's author self-audit remains historical. The challenge checks in this split are planning requirements, not reviewer reports.

A reviewer report must state: claim challenged; severity/confidence; precise evidence; minimal failure case; whether existing tests catch it; correction or experiment; unresolved uncertainty; requirements dropped or added; and the smallest next authorized task. Record NONE for experiments not run.

## 9. Codex entry task and handoff

Start with **P2.01 only**, read-only, using P1's frame fixture when available. Return the observed pipeline, reproducible versus hypothesized defect, independent reference patches, required optional-data policy, and one bounded implementation task. Do not silently convert this into a raw-lidar terrain rebuild or a general-purpose manual GIS editor.

Typical ownership: existing preparation imagery/cover modules, optional canopy/community adapters, package extension validator, cover/material presentation, clearing transactions, and focused tests. One owner controls shared material/asset files.

P3 receives a versioned CoverEcology fixture, sampling/quality semantics, accepted material masks and exclusion policy, source/community crosswalk, canopy missing-data policy, change receipt, offline reconstruction recipe, and measured resource cost. No simplified visual polygon becomes the vegetation database.

## Source register and evidence limits

The source references below are carried forward from the supplied v1 planning package, whose recorded research date is **21 September 2026**. This split did not refresh the repository, provider availability, asset listings, licenses, or engine documentation. Recheck mutable facts at the implementation gate. These sources support the recorded research, not an assertion that the proposed code works. H1/H2 identify historical planning evidence, not these new P1/P2 workstreams. All other bracketed IDs resolve below.

- **R0 — Repository guidance / visible application.** `AGENTS.md`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/AGENTS.md . Describes React/MapLibre/Electron and existing ownership/invariants. Inspected branch metadata and recursive main tree separately; no native project found in that response. Local/unpushed work is unverified.
- **R2 — Terrain preparation and persistence.** `src/terrainIngest.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/terrainIngest.ts . WorldCover request at 10 m; NAIP/context integration; original/derived separation; returned elevation bounds; verification after save.
- **R3 — NAIP acquisition.** `src/usgsTerrainCover.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/usgsTerrainCover.ts . Scene lock, four-band export, 2 m requested spacing, 4,000-dimension cap, source metadata and fallback.
- **R4 — Four-class cover.** `src/fourClassCover.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/fourClassCover.ts . WorldCover forest seed, narrow imagery refinement corridor, indices/texture, inferred treeline and four-class product.
- **R5 — Display derivation.** `src/coverDisplay.ts`: https://github.com/ljs294/v2-ski-area-design-challenge/blob/1cca4e0808b96fa0fc43d48c4289a118b29b30ec/src/coverDisplay.ts . Smoothing/simplification, 250,000-vertex budget and polygon-dropping fallback.
- **H1 — Prior owner planning artifact, retrieved from Library.** `01_MASTER_PLAN.md`, retained Unreal v0.8 master within the v0.9 context; Library file ID `file_0000000078dc81fd8e8059fac423ddd1`. Sections 4–8 are the main runtime-terrain, geography, visual, preparation and Build contracts. This is prior planning, not implemented behavior.
- **H2 — Current handoff and answer reconciliation, retrieved from Library.** `START_HERE_CODEX_PROMPT.md` v0.9, file ID `file_0000000012d881fd86e341fa929faa7b`; `09_FOCUSED_FOLLOW_UP.md`, file ID `file_00000000684c81fd9a5e164d9c2c1e1c`; and the surfaced current `03_PHASE_PLAYBOOKS.md`. Establish Crystal Mountain WA, the optional older laptop and review routing. These originals were not edited.
- **D4 — USGS EROS, NAIP.** https://www.usgs.gov/centers/eros/science/usgs-eros-archive-aerial-photography-national-agriculture-imagery-program-naip . Official account of resolution, bands, acquisition, projection, accuracy and distribution. Distinguish native GSD from the coarser export made by this repository; do not infer sub-meter absolute positioning from sub-meter pixels.
- **D5 — PDAL, `filters.hag_dem`.** https://pdal.io/en/stable/stages/filters.hag_dem.html . Documents raster-relative height-above-ground and streaming support. It does not by itself classify vegetation, solve sparse canopy or validate a CHM.
- **D6 — Meta/WRI canopy-height data.** https://registry.opendata.aws/dataforgood-fb-forests/ . Provider-managed registry identifies ML-derived maps, CC-BY 4.0, observation-date sidecars and public no-account S3 access. One-meter mapping context: https://sustainability.atmeta.com/blog/2024/04/22/using-artificial-intelligence-to-map-the-earths-forests/ . Pin actual product/version/epoch; this report does not certify the newest global release or local height error. Raw source imagery rights are separate from the released height map.
- **D7 — ESA WorldCover.** https://esa-worldcover.org/en and https://esa-worldcover.org/en/data-access . Global 10 m classes, with 2020/2021 products. License/access documentation: https://developers.google.com/earth-engine/datasets/catalog/ESA_WorldCover_v200 ; direct data registry: https://registry.opendata.aws/esa-worldcover-vito/ . Broad cover, not species mapping.
- **D8 — Dynamic World catalog.** https://developers.google.com/earth-engine/datasets/catalog/GOOGLE_DYNAMICWORLD_V1 . 10 m class probabilities and labels; optional temporal/confidence evidence. Dataset license does not mean a commercial Earth Engine compute/account service is automatically free or suitable for every player.
- **D9 — LANDFIRE Existing Vegetation Type.** https://landfire.gov/vegetation/evt . Vegetation-community/type prior; not a stem inventory. Exact release/class crosswalk/license recorded at acquisition.
- **D10 — LANDFIRE Existing Vegetation Height.** https://landfire.gov/vegetation/evh . Dominant vegetation height classes at coarse resolution; useful fallback context, not exact heights for individual trees.
