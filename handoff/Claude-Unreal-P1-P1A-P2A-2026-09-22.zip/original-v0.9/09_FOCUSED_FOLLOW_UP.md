# Remaining scope clarification and engineering gates — Unreal v0.9

All five direct answers are recorded in [sources/OWNER_FINAL_ANSWERS.md](sources/OWNER_FINAL_ANSWERS.md). Mixed multi-item plans, daily arrivals/pricing, Crystal Mountain WA, available older laptop, and permission to translate the weather backend are not unanswered questions. One new scope distinction remains; it does not block bounded P0 or existing lift/trail tools.

## F1_BUILDINGS — Current footprint tool or future building tooling?
**Needed before:** commissioning building placement; not multi-item blueprint data support.

You explicitly want an entire pod, including buildings, saved as one blueprint. Should this effort also include a simple **2D building-footprint placement tool**, or should it preserve building entries in the blueprint format while building tools come later?

**Recommendation:** support mixed-plan building records now and deliver building placement later unless it is needed for your first playable designer. No 3D building models or amenity/finance simulation is implied in either case. In the meantime unsupported building entries are preserved and clearly non-buildable, never silently removed.

**Answer:**

## Already resolved by the latest answers

- **F1_GROUPING:** entire multi-item trail pods, not single-item-only saved blueprints. Explicit Save Blueprint/Load Blueprint remains separate from Save Game. Build All/Build Selected with visible dependency confirmation is the proposed minimal implementation interface, not cross-mountain stamping.
- **F5_REVENUE:** player-set daily arrivals, fixed daily ticket price, revenue once on actual admission, no price elasticity, estimates-only construction.
- **U5_REFERENCE:** Crystal Mountain, Washington. Task owner proposes camera shots and data bounds for visual review; no named must-preserve feature is invented.
- **F12_HARDWARE:** approximately ten-year-old laptop available. Specs and compatibility are unknown; optional test probe, not an adopted minimum.
- **F10_BACKEND:** preserve existing numerical weather behavior; translate to C++/another language if justified. New visual effects/dynamic clouds are separate future features.

## Engineering evidence, not another questionnaire

**P1:** verify terrain source/bounds and propose reference views of Crystal Mountain. User approves actual visual results. Do not require a newly named chute before starting.

**P4.0:** implement the small clock/event demonstration and freeze daily-input boundary rules. Accepted direction does not approve unshown exact rate changes.

**P5.2:** capture laptop model/CPU/GPU/RAM/OS/storage/driver during a separately authorized local inventory. No purchase request, no unsupported old hardware promise, no assumed editor installation.

**P6.1:** trace actual weather call paths and pin the source behavior. The phrase existing backend does not select gameplay versus lab by directory name. Only ask a concrete behavior-comparison question at that stage if source/use cannot resolve a material difference. There is no new early blocker and no requirement to build dynamic clouds to finish numerical integration.

Unreal/plugin/API feasibility, local model routing, licensing, build evidence and independent reviews remain implementation gates. User alone stages/commits. No repository or original Google Doc changes are authorized by this package revision.
