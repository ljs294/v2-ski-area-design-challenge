# Codex orchestration — Unreal v0.9

## Roles, effort and cost discipline

F11 is now explicit: **Sol High performs all routine delegation, section scoping and coordinating review. Terra High performs all implementation and fresh adversarial review. Astra is used very sparingly for high-level decisions only.** Do not use an always-active Astra parent or call Astra automatically at each phase. Sol reads compact evidence and reconciles Terra findings; it does not substitute its synthesis for a fresh non-author adversarial review. A necessary exceptional Astra escalation contains one decision, relevant evidence, alternatives and a bounded question—not all worker transcripts. Escalation does not authorize paid spend, scope changes or commits. Earlier model-cadence alternatives are superseded. Model availability and exact effort names must be checked in the installed VS Code extension. Explicit child model/effort avoids accidental inheritance; no unsupported field or silent fallback. [E21]

Task inputs contain only the active section, relevant contracts, source paths/fixtures and acceptance criteria. Do not feed the full historical archive into every worker. Return concise evidence-oriented packets; retain detailed logs as artifacts. Do not claim a quota/token savings percentage. No recursive subagent spawning by workers.

At most two implementers plus one reviewer; use fewer whenever files/assets overlap. Reviewer batches for architecture contain at most two simultaneous independent sessions. One designated integrator controls the editor, UBT/UHT/cook, shared build/config files and binary asset creation. C++ writers can operate on truly disjoint task-owned files outside a freeze. Heavy build/editor workloads are serialized on the machine. No per-task branches/worktrees/commits by default.

## User authority

The user alone stages and commits after an accepted phase section. Agents may not commit, amend, tag, push, merge, publish, reset/rebase, switch branches, manipulate worktrees or use connector writes to bypass the rule. An implementation task explicitly lists allowed files and non-goals. Stop on required product changes, new paid dependencies, engine source fork, global config/permissions changes or unscoped deletions. Do not install this pack's templates automatically. Preserve unrelated owner changes and the original game repository.

## Actual independent review

Fresh non-author Terra reviewers independently challenge scope/dependencies, runtime terrain/visuals, simulation/geometry, and persistence/execution. Do not provide this pack's conclusions as answers they should repeat. Once first-pass reports return, compare against audit mappings and reconcile differences by source, failure case or minimal experiment, not a vote.

A label saying reviewer is not enforcement. Request read-only sandbox and verify effective permission/routing. **Also remove write-capable editor MCP/remote-control tools and connector actions**: a filesystem sandbox cannot stop a writable editor process reached over HTTP. Reviewers return findings; any experiment needing writes uses a separately authorized frozen scratch clone/output directory and a test executor. All repairs are a new task/frozen version followed by review. No agent can approve its own changes.

If no spawning or requested model is available, mark actual independent execution BLOCKED; provide the assignments for separate fresh sessions and report unknown routing. Role-play inside one assistant is not multiple executed agents. This planning session did not execute any independent subagent. The final author audit is labeled separately in 14_FINAL_ADVERSARIAL_REVIEW.md.

## Unreal assets and editor automation

Unreal `.uasset`/`.umap` content is not text source. One writer owns each asset and its dependencies. Use supported editor APIs to generate/edit/move content; never raw byte edits, hand-invented serialized files or filesystem renames of engine assets. A repeatable generator owns only declared generated assets; before a second run check ownership/prior hashes and refuse to overwrite unrecognized manual edits. [E18]

Produce asset receipts: stable path/class, referenced asset identities, parameter/property changes, creation script/version, validation result, and required viewport/UI evidence. A hash change alone cannot explain the change. Use Unreal asset diff/property dumps and screenshots where appropriate; do not substitute screenshots for behavioral tests. Source control/LFS policy for binary assets is a bounded user-approved configuration task, not an automatic migration.

A design blueprint is a game construction proposal, NOT an Unreal Blueprint scripting asset. C++ is the authority implementation; Blueprint assets compose tested view/UI functions and configuration only. Explicitly saved game construction plans use the separate small Save Blueprint/Load Blueprint data library; they are not .uasset files. Keep code/editors separate so a node-map viewer does not import editor GraphEditor into the player.

## Optional first-party Unreal MCP

Epic documents an Experimental MCP plugin with editor operations and client-config generation, but the exact installed tools must be inspected. It is not required to implement or test ordinary C++ code. Use CLI/build tools, scoped editor scripts and owner visual checks when the bridge is absent. Unreal editor Python is not a shipped gameplay runtime. [E18/E19]

If authorized: local-only listening, explicit allowed tools, no arbitrary eval/shell native proxies, no write tools in review, no overlapping editor calls. Read the installed config before generating one; never delete/replace an existing Codex config because a generator refuses to overwrite it. AllToolsets convenience is not a least-privilege policy. Record what is really enabled. Stop the bridge when not needed; shipping build audit verifies server/plugins/listeners disabled or excluded. The documentation notes runtime-capable server modules, so do not assume Editor mode alone removes them. Do not expose the unauthenticated service beyond loopback. [E19]

## Frozen evidence protocol

1. Stop source writers and editor mutation tools. Save only authorized dirty assets; unrelated dirty state blocks certification rather than being silently saved/discarded.
2. Record engine/plugin/toolchain/compiler/RHI/config/command identities and the complete relevant source/assets/generated-input manifest, including untracked files and binary sidecars.
3. Run from a frozen/read-only input snapshot where practical, or maintain an explicit exclusive source/editor freeze. No Live Coding/hot reload while qualifying. Before/after hashes detect drift but alone cannot prove a transient edit was impossible; remove write paths during the window.
4. One executor builds/cooks/tests. Output/caches go to declared locations and are not confused with immutable input. Capture loaded asset/save fixture IDs and packaged artifacts.
5. Compare source identity at completion and acceptance. Mutation, changed config, incomplete cook or a source-mismatched executable invalidates the receipt. Re-freeze and rerun affected checks; do not create an agent commit as a workaround.

Live Coding can assist bounded local iteration, but class/reflection/layout/module changes and final qualification require appropriate restart/full build. A green editor session is not a clean package pass. Tests with no discovered cases, timeouts, stale reports or failed subprocesses do not become success.

## Task completion and escalation

Return exact changed source/assets, behavior, source/build identities, commands actually run and results, fresh review findings, blocked checks, remaining decisions and suggested commit message. Do not continue automatically into the next section. The user accepts and commits.

Escalate narrow failures: one reproduction, evidence, relevant contract, smallest alternatives and which owner answer is required. Do not ask already settled questions or resolve an unanswered product choice by choosing the easiest code. Read DECISION_STATUS.json: F1_BUILDINGS is the only product clarification; later laptop/weather trace tasks are evidence gates; F6 direction and weighting deferral are resolved, though the concrete clock demo remains a required approval. Limit review loops to one focused follow-up per material dispute before owner/architecture escalation; new evidence may justify a separately scoped investigation.
