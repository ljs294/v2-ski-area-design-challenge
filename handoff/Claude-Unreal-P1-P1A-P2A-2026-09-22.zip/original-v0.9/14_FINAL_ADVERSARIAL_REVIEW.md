# Retained v0.8 final author audit — current amendments in v0.9

> **v0.9 status:** this file retains the v0.8 review findings for traceability. Its original five missing inputs have since received answers. The current amendment review and their dispositions are in [15_OWNER_ANSWER_RECONCILIATION.md](15_OWNER_ANSWER_RECONCILIATION.md) and DECISION_STATUS.json. Historical findings are not newly executed agent/runtime tests.


**Date:** September 18, 2026. **Inputs actually inspected:** complete v0.7 ZIP; original answer source; all 77 paragraphs/16 answer blocks of the supplied follow-up DOCX; active contracts, phase graph, test/config templates and registry. Source hashes are in evidence/PROVENANCE.json. The v0.7 baseline passed 37 local checks including its delivery manifest; that did not detect the semantic test-ID defect below.

**Method:** sequential single-author challenge across product/source authority, construction/persistence, simulation/runtime safety, and execution/evidence. Small reproducible document/configuration and illustrative state/numerical checks supplement that reading. Targeted official-document rechecks confirm the existing runtime-mesh constraints and configurable model/sandbox fields; they do not test Unreal or the user's Codex client.

**Independent agents:** NOT_EXECUTED. The connected plugin search and local command discovery exposed no usable independent-agent, Codex or Unreal runner. No simulated panel, fabricated model identity or runtime sign-off is claimed. Fresh Terra reviews coordinated by Sol remain an execution gate; see independent-review/START_HERE_CODEX.md.

## Verdict

**Ready as the final planning handoff for bounded P0 scoping and authorized incremental work. Not an unconditional runtime or release approval.** The new decisions are reconciled, material planning corrections are incorporated, and missing owner parameters are isolated to their dependent gates. No unsupplied answer is silently turned into a product requirement. No complete simulation is a prerequisite for terrain.

A final planning package is not permission to skip the same-representation terrain/visual test, the concrete clock demo, actual code/package tests, or non-author review. The author audit cannot close the independent-review requirement by itself.

## Findings and dispositions

| ID | Kind / priority | Concern and correction | Earliest gate |
|---|---|---|---|
| FR08-01 | Owner change / High | Explicit-only blueprint persistence replaces automatic proposal inclusion. Separate action/data/transaction contracts, small controls in first lift slice, dirty-plan warnings and no implicit build on load. | P2.1 |
| FR08-02 | Conditional failure / High | A slow save can save revision A then incorrectly mark newer B clean; older completion can overwrite newer saved data; an old plan can reference a different terrain/anchor or reuse built IDs. Capture/version fences, fresh working identities, explicit dirty replacement and protected library dependencies are now required. | P2.1/P2.3 |
| FR08-03 | Confirmed plan defect / High | v0.7 construction BLD03/BLD04 and simulation SIM08/SIM09 definitions did not match the canonical JSON meanings. Existence-only checking missed this. Generate the definition blocks from one registry, validate exact equality and phase case sets, and fail a deliberately mutated definition. Staged fixtures/specs are not whole runtime-case passes. | Every task |
| FR08-04 | Owner change/boundary / High | F6 defers weighting, so old conditional weighted P4.3 must not remain a mandatory code gate. Current P4.3 now handles real individual cap/pending requests without disappearing people or income before admission. Weighted tests are explicitly future, not passed. | P4.0/P4.3 |
| FR08-05 | Conditional failure / High | Accepted Closed/Open controls could incorrectly hide graph nodes, strand travelers or use layer visibility as operation state. Separate physical topology/eligibility/views; preserve in-flight geometry, reject unsafe closure/deletion, keep manual resume. | P2 flags/P4.5 safety |
| FR08-06 | Owner change / Medium | Old always-Astra profile and mandatory-gate wording would waste usage and violate F11. Only Sol parent example remains; Terra implements/adversarially reviews, Astra is rare high-level consultation. Read-only external-tool controls retained. | P0.2 |
| FR08-07 | Source limit / Medium | U5/F10/F12 method acceptance supplied no identity; F5 only settled cost estimates; F1 did not select multi-item grouping. Five precise follow-ups remain, with no blanket P0 block. | Respective later gate |

These are not seven discovered bugs in existing game code. Categories explicitly separate the source-driven amendments, confirmed document defect and prospective failure cases. The full machine-readable record is FINAL_AUDIT_FINDINGS.json.

## Adversarial counterexamples used

**Explicit persistence:** unsaved proposal edits must not survive ordinary Save Game, while an explicitly saved library version must survive independently. Loading it is a data proposal, not a world checkpoint or build instruction.

**Save race:** start saving proposal revision 3, make revision 4, then finish the older write. The saved snapshot may be valid, but revision 4 must remain dirty. If another write already advanced the library generation, the older write must fail its expected-generation check instead of overwriting it.

**Capacity boundary:** one remaining active slot and two arrival requests must produce one admission plus one explicit pending/unadmitted event, with one ticket—not two admitted agents, silent loss or weighted substitution. Save/retry/day-end must preserve those classifications.

**Test-ID ambiguity:** mutating a generated definition while leaving its ID intact must fail package validation. IDs existing in a JSON set alone is not enough.

The retained frame-freeze, unit conversion and LIFO examples remain illustrative plan tests, not engine benchmarks or production implementation.

## Risks still requiring real evidence

1. **Runtime terrain + appearance:** the same packaged candidate must accept post-build terrain data, edit it, render approved hybrid appearance/overlays, provide correct picking and reopen offline. Dynamic Mesh documentation does not grant Nanite/Lumen or certify maximum footprint performance. No silent prebuilt-only or high-end-only fallback.
2. **Coordinates/LOD/resources:** corners, seams, close-camera picks, cm/m and winding conversions, local tile IO, upload/undo/collision working sets and cold shader cost need measured limits. A 2–10 km target is not certified support.
3. **State safety:** blueprint/game-save transactions, Open/Closed in-flight handling, idempotent Build, canonical/derived recovery, revision-fenced workers and corrupted package rejection require actual native tests.
4. **Individual time:** F6 resolves direction but not exact clock math. The concrete single-person/queue/day-boundary demonstration must precede production host code; later weather does not hold up the designer.
5. **Evidence/agents:** validate actual Sol/Terra routing, effective reviewer permissions including editor MCP, C++ dependency checks, nonempty failure-propagating tests, source/asset freeze, clean Shipping content and absence of debug listeners. User-only commits remain mandatory.

No independent reviewer, actual GPU lane or missing test becomes PASS by being deferred. An unavailable lower-end machine can leave that lane unqualified while reference-PC implementation proceeds.

## Required follow-up inputs

Only F1_GROUPING, F5_REVENUE, U5_REFERENCE, F12_HARDWARE and later F10_BACKEND remain. Exact questions and recommendations are in 09_FOCUSED_FOLLOW_UP.md. None blocks bounded P0. The first single-lift blueprint workflow need not wait for the multi-item choice.

## Actual checks and changes

DOCUMENT_CHECKS.json records the executed local checks and their limits; `python evidence/check_package.py` can reproduce them without network or engine access. MANIFEST.json validates delivered bytes. The old ZIP and original answer text are unchanged, and the latest answer text is a direct paragraph extraction with a DOCX hash. No original Google Doc, repo, user data, engine/config installation or commit was changed. The planning files are a new derivative.
