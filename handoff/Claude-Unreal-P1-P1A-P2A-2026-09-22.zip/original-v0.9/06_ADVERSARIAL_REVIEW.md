# Independent adversarial review protocol — Unreal

The original request requires fresh Terra High adversarial agents to challenge decisions and work, coordinated and reconciled by Sol High. Astra is exceptional high-level escalation only, not the standing reviewer. Actual independent sessions are required in Codex; this package's self-review is not their substitute. Every accepted architecture decision has a challenger, every implementation change a non-author reviewer and every milestone an integration review. Report actual session/model/effort/permissions and blocked tools.

## Four focused assignments

1. Product/runtime terrain/visual feasibility: can a new mountain be imported and edited in the same packaged representation that produces the accepted appearance? Challenge Nanite/Lumen/World Partition/experimental/API assumptions and source/quality tradeoffs.
2. Core/simulation/geometry: prove no Actor/Blueprint time/state authority; challenge meters-centimeters/handedness, F6 event clocks, weighted service, route topology and stale analysis.
3. Construction/persistence/UI: challenge blueprint-vs-built leakage, Undo overlap, canonical-vs-derived recovery, UMG/editor leakage, old/new save generation, offline content/cook dependencies and stale callbacks.
4. Execution/performance/security: challenge binary asset ownership, dirty editor state, source freeze, compiler/cook/test failure propagation, shader/PSO hitches, model routing and MCP bypass of read-only permissions.

At most two reviewers concurrently; no recursive spawning. Give relevant original owner answers, current plan/contracts and source references BEFORE showing the self-review findings. Return independent first-pass reports, then compare with R01–R10/ER01–ER08 and the Unreal self-review. Unknowns stay unknown; a handled gated risk is not automatically a new defect. Do not fill quotas with generic concerns.

## Finding format

ID; severity; exact file/section/line; observed contradiction vs unmeasured conditional risk; concrete failure scenario; smallest correction or test; affected phase; owner decision needed; evidence; actual runtime/model limitations. A finding with no cited premise must be qualified rather than stated as fact.

High-severity issues block affected dependent work, not unrelated bootstrap. Resolve disagreements through references or bounded tests, not consensus voting. Use one focused follow-up per material dispute; escalate unresolved product choices to the owner. Do not infer F/U approval from the phrase “address the review.”

## Safety and execution

Reviewer cannot change source/config/assets or invoke a writable editor tool. Experiments needing writes run only in authorized scratch/output space by a separate executor. Frozen source/input identity includes binary asset state and all content needed for cook. Any repair changes the version under review; obtain a new receipt. No commits, branches, worktrees, global settings, installations or publishing.

An Unreal integration and a requested Terra model are not exposed in this planning environment. Independent execution is therefore NOT_EXECUTED here. [independent-review/START_HERE_CODEX.md](independent-review/START_HERE_CODEX.md) is the actual read-only handoff, not a fabricated completed panel.
