# Phase / section acceptance receipt

Scope and owner authorization:
Source/base SHA plus complete uncommitted/new-file/asset input manifest:
Engine exact patch/build/toolchain; plugins/build configs; runtime RHI/quality/resolutions:
Canonical content and fixture hashes:
Build/cook/package executable and outputs identity:
Freeze start/end and editor dirty-package status:

## Evidence

Required test-case IDs: actual command, exit status, nonzero discovered/executed cases, pass/fail/skip, artifact paths. Separate pure C++ / Automation / PIE / packaged Development / Shipping / GPU / live-provider results. Any source mutation invalidates the receipt. Unavailable/unsupported lanes remain BLOCKED or UNQUALIFIED.

For visual gates, identify same editable runtime representation, camera/lighting conditions, owner approval and any comparison limitations. For performance, record entire window incl start/end/max gaps, actual active/rendered workload, achieved sim speed, cold shader/PSO distinction and measured/unknown CPU/GPU memory. Reopen includes required terrain/query readiness.

Independent reviewer identities and actual permissions/routing:
Open decisions, failed/blocked checks, justified deferrals:
Owner acceptance and USER-made commit identity (only after actual user action):
Proposed next bounded section; no automatic execution:


## v0.9 decision/evidence guard

Read current DECISION_STATUS.json. Sol High coordinates; Terra High implements and independently challenges; Astra only for exceptional high-level consultation. Explicit-only saved construction plans, Closed new infrastructure, estimates-only costs, individual-first/weighted-deferral and accepted visual/footprint/load direction are settled. Do not re-ask them. Distinguish accepted direction from concrete clock-demo approval and measured hardware. Use TEST_CASES.json meanings; report covered assertions and deferred assertions, not a blanket PASS for a case only partially exercised. User alone stages/commits.
