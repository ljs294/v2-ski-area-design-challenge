# Fresh non-author review

Reviewed frozen identity and applicable owner/ADR scope:
Actual reviewer session/model/effort and effective access evidence:
Filesystem and editor/MCP/connector write routes disabled or isolated:

First pass independent of the author's self-review. Cite exact source/plan lines, distinguish observed defect versus conditional risk versus open product decision. Do not fill a quota. For each actionable finding give failure case, severity, smallest correction/test and affected gate. A feature correctly deferred is not a missing implemented requirement.

Run only permitted read checks. Write-producing experiments require separately approved scratch execution; never repair the reviewed source. After changes, review a new frozen identity. Verify cook/API/runtime assumptions for terrain; don't accept a static showcase as editable-player proof. Check stable identities, canonical versus derived state, units, shader/PSO first use, resource bounds and source-freeze integrity.

Return findings, tests actually seen/executed, unknowns, approval/block status for this scope, and after-review identity. Separate sessions do not guarantee statistical independence. A missing route/permission receipt cannot be made up. No staging/commits/publishing.


## v0.9 decision/evidence guard

Read current DECISION_STATUS.json. Sol High coordinates; Terra High implements and independently challenges; Astra only for exceptional high-level consultation. Explicit-only saved construction plans, Closed new infrastructure, estimates-only costs, individual-first/weighted-deferral and accepted visual/footprint/load direction are settled. Do not re-ask them. Distinguish accepted direction from concrete clock-demo approval and measured hardware. Use TEST_CASES.json meanings; report covered assertions and deferred assertions, not a blanket PASS for a case only partially exercised. User alone stages/commits.
