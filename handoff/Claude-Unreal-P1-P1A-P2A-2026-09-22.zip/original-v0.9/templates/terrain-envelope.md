# Terrain and visual envelope — candidate, not support guarantee

Terrain backend/component/plugin and exact release/experimental status:
Runtime create/import/edit/query/collision capabilities actually proven:
Unsupported Nanite/Lumen/LOD/distance-field/raytrace features; source evidence:
Same packaged representation identity for visual AND editing proof:

Footprint/bounds/origin/datum/source spacing; standard/high source quality:
Native/local/package source bytes and cache schema/generator hash:
Tile dimensions/LOD rules/resident limits/border normals; canonical query and error tolerance:
CPU managed/native/heap staging/undo ceilings; GPU memory/upload limits (unknown metrics marked unknown):
Collision representation/version/cook budget or explicit canonical-ray alternative:
Cold/warm loads, first-grade, PSO/shader state, camera path and visibility:
Hardware/RHI/output+internal resolution/quality/AA/frame generation settings:
Near/far/midday/low-angle/overcast appearance, dot/overlay legibility:
Peak actual measurements, unsupported combinations and visible fallback policy:
New source package created after executable build and offline reopen evidence:
Owner U1/U2/U3 and F7/F8/F12/F13 status; non-author review:


## v0.9 decision/evidence guard

Read current DECISION_STATUS.json. Sol High coordinates; Terra High implements and independently challenges; Astra only for exceptional high-level consultation. Explicit-only saved construction plans, Closed new infrastructure, estimates-only costs, individual-first/weighted-deferral and accepted visual/footprint/load direction are settled. Do not re-ask them. Distinguish accepted direction from concrete clock-demo approval and measured hardware. Use TEST_CASES.json meanings; report covered assertions and deferred assertions, not a blanket PASS for a case only partially exercised. User alone stages/commits.
