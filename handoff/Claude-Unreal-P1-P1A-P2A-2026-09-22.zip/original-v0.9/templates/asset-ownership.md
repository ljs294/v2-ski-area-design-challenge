# Binary asset and editor-action task

Exact map/material/widget/Blueprint asset paths:
Owner and exclusivity window:
Required plugin/toolchain/runtime or editor-only status:
Current disk hash + dirty-editor state + owner manual modifications:
Authorized properties/links to change; generated versus hand-authored boundaries:
Idempotent recipe and second-run behavior; no broad erase/recreate:
Preview/save policy (owned assets only), failure/restore/cancel handling:
Property/relationship diff and viewport/runtime evidence:
Cook reachability, packaged runtime test and output identity:

Do not raw edit .uasset/.umap or move them outside editor asset APIs. A Blueprint presentation asset is not the player's ProposedPlan. Editor automation/MCP is not a blanket permission to mutate the entire project. Reviewer tools must remain read-only independently of shell sandbox.
