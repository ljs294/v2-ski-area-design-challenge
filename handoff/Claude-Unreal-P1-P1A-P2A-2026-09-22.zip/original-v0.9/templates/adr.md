# ADR UE-__ : decision title

Status: PROPOSED / SPIKE / ACCEPTED PRODUCT / ACCEPTED TECHNICAL / SUPERSEDED
Owner question/authorization; affected sections; source identity and evidence date:
Problem, exact user outcome, alternatives, required runtime capability, cost/maintenance/security consequences:
Chosen option and scope; explicit unknowns; evidence that would falsify it; rollback/exit:
Dependencies, validation cases and exact acceptance measurement:
Actual non-author challenger and reconciliation:

An Epic API/editor feature is not a measured runtime proof. Do not mark accepted technical solely because the owner selected Unreal. Do not silently change low-end hardware, arbitrary mountain selection, grading, current art scope or manual-only saves.
