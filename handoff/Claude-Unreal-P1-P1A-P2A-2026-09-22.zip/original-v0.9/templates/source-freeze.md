# Source and editor freeze receipt

Authorized coordinator/output path; project path; active writer/asset ownership list:
Stop source writers, editor saves/scripts, LiveCoding and writable MCP sessions. Save only owned dirty packages explicitly included in this task. Unrelated unsaved owner content cannot be silently saved/discarded. Use an authorized frozen scratch snapshot if appropriate.

Include all relevant tracked/untracked code, .uproject/.uplugin/Build.cs/Target.cs/config, assets and generated INPUTS in a length/hash manifest. Record engine/toolchain/plugin identities and source control base/dirty status without staging. Exclude outputs/caches using explicit rules; identify cooked output separately.

Capture before build/test/review and compare after and at acceptance. Test deliberate mutation in a disposable control: either prevent it or invalidate evidence. One process is not source locking. Close receipt before writers resume. Later changes require new relevant tests/review; never reset user changes to make identity match.
