# P4.0 joint event-clock and population contract

Owner F5/F6A/F6B answers; retained source rate mapping and proposed intentional differences:
Per event: admission, ticket recognition, lift seat/service, queue entry/release, travel completion, opening/closing, departure, optional environment step -> authoritative clock, input/output units, conversion, ordering, speed switch, checkpoint fields.

Actual individuals versus visual representatives and aggregate authority:
Active cap versus daily arrival demand; overflow/wait/rejection policy (no disappearing people):
Weighted included or owner-approved deferred:
If included: integer/fractional weights, partial seats, residual FIFO, wait metrics, route-choice approximation, day carryover, restore behavior.

Tiny one-lift/one-trail fixture at each included speed, one person/short queue/time boundary, save/restore and stale control response:
Revenue once per approved visit in integer cents; no hidden budget/amenities:
Actual source/fixture result and fresh independent review:

No headless production host/lifecycle implementation before this decision. No completed simulation required to begin P1 terrain.


## v0.9 decision/evidence guard

Read current DECISION_STATUS.json. Sol High coordinates; Terra High implements and independently challenges; Astra only for exceptional high-level consultation. Explicit-only saved construction plans, Closed new infrastructure, estimates-only costs, individual-first/weighted-deferral and accepted visual/footprint/load direction are settled. Do not re-ask them. Distinguish accepted direction from concrete clock-demo approval and measured hardware. Use TEST_CASES.json meanings; report covered assertions and deferred assertions, not a blanket PASS for a case only partially exercised. User alone stages/commits.
