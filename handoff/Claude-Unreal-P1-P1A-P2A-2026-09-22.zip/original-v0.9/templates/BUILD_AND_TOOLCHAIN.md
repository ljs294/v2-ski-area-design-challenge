# Build/test loop to establish in P0 (not a ready-built Unreal project)

Pin installed UE5.8 patch, supported MSVC/Windows SDK and plugin versions using Epic's matching documentation. VS Code is an editing client, not a replacement for C++ build tools. Do not require a source-engine fork or global installation merely because an optional target is absent.

Create minimal named Runtime modules for the pure-domain shim, application and presentation plus a separate Editor module. Pure canonical sources have a single explicit file manifest reused by UBT and standalone C++ tests. Module registration imports may reference minimal UE infrastructure only outside that manifest. Deliberate direct/transitive UE include controls must fail pure compilation. Audit public/private link dependencies; do not rely on a directory name or search-only lint.

Specify user-invokable wrappers for pure tests, native build/cook/package, relevant Automation/functional checks and a packaged smoke. The implementing task supplies tested executable paths and commands from the installed version; this planning template does not pretend placeholders ran. Fail on failed/zero/timeout tests and parse actual native automation/cook results. Never treat only a process exit or editor launch as successful tests.

Use a launcher build first; a small standalone compatible C++ runner can test the same core without requiring full engine compilation. LLT/Catch2 availability must be checked rather than assumed. Automation and packaged runtime tests remain necessary. No external test program may become a second different implementation.

Cook required material/shader families, UMG/sky/approved assets and stage approved helper/browser dependencies. Test Development diagnostics and Shipping functionality separately. No source-only editor dependency, uncompiled user material graph, unsupplied helper runtime or optional MCP service in release. Qualify from frozen source and normal clean build, not LiveCoding state. Record cold/warm PSO usage explicitly.
