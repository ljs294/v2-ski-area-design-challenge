# Codex configuration reconciliation — current F11

`config.sol-high.toml.example` is the sole active parent-profile proposal: Sol High coordinates; Terra High implements and performs fresh adversarial review. Astra is a separate rare high-level consultation, never a default root session or required per-phase reviewer. The former alternative parents exist only inside historical archives.

These model IDs/fields are template candidates, not proof of your account/client availability. Read installed project/user configuration and current documentation; verify effective model/effort and sandbox after inheritance/overrides. Never silently fall back, invent a `high_high` value or overwrite working settings. Current docs reference: E21/V08-O1 in 08_SOURCES.md.

A scoped authorization is required before installation/configuration edits. Preserve existing tools and permission restrictions. Child workers must not recursively spawn. At most two implementers plus one reviewer; architecture review batches at most two. One editor/build owner. Review mode needs filesystem AND editor/MCP/connector read-only restrictions. A config parser succeeding is not routing or security validation.

Do not expose an Unreal automation listener in Shipping. Do not use a GitHub write tool to evade the user-only commit policy. Keep normal work scoped to the named section, then return for user acceptance and commit.
