# Unreal replacement — canonical repository agent guide (proposed)

Apply only to `ljs294/v2-ski-area-design-challenge` through an authorized instruction-reconciliation task. Preserve higher-priority and unrelated existing requirements. Root CLAUDE.md contains only `@AGENTS.md`; pair any scoped guide with its same-directory import. This template is not evidence the repository has changed.

## Authority and scope

Read the current owner answers, active section and applicable decisions under the accepted `Docs/UnrealRebuild/` plan location (or the explicitly identified current v0.9 package before installation). Engine is Unreal. Original application is a read-only reference in its own repository, never a parallel maintenance target. Only terrain is modeled3D in present scope; dot guests, line/footprint infrastructure, lift/trail/node design and viewer, same-window mountain preparation, offline gameplay, blueprint costs, pause-on-Build/manual resume, trail grading, manual save, selected early snowmaking layout and simple guest/ticket loop. Weather later. No speculative operational snowmaking, character/tree/building art, full economy, autosave, multiplayer or cloud features.

User owns staging, commits, amend/tag/branch/push/merge/rebase/reset, release and worktree decisions. Never perform those actions or use connector writes to circumvent them. Never delete or overwrite unrelated owner work. Implement only the active predefined task with allowed files, source dependencies, tests and non-goals. Stop/escalate out-of-scope changes or undecided product gates. No automatic next section. Latest decisions are in DECISION_STATUS.json; F1_BUILDINGS is the only product clarification; do not reopen grouping, revenue, Crystal Mountain, weather translation or laptop availability. Paid plugins, source-engine builds/forks, installed/global tools, permissions and public releases need explicit authorization.

## Code and data boundaries

Canonical models, algorithms and engine-independent C++ sources do not include or transitively rely on Unreal headers, UObject, Actors, engine containers or reflected Blueprint data. Module registration/bootstrap is an explicitly separate thin adapter, not part of the pure source set. Same pure sources must compile in a small standalone test target. UE module loading success alone is not proof. Do not copy separate test implementations.

UE components/UMG/Blueprint assets are lifetime/presentation/input adapters. Canonical guest/entity identity persists when views are rebuilt, hidden or unloaded. No per-guest Actor/Tick/AIController design by default. Do not indiscriminately ban useful tick/lifecycle code; prohibit authoritative simulation depending on render cadence and profile actual hot work.

Game construction blueprints are ProposedPlan DATA, not Unreal Blueprint asset graphs. F1 requires separate explicit Save Blueprint / Load Blueprint; ordinary Save Game excludes working plans. The first lift slice implements these small controls. Load Blueprint never builds, changes clocks/tickets or resets committed undo. Follow BLUEPRINT_LIBRARY.md for dirty prompts, independent generations, stale bindings, ID remapping and plan-library reference protection. Keep gesture/proposal/built state separate from the first lift slice; live simulation sees built state only. Common Build: acknowledged pause -> validated canonical staging/commit -> derived mesh/query/collision/index synchronization -> remain paused. Failures after canonical commit retry derived reconstruction, not Build; no duplicate operation or premature Play. One cross-tool committed LIFO history; tool-local uncommitted gestures; never implicitly rewind business time/revenue.

F3 new infrastructure is Closed; operating eligibility differs from built existence and rendered visibility. Validate before Open, prevent unsafe Close/Delete with live references, preserve in-flight geometry and manual Play. F6 current operation is individual-only with a bounded active-cap/pending-arrival contract, no hidden weighted cohort. Construction costs are estimates, not a cash ledger. Canonical geographic/local geometry is explicit double ENU meters. Unreal projection uses north/east/up centimeters; subtract origin before conversion; test inverse/triangle winding/raster conventions. Camera and engine transforms are not save authority. Base earth, grading and numerical snow are separate.

P1 must prove one packaged runtime terrain representation supports new data, required visual quality, bounded height changes, queries and offline reopen. Dynamic Mesh has documented Nanite/Lumen limits; do not claim those features from the engine name. No editor cooking or uncooked uasset assumption for player packages. Expensive analysis gets bounded/revisioned triggers, not unbounded hot-loop solves. F4 limited layout is accepted; no hydraulic/pump work is commissioned. F6 true individual authority and weighted deferral are accepted; the concrete clock demo must pass P4.0 before production host code.

## Assets, tools and source identity

Assign one owner to each .uasset/.umap, shared module/uproject/config and cook dependency. Do not raw-edit binary assets, rename them in the filesystem or bulk-regenerate an owned manual asset to make a script pass. Use scoped editor APIs; save only allowed assets. Capture asset properties/relationships and reproducible setup evidence. Editor Python is not gameplay Python.

Unreal MCP is optional/Experimental. Verify actual tools, process ownership, bind/auth and permissions before use. Review sessions cannot have mutation tools through MCP/HTTP/connector routes even when their shell is read-only. No unreviewed listener/toolset in Shipping; runtime-capable modules need explicit exclusion. No arbitrary editor code execution outside a named task.

Before qualifying tests/build/review, quiesce ALL source, asset, editor and LiveCoding/MCP writers. Handle only owned dirty packages, capture complete saved input identity incl untracked/source/plugin/cook inputs, and compare before/after/acceptance. A changed input invalidates evidence. One editor/build process alone is not a lock. No commit is needed to identify uncommitted changes.

## Agent separation and verification

Accepted F11: **Sol High owns all routine delegation, section coordination and coordinating review. Terra High owns all actual implementation and fresh adversarial review. Astra is used very sparingly for high-level decisions only.** No default Astra parent or mandatory phase-gate Astra invocation. Sol synthesis never substitutes for fresh Terra review. Verify actual local model/effort routing and report unknowns. Max two implementers plus one reviewer, with a single integrator; fewer for shared assets. No recursive worker spawning. Distinct sessions are non-author separation, not proof of correctness.

Reviewers are effectively read-only, return findings and never repair their target. Necessary write-producing experiments are separate scratch tasks. Use source facts and minimal counterexamples, not agreement voting. Missing Unreal/model/GPU capability is BLOCKED. Never invent independent review or claim a test passed because code appears plausible.

Tests: affected pure/unit and boundary failures per task, relevant engine/player workflows per section, selected integrated visual/performance story per milestone. No default full-season test. Native UBT/UHT/cook/packaged checks remain separate from pure tests and editor/PIE. LiveCoding is not clean-build evidence. Include cold shader/PSO use, frame start/end/max gaps and actual workload/liveness. Only measured hardware/quality is qualified.

Return changed files/assets, behavior, exact commands/results and frozen identity, real reviewer findings, blocked checks/remaining risks, and a suggested commit message. Leave user changes unstaged/uncommitted. User acceptance and user commit precede the next authorized section.

## Latest answer protections

A saved blueprint is a mixed multi-item pod, not one object. Preserve typed internal links, external anchors and building record data. No unsupported entry may be silently dropped or partially built; F1_BUILDINGS governs only whether simple building placement ships now. No 3D building art/amenities is inferred. Retain explicit separate plan saves.

Daily arrival input and fixed per-day ticket price are accepted; no demand response to price. Crystal Mountain WA is the visual reference. The approximately ten-year-old laptop is optional and unqualified pending actual inventory/testing; no hardware-age assumptions. Existing numerical weather behavior may be translated to another language; new dynamic weather/cloud effects are separate future scope. Trace backend identity at P6 and keep visuals non-authoritative.
