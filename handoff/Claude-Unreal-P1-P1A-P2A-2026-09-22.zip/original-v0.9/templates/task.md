# Bounded implementation task

ID / phase / assigned model / implementer / integrator / fresh reviewer:
Owner authorization (exact scope):
Baseline source and uncommitted-input identity:
Relevant O/Q/F/U/ADR and test-case IDs:

## Outcome

One observable player/developer workflow, with explicit current-state behavior and desired change. Name the source reference or new approved behavior. A package of classes alone is not delivery.

## Allowed writes and shared ownership

Exact source/config paths; exact uasset/umap paths and editor operations; output/scratch directories; locks. Identify prohibited original-repo, owner/cloud/data/config areas. No commits/staging/worktrees/paid dependency/permissions change. Show how existing dirty/manual assets are protected.

## Contracts / dependencies

Canonical inputs/outputs and units, stable IDs/revisions, preview versus built state, error/cancel/retry, save, undo, module/runtime/editor boundary, cook/runtime content dependencies and source freeze. Required owner decisions are recorded BEFORE dependent code. Declare any view/thread/collision/LOD assumption.

## Non-goals

Explicitly excluded features and tempting unrelated refactors. No speculative full simulation or engine fork.

## Execution and verification

Small steps and bounded work budget. Every costly analysis has trigger, measurement, invalidation and failure handling. Every editor script has idempotence/ownership checks. Specify pure checks, negative controls, engine/package tests, visual demonstration and actual hardware needed. Describe BLOCKED path; unavailable test is not PASS. Qualifying source must remain frozen, incl editor and MCP.

## Return

Actual diff/new-file/asset hashes; commands/statuses/nonzero test counts; diagnostic output; images/property diffs as applicable; fresh read-only review of this same identity; unresolved risks; suggested USER commit message. No automatic next task.


## v0.9 decision/evidence guard

Read current DECISION_STATUS.json. Sol High coordinates; Terra High implements and independently challenges; Astra only for exceptional high-level consultation. Explicit-only saved construction plans, Closed new infrastructure, estimates-only costs, individual-first/weighted-deferral and accepted visual/footprint/load direction are settled. Do not re-ask them. Distinguish accepted direction from concrete clock-demo approval and measured hardware. Use TEST_CASES.json meanings; report covered assertions and deferred assertions, not a blanket PASS for a case only partially exercised. User alone stages/commits.
