# Master plan — Unreal replacement v0.9

**Owner-selected engine:** Unreal. **Technical baseline proposal:** a tested released Unreal Engine 5.8 patch, pinned with its plugin/toolchain versions in P0. Recheck actual installation; do not claim a patch is tested from documentation alone. [E01]

## 1. Product contract and order of authority

The latest [five direct owner answers](sources/OWNER_FINAL_ANSWERS.md) override older recommendations. Preserve the [questionnaire answers](sources/OWNER_FOLLOW_UP_RESPONSES.md), [forty original answers](sources/OWNER_RESPONSES.md), and [engine decision](sources/OWNER_ENGINE_CHANGE.md). DECISION_STATUS.json distinguishes approved product direction, the single building-tool clarification, and technical gates. This is a consolidated planning handoff, not certification of a built game.

Build one Windows single-player Unreal application in the v2 repository, replacing the previous application. The original game remains in its own repository and is a read-only behavioral reference, not a parallel maintenance target. No old game-save importer is required.

Deliver a small bounded open-world resort designer: player-selected real terrain, a fixed chosen boundary, recognizable compact UI, lift/trail/node tools and node-map viewer, blueprint cost preview while operation continues, pause-on-Build with manual resume, trail grading, manual saving, early selected snowmaking layout, and a basic dot-guest/ticket loop. No network streaming during gameplay. A saved designer is an intermediate usable milestone; the selected scope also includes a later basic operating build. [O: Q1/Q3/Q5/Q6/Q11/Q16/Q17/Q23/Q29/Q36]

The recent environment discussion makes a compelling mountain presentation a first-class acceptance gate, not an optional final polish exercise. It does not by itself repeal the terrain-only 3D scope: no modeled buildings, chairs, people, trees or rocks are commissioned. Surface materials, lighting, sky/atmosphere and terrain geometry provide the current visual treatment. A decorative mesh expansion requires an explicit scope change. U1–U3 now approve hybrid naturalistic terrain with clean readable overlays, overview/moderately close cameras, and judging the actual playable result rather than specific renderer features. No ground-level walking/skiing or modeled-object expansion is implied. [O: Q9/Q20/Q27; current instruction]

Weather integration is later core. Physical snow height, operating snowmaking/grooming, amenities/full economics, patrol, vehicles, lodging, multiplayer, cloud accounts, autosave, and land unlocking remain deferred or excluded. Future possibilities must not become speculative infrastructure in P0.

## 2. Recommended stack and limits

| Area | Proposed choice | Acceptance condition |
|---|---|---|
| Engine | Released UE 5.8 patch, launcher/binary installation first | Exact patch/MSVC/SDK/plugins locked, native build/cook and blank packaged player pass; no automatic engine fork |
| Code | C++ foundation; minimal Blueprints for presentation composition and asset configuration | Pure domain compiles without UObject/Engine/editor headers; BP graphs hold no simulation authority |
| Runtime terrain | Bounded C++ heightfield-tile data pipeline; initially evaluate Geometry Framework `UDynamicMeshComponent` | Same packaged implementation passes runtime import, update, picking, visual and resource gates; component is not preapproved for final rendering |
| Lighting | Deferred rendering candidate; quality-tiered dynamic sun/sky, terrain materials, atmospheric depth; Lumen conditional | Actual runtime terrain participates correctly in the selected lighting/shadow path; no presumed Nanite/Lumen compatibility |
| RHI | DX12 candidate for the high-quality lane; verify exact hardware/features and optional DX11 fallback separately | Neither a lower-end nor a high-end lane is certified by the other; report internal/output resolution and upscaling |
| UI | UMG with C++ presenters and event-driven updates; custom runtime Slate/UMG node-map widget | Docking/window flow, focus, DPI, tool ownership, graph selection and packaged operation pass; no editor GraphEditor dependency |
| Input | Enhanced Input with explicit UI/camera/tool contexts | Modal Escape, pointer capture, focus loss and blueprint planning do not affect built state |
| Simulation | Plain C++ models, explicit scheduler/clock contract, bounded task execution | P4.0 confirms remaining accepted F5 revenue behavior and demonstrates the accepted individual/dual-clock direction before host/lifecycle code; weighting is deferred |
| Guest display | Batched camera-facing dots with stable IDs and a CPU picking index | 3,000-dot presentation probe followed by actual integrated simulation; no Actor/AIController/physics body per person by default |
| Geometry/analysis | Port selected tested calculations behind adapters; C++ libraries only after version/license/semantics check | No blanket new hydraulics/catenary engine, unbounded per-frame solves, or unvalidated approximation |
| Persistence | Explicit versioned records + checksummed binary terrain/grading/simulation assets | Separate Save Game and explicit Save Blueprint/Load Blueprint, coherent independent generations and interruption recovery; no Actor graph authority |
| Selection | Existing MapLibre selector in Unreal `UWebBrowser` host candidate | Packaged WebGL/assets/DPI/message/security/lifecycle proof; WebView2/native alternatives only after evidence |
| Preparation | Reuse selected TS/Python acquisition/processing tools with an explicit bundled local host | Complete pipeline works without editor, development server or separately installed Node/Python on player PC |
| Tests | Tiny standalone same-source C++ tests first; Unreal Automation/functional/player checks; LLT/Catch2 if available and useful | Demonstrate failing tests/dependency controls propagate; no source-engine build only to obtain a test framework |
| Profiling | Unreal Insights and packaged frame/GPU/streaming/shader measurements | Stable source/cooked content identity, live workload, short focused trials, unknown metrics labeled |

Epic documents C++/Blueprint tradeoffs, module separation and test tools; these recommendations select an approach for this project rather than a universal engine prescription. [E04/E05/E06/E10/E11/E14]

## 3. Repository and C++ ownership

Proposed layout:

```text
SkiAreaDesignChallenge.uproject
Source/
  SkiDomain/                 # pure model/algorithms plus an isolated registration shim
  SkiApplication/            # commands, sessions, package/save and host adapters
  SkiPresentation/           # runtime terrain/input/UI/guest views
  SkiEditor/                 # editor-only setup, validation and asset recipes
Content/                     # small authored maps/material/UI assets
Config/                      # reviewed defaults and quality profiles
Plugins/                     # explicitly approved project plugins only
Tests/Domain/                # compiles the SAME pure domain sources, not a second engine
Tools/Preparation/           # extracted local provider/processing pipeline
Tools/Build/                 # reproducible compile/cook/test helpers
Fixtures/                    # small legal fixtures and manifests
Docs/UnrealRebuild/           # accepted plan, decisions and evidence
```

Keep Unreal module count small. Do not create a module for every feature. An isolated module registration/export shim may use UE Core; the pure source set contains no UObject, Actor, engine container, reflection macro, gameplay global or Blueprint dependency. The standalone no-engine build is the enforcement surface; the UBT module and the standalone tests compile the same implementation. Audit includes and linked/dependency closure, not a keyword-only guarantee. P0 chooses the simplest working linkage/export arrangement and documents compiler settings; no opaque prebuilt domain DLL is assumed. Unreal uses Build.cs/Target.cs for build rules, not generated IDE solution edits. [E05]

Only the user stages/commits. Agents may edit only an authorized bounded task. Enumerate obsolete entrypoints/workflows and map provider/worker/storage dependencies before retirement. Preserve required extracted files until the replacement preparation pipeline works; this is not a reason to keep a second gameplay application. Do not erase or move unrelated local work, the original repo, saved games or downloaded packages.

## 4. Runtime terrain and visual fidelity are ONE gate

The player chooses an arbitrary supported mountain after the game is packaged. A cooked developer-authored level is not equivalent. This requirement survives the engine change. [O: Q5/Q19/Q23]

Unreal Landscape/Nanite and Mesh Terrain have useful editor/build pipelines, but those pipelines do not establish arbitrary user-time authoring. Epic labels Mesh Terrain Experimental and distinguishes editor preview from compiled runtime sections. Dynamic Mesh supports runtime modification but is documented without Nanite/Lumen, built-in LOD, mesh distance fields or instanced rendering. Use Geometry Framework C++ directly where adequate; do not assume the entire Geometry Scripting plugin is needed. [E02/E03/E07]

P1 therefore first builds a narrow candidate using runtime-generated bounded heightfield tiles with pre-cooked material families. Test a new package created AFTER the executable was built. Then test controlled height updates, seams, slopes, own terrain queries, optional collision refresh, materials/shadows/atmosphere, camera travel, memory and offline reopening in that SAME player. A diagnostic editor Landscape can be a labeled appearance reference only; it cannot substitute for the runtime candidate.

**The initial candidate is not a guarantee of the high-end visual promise.** No automatic Nanite conversion, runtime distance-field build, Lumen participation, or material-graph compilation is assumed. Build a capability matrix per representation, not just per engine. If the first candidate fails visual or scale acceptance, commission one targeted alternative: a verified runtime mesh component/plugin, an explicitly supported runtime Landscape path, or a bounded project renderer. Each needs packaged evidence and a maintenance/license assessment. Do not silently switch to prebuilt maps, require the editor on player machines, buy a plugin, or create a remote cooking service. Escalate with evidence under accepted U3/U4: appearance is the gate, free/built-in first, and no purchase/source fork without item-specific permission. Do not spend indefinitely on a custom terrain framework.

Use a fixed bounded map first; no World Partition mandate merely because the world is open. Project-owned local-disk tile residency can be independent of World Partition. Camera visibility controls presentation—not simulation, persistent IDs or people. Do not make runtime-generated tile identity depend on editor-authored partition cells. [E09]

## 5. Geography, terrain truth and resource budgets

Canonical geometry uses double-precision local **east/north/up meters**, with documented source CRS/datum and near-center origin. Proposed Unreal adapter is **X=north, Y=east, Z=up, in centimeters**. Subtract origin in double before local/tile float conversions; multiply linear distances by 100 exactly once at the boundary. Areas/volumes remain m²/m³ in rules and costs. Validate swapped axes, sign/handedness, winding, normals, UV direction, headings and inverse round-trips. Do not carry over a previous engine's axis or one-unit-equals-one-meter convention. UE's LWC improves precision support but does not eliminate shader/physics/quantization error. [E12/E13]

Immutable source elevation, authored grading, and numerical snow are separate. A renderer mesh or Actor is never the geographic database. Build/query sampling specifies cell-vs-vertex convention, interpolation/triangle split, nodata, bounds, neighboring samples and actual source error. High-resolution source data is not forced into every analysis/display grid. Upsampling is not newly measured topography; a DEM still cannot describe true overhangs absent from its data.

Tiled LOD is a deliverable with a bounded first implementation—not a claim that Dynamic Mesh supplies it. Select finite measured resolutions, shared-border rules, bounded neighbor LOD difference and crack treatment; prove switch/pick alignment. Compute normals consistently across tile borders. Keep limited CPU staging/undo buffers, decoded/resident tiles, IO queue length, GPU updates and collision/query rebuilds. Vertex/index generation may use bounded background work on plain data; UObject/component commits occur on the game thread.

Declare and measure the footprint/quality envelope in P1.7; recheck real grading in P2.4 and integrated operation in P5.2. A 10 km square at one-meter vertices has 100,020,001 samples (~400 MB per float32 channel); do not materialize full-domain copies for each tool. Cold IO and shader/PSO first-use work are distinct from warmed gameplay and must be reported. No unsupported memory metric is zero. F7/F8 approve the target footprint/quality choices; F12 approves the candidate acceptance approach, not a tested machine. Record measured supported combinations; small experiments do not certify maxima.

## 6. Visual environment and quality lanes

P1.2/P1.7 include the intended appearance—not a checkerboard deferred to final polish. Use source-aware terrain forms, snow/rock/ground material variation, slope/altitude masks, controlled sun/sky, atmosphere and fog where supported. Avoid decorative geometry until explicitly scoped. Visual presets are art controls before weather integration, not claims of a location-calibrated weather model.

Compare clear midday, low-angle light and overcast art presets using identical terrain/camera paths. Inspect gameplay readability: blueprint/trail overlays, contours and dots must remain legible on snow and dark rock, including under temporal antialiasing and upscaling. Report visual differences at actual output/internal resolutions. Screenshots or Movie Render Queue output cannot certify an interactive player.

Preserve 30-FPS minimum / 60-target intent. A lower-quality path may omit advanced GI/cloud/shadow effects only transparently under accepted F12/U3, with owner visual approval; it must retain the same terrain topology and game rules. High quality may enable Lumen/Nanite only on actually supported representations and qualified hardware. Epic scalability targets are not this game's measured frame rate. [E08]

Cook a bounded set of material/shader permutations and required textures/UI/sky ahead of distribution. Newly downloaded terrain supplies data and runtime parameters, not uncooked materials. Handle PSO first-use/precache readiness and include cold first-run checks; never hide an unexpected hitch by calling it loading after the fact. [E15/E16]

## 7. Setup, offline content and security

P1.4 evaluates the existing selector in Unreal's browser widget. Runtime WebGL, local bundle delivery, provider requests, GPU backend, input, clipping, resizing and release packaging are unproven until tested. The widget API alone is not proof of MapLibre compatibility. [E17]

Keep a narrow origin-checked, schema-checked bridge with bounded boundary/options messages. No general eval/file/command proxy, raw credentials or huge arrays through JS messages. Restrict navigation and untrusted content. A local helper returns a validated package identifier, not arbitrary filesystem authority. Cancel/retry includes request generation fencing across download, decode, storage and activation. Terminate only owned helper processes; explicitly close browser resources at gameplay entry and verify cleanup.

P1.5–P1.8 own extraction, provider fixture/live checks, real metadata, portable writer, native validator, staging, activation and offline reopen. Required failures prevent activation; unavailable optional data is labeled and explicitly handled. Bundle any required helper runtime and dependencies; Epic's editor Python is NOT a player-runtime Python environment. [E18] Do not depend on an end user's installed editor, Node/Python, development server or cook-on-the-fly service. P1 proves reopening an installed terrain package; P2 adds authored-save reopening.

Packages are versioned non-executable data. Reject path traversal, oversized dimensions/decompression, invalid numeric values/hashes, duplicate conflicting IDs and unsupported schemas. Preserve source terms/attribution. Download and storage estimates use actual progress; ETA is a range where justified. Previously prepared saves bypass provider calls and expensive derivation. About five minutes is the standard-preparation reference; an explicitly selected high-detail option may take longer. Prepared-save <=30 seconds is now an accepted initial target on a declared standard fixture, not a universal or measured guarantee.

## 8. Construction, undo and derived readiness

The first lift slice is transient gesture -> working construction plan -> built document, with cost, explicit Save Blueprint/Load Blueprint, Build, inspection and separate manual Save Game/reopen. The first explicit single-item plan save is not postponed to P2.3. Only built infrastructure enters the live network. P2.2 adds trails/topology and a **runtime** node-map viewer via UMG/Slate; do not use editor-only GraphEditor/SGraphEditor, UnrealEd transactions or editor splines as runtime persistence.

Build state progression remains:

`PlanReady -> PauseRequested -> PausedValidated -> CanonicalStaging -> CanonicalCommitted -> DerivedSync -> PausedReady`

Session/operation IDs and expected plan/document revisions fence stale work. Before commit, failures preserve built state and proposal. After commit, a failed mesh/query/index update enters `PausedRecovery`: rebuild derived state from that committed revision, never repeat construction. No partial rollback, duplicate cost/grade, Play, new built mutation or normal save while required representations disagree. Keep inspection labeled; allow recovery retry or exit warning while preserving the previous durable save. Build is not autosave.

Revisioned projections include meshes, terrain queries/collision if used, graph caches, spatial indexes, hit registries and pooled views. Recreating or garbage-collecting an Actor/component cannot delete a guest or built entity. Callbacks carry stable IDs and generation, not a reused instance slot alone. Do not retain unsafe raw UObject pointers across asynchronous work.

Tool-local undo applies to draft gestures. One cross-tool last-in-first-out history reverses committed changes including graph/grading. No arbitrary selective historical undo. New committed edits clear redo; Load Game clears session history; Load Blueprint changes only working-plan history and never committed history; actual simulation progression seals earlier reversible history. Removing infrastructure after use is a current-state command, not time/revenue rewind. F1 requires explicit persistence of mixed multi-item trail-pod plans; its data may include lifts, trails, snowmaking and building plan records. Only the timing of building-placement tooling remains F1_BUILDINGS. F3 now requires Open/Closed states and initially Closed new infrastructure. The engineering closure policy below must be implemented before enabling changes.

### Explicit saved blueprints and operating states — owner F1/F3

Save Game, Save Blueprint and Load Blueprint are separate actions. A working plan is session-only until explicitly saved; normal Save Game excludes it and warns about unsaved plan edits without silently saving or discarding them. Save Blueprint atomically writes a named versioned construction-plan snapshot and can run while simulation continues using a coherent plan revision. Edits after that snapshot remain dirty. Load Blueprint restores proposed geometry only: no build, clock change, ticket event, operating-state change or reset of committed undo. A built result is not durable until Save Game.

Initial engineering default: plan records are bound to the prepared mountain and resort document, with validated references to existing anchors. Cross-mountain stamping/template placement is not commissioned. Old grading/cost/query caches are recomputed. Saved records are immutable generations; load creates a fresh working instance, not resurrected built IDs or operation tokens. Overwrites and dirty-plan replacement require explicit confirmation. P2.1 still proves one lift; P2.3 must extend the same model to a whole mixed trail pod, not a single-item-only format. Build All and Build Selected with displayed dependency closure are the minimal engineering UX default; do not add unselected dependencies silently. See [contracts/BLUEPRINT_LIBRARY.md](contracts/BLUEPRINT_LIBRARY.md).

Built topology and operational eligibility are distinct. The viewer labels proposed, built-closed and built-open elements; hiding a layer never closes a lift. New construction is Closed. Set Open/Closed is an acknowledged paused application command, not a renderer toggle. Engineering default: Close prevents new entries but honors existing in-flight geometry; reject a closure that would leave no safe completion/exit. Delete waits for no live journey/queue/anchor references. No teleport, forced evacuation, guest deletion or revenue rewind. Opening validates directed connectivity and the defined admission/exit policy. The game remains paused until manual Play; no automatic reopening on save/load. Small return/queue fixtures prove these rules.

## 9. Simulation, concurrency and analysis

P0 provides only a small pure core boundary. **P4.0 precedes P4.1/P4.2:** F6A selects genuinely individual people over strict preservation of incompatible old numeric mappings. Retain separate business/movement concepts and familiar controls. Sol scopes a concrete event-clock table and Terra builds a tiny one-guest/queue/day-boundary demo; obtain owner approval of any actual changed rates/semantics before the production host. F5 now approves player-set daily arrivals, one fixed daily ticket price, no price elasticity, and estimates-only construction. Engineering work specifies daily locking/re-entry and overflow behavior; do not re-ask that settled product direction.

Canonical simulation state lives in plain C++ objects with deterministic ordering, explicit RNG algorithm/state, integral currency and deliberate tolerances. An application session/UGameInstanceSubsystem adapter may own the host's lifetime; Actors, Tick, physics time dilation, render visibility and Blueprint variables are not authority. No mandatory Mass/GAS, Behavior Trees, NavMesh agents or Actor per guest. The existing directed ski/lift network remains the route authority.

One host mutates simulation state. Background tasks receive immutable/revisioned inputs; game-thread application publishes bounded snapshots. No worker dereferences live UObjects or edits assets. A session close/load invalidates pending completions and releases resources safely. Use RAII and bounded ownership; no detached unlimited work or blocking wait on the game thread. Render interpolation follows valid routes and never takes a straight shortcut through terrain.

F6B explicitly defers weighted guests beyond the first operating release. P4.3 now implements the individual capacity boundary, not weighted groups: about 3,000 ACTIVE people is a starting target, not a daily admission cap or certified throughput. Track requested arrivals as admitted, pending or visibly unadmitted; pending people are not simulated guests and earn no tickets. Final bounded overflow/day-end policy is documented at P4.0 with F5. No silent dropped demand, fractional people, hidden cohorts or unbounded backlog. Historical weighted partial-seat/FIFO/wait/checkpoint tests remain FUTURE, not current release gates. Construction costs are estimates only; no cash deduction, budget restriction or amenities. Ticket revenue remains current scope with the accepted F5 inputs. Pending/unadmitted people earn no tickets; retry/load cannot repeat an admission charge.

Approved expensive design analysis is triggered by changed relevant inputs or explicit request—not each Tick. Cache by session/design/terrain/config revision, coalesce/cancel superseded jobs, bound convergence and report failure. Cheap measured checks may stay synchronous; lookup tables require validity/error bounds. F4 now selects nodes/pipes/guns/existing-water references and verified design estimates. Pump layout/hydraulic sizing is not commissioned; no operating snowmaking/catenary engine is inferred.

## 10. Saves, tools and later weather

Versioned portable model records and binary sidecars are authoritative. UObject/Actor serialization alone is not the save contract. Save Game captures coherent built canonical state, content IDs, grading, operating flags and later the simulation checkpoint; it excludes all working-plan content. Explicitly saved blueprint generations live in their own library and are loaded only through Load Blueprint. Write/verify new assets then commit a new manifest generation; retain previous valid recovery. Save only PausedReady once relevant derived consistency is established. No old-save importer; native format forward migrations begin with the first editable milestone.

Catalog data and stable IDs leave later sharing/mods possible without shipping executable scripts now. Screenshot and clean trail-map export restores UI and transient visibility exactly once; no new report export scope. Use supported image capture in the packaged player, not only editor viewport screenshots.

P6 preserves the existing numerical weather backend behavior; a C++ or other-language translation is now expressly permitted when justified. At P6.1 trace gameplay and lab call paths, pin the actual reference and representative fixtures, and reconcile any materially different intended behavior rather than guessing from a directory name. Choose one offline host/translation after that evidence, not multiple speculative adapters. Translation is not permission to redesign model science. Preserve/check RNG, timezone/DST, sequence and checkpoint continuation with declared numerical tolerances. New Unreal weather visuals and dynamic clouds may be built from scratch **as a separate future feature**; they do not drive numerical weather or block P0–P6. Current static/artist-controlled sun/sky/overcast presets remain visual controls, not simulated weather. See [contracts/WEATHER_AND_EFFECTS.md](contracts/WEATHER_AND_EFFECTS.md).

## 11. Codex, assets, verification and completion

The user alone commits after an accepted bounded section. Fresh Terra reviewers challenge both architecture and implementation; requested role/model labels are not routing proof. F11 is settled: Sol High performs all routine delegation, scope coordination and review reconciliation; Terra High performs implementation and every fresh adversarial review. Astra is a very sparing, high-level escalation only—not a default parent or mandatory per-phase reviewer. See [05_CODEX_ORCHESTRATION.md](05_CODEX_ORCHESTRATION.md).

One writer owns each `.uasset`/`.umap`, material graph, Blueprint, shared config and build contract. No byte editing or external file moves of engine assets; use reviewed editor automation. Save owned dirty packages, then freeze writers/editor mutation/Live Coding while build/cook/review receipts are produced. Include source, assets, config, plugin/toolchain/engine IDs and generated INPUTS; identify exclusions for caches only. A mutated source state invalidates evidence. Do not require a commit to obtain provenance.

Optional Unreal MCP requires separate owner-authorized setup, loopback-only verification, bounded tool allowlists and serialized editor operations. It is Experimental and may expose runtime-capable server modules; explicitly exclude/disable automation bridges in shipping and verify no listening server. A filesystem read-only reviewer must also lack write-capable editor/network tools. Editor Python/MCP is a development aid, never a hidden game prerequisite. [E18/E19]

Run small affected tests and one section/milestone integration lane. Catch zero-discovered-tests, expected failure and timeout/exit propagation. Packaged Development/Test builds expose diagnostics; Shipping gets its own startup/offline/save/UI/security smoke. NullRHI tests do not qualify visuals. Record complete frame timelines, max gaps and stalls, not averages alone. User-approved visual and performance acceptance plus a closed selected-scope ledger define completion; historical future features do not.

No independent agents, Unreal compilation, runtime terrain tests, GPU trials or repository/cloud writes occurred while creating this package. The final adversarial self-audit, input reconciliation and structural/numerical checks are separate evidence. [14_FINAL_ADVERSARIAL_REVIEW.md](14_FINAL_ADVERSARIAL_REVIEW.md) records remaining gates and actual limitations.

## Latest owner answers — grouped plans, reference and hardware

Crystal Mountain, Washington is the visual reference, not a promised downloaded fixture or a restriction of user map selection. P1 chooses data/bounds and proposes overview/moderately-close views from that terrain; owner review judges whether processing preserves recognizable forms. Do not invent a required named chute or claim unverified resolution. Synthetic seam/slope fixtures remain complementary.

A roughly ten-year-old laptop is available as an optional test candidate. Inventory its CPU/GPU/RAM/OS/storage/driver before any compatibility or performance claim. It does not automatically become the minimum hardware, and does not qualify the previously proposed GTX1650 lane. Test the packaged player, not an assumed editor installation; retain failed/unsupported results honestly without expanding scope to arbitrary old hardware.

Mixed blueprint data explicitly accommodates building plan records. Until F1_BUILDINGS selects current footprint-placement tooling or future tooling, only data retention/reference/capability handling is commissioned. No modeled building art, amenities, staffing, income, collision population or hydraulic behavior is inferred. Unsupported entries are retained with visible capability diagnostics, never silently discarded, executed, costed as zero, or partially built. A selected transaction requiring one must fail safely; an independent supported subset can be explicitly selected. [Latest answers 1, 3–5]
