# Owner engine-change instruction — September 18, 2026

> Please edit the plan to reflect implementation in Unreal. Please ask me as many questions as needed and follow the initial prompts.

This selects Unreal Engine for the replacement. Prior discussion emphasizes a small open-world resort-building map and stunning mountain environment design. It does not expressly authorize first-person skiing, a higher minimum GPU, extra modeled objects, removal of player-selected real terrain, removal of trail grading, or different clock semantics. Those are not inferred approvals.

Prior requirements and the authorizations to incorporate audit R01–R10 and validate the external critique still apply. Original 40 answers are preserved byte-for-byte in OWNER_RESPONSES.md; references there to the previous engine are historical wording. Engine-specific implementation is superseded by this revision. The user alone commits. This instruction authorizes editing the planning package, not implementing game code or overwriting repository/cloud files.
