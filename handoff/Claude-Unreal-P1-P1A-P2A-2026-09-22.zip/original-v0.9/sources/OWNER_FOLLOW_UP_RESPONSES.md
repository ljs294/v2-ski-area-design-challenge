Owner questions — Unreal v0.7

Unreal is selected. This is not another engine vote. The original forty answers remain authoritative; no need to repeat Windows, single-player/offline operation, replacement rather than alongside, runtime real-mountain selection, local runner/user review, manual saves, no automatic commits, dots, terrain-only 3D, no current operational snowmaking or no default season test.

Five new decisions arise from making Unreal's mountain presentation central; eleven prior F entries still need answers. Recommendations are proposals, not automatic acceptance. Answer the ID plus a choice or “use the recommendation.” Engine APIs, C++ memory management and mathematical timing formulas are engineering responsibilities—not questions delegated to you.

New Unreal / visual decisions

U1 — Visual direction

Question: Keep the alpine-diorama style, move to a naturalistic/cinematic mountain, or use a hybrid (realistic terrain/light with clean diagram-like construction overlays)? Recommendation: Hybrid: authentic terrain, naturalistic snow/rock/lighting/atmosphere, restrained readable overlays. Preserve the existing terrain-only modeled scope; adding rock/tree meshes would need a separate explicit scope change. Gate: P1.2 direction; P1.7 visual acceptance. Answer: 



Answer: Hybrid recommendation is correct. Should have good overlays and also handle overlays well.

U2 — Closest required camera experience

Question: Does the existing overhead/orbit/free-camera scale remain enough, or must the mountain look convincing from near ground level? Give the closest view you expect—e.g., looking down on a whole run versus examining terrain a few meters away. Recommendation: Resort overview and moderately close free-camera views first, not walking/skiing gameplay. Establish one concrete closest-camera shot during the proof. The original zoom concept is retained unless you explicitly expand it. Why: Source terrain, materials, collision/picking and distant/near LOD requirements differ substantially; an unspecified ground-level promise can dominate the project. Gate: P1.7. Answer:



Answer: Follow recommendation.

U3 — What counts as a successful high-quality environment?

Question: Should acceptance be based on the appearance and responsiveness of the actual editable mountain, regardless of whether it uses Lumen/Nanite? Or are those particular high-end rendering features essential to your reason for switching? Recommendation: Judge the playable result, not a renderer name. Preserve a transparent lower-cost lighting profile for the low-end target and pursue a strong high-quality look on the reference PC. The documented first runtime mesh candidate lacks Nanite/Lumen, so its look must be demonstrated before being accepted; an unattractive fallback is not automatically approved. Gate: Combined P1.7 editable/visual proof. Answer:



Answer: Follow recommendation.

U4 — Optional dependency budget and escalation

Question: Keep every new plugin/tool at zero upfront cost, or may a tested paid dependency be proposed if it demonstrably solves a runtime-terrain or browser gap? State a ceiling only if you have one. Recommendation: Free/built-in first; zero purchases without your item-specific approval. No engine source fork or experimental terrain foundation by default. A failed proof returns cost/maintenance/license tradeoffs rather than quietly buying a plugin or spending indefinitely on a custom engine subsystem. Gate: Only when a candidate needs paid/source-build escalation; does not block the free proof. Answer:



Answer: Follow recommendation. No cost requirements at this point.

U5 — Recognizable terrain reference

Question: Name one mountain whose ridges/chutes you know well, or supply one/two environment references that express the desired look. Which feature absolutely must survive the terrain processing? Recommendation: Use one recognizable real mountain for your visual review and a small synthetic seam/steep-slope fixture for numerical checks. Existing local benchmark data can bootstrap development; it does not substitute for your final visual standard. No travel planning or new data purchase is implied. Gate: P1 visual approval; not native bootstrap. Answer:



Answer: Follow recommendation.

Prior open choices — same F identifiers

F1 — Construction-plan persistence and grouping — P2.1/P2.3

Should unbuilt plans survive save/reopen, contain several linked elements and support Build Selected? Recommendation: Persist non-transient proposals; support selected-item builds with explicit dependency closure. Elaborate naming/multi-plan organization can follow the first lift slice. A game design blueprint is data, not an Unreal Blueprint asset. Answer:



Answer: They should persist if the blueprint is explicitly saved. There should be a separate little save and load blueprint function to use.

F2 — Undo safety — RESOLVED IN PLANNING

Tool-local draft undo; one cross-tool committed LIFO history; coherent graph/grading reversal; no arbitrary selective undo or time/revenue rewind. New commit invalidates redo; load resets history; actual simulation advancement seals prior reversible history. Implement the runtime application command system, not editor transactions. No re-approval needed for this corruption-prevention rule.

F3 — Post-Build operating controls — P2 UI / P4 operation

Should lifts/trails have Open/Closed controls now? Should new construction start closed or open after validation? Recommendation: Explicit state and initially closed until validated/opened, then manual Play. Safe in-flight completion/rerouting and new-entry restrictions must be specified before closure/removal exists. No maintenance/staffing scope implied. Answer:



Answer: Follow recommendation.

F4 — Early snowmaking design subset — P3.1

Are nodes, pipes, guns and existing-water-source references sufficient, or do you require pump layout/hydraulic design sizing now? Recommendation: Begin with those layout elements and verified design estimates. No new pond/dam terrain tools, water consumption, operating snow output or grooming. Answer:



Answer: Follow recommendation for now.

F5 — Construction money, arrivals and ticket price — P4.0

Are costs informational or cash deductions? Should daily arrivals be directly set by the player, and should price alter demand? Recommendation: Unlimited-money design sandbox, informational construction estimates, player-set daily arrivals, fixed daily ticket price and once-per-admission revenue. No price elasticity or amenities. Define re-entry/price-lock rules in the task. Answer:



Answer: Costs are purely estimating for now. 

F6 — Individual authority, two clocks and weighted busy days — P4.0 before host code

A: Must a low-population guest's actual queue/trips determine totals even if exact time-rate mappings need an explicitly approved adjustment, or must exact old mappings take precedence with samples/aggregate authority where necessary? Recommendation: True individual low-count people, retain separate business/movement concepts and familiar controls, explicitly approve any required mapping changes after a tiny understandable demo. Do not silently alter Q10. Answer A:

B: Must weighted groups be included in the first operating milestone, or can it start near 3,000 individually simulated ACTIVE people with weighting deferred? Recommendation: Individual-only first, subject to your explicit deferral approval. When weighting is included, partial seats/FIFO residuals/checkpoints/waits are required. An active cap is not a daily-admission cap; excess demand cannot vanish. Answer B:



Answer: Follow recommendations for both.

F7 — Resort footprint — P1 supported envelope

Retain the proposed 2–10 km per side range, fixed boundary and lower-detail surroundings? Recommendation: Yes as a target, not a measured support claim. Qualify maximum footprint AND source quality together. A small proof can proceed while upper limits remain unqualified. Answer:



Answer: Follow recommendation.

F8 — High-resolution preparation time — P1 quality policy

May an explicitly selected high-detail option exceed roughly five minutes on a large region, with clear status/size estimates, while a faster option remains available? Recommendation: Source-aware Standard/High choices where actual data supports them; no silent degradation or false precision from upsampling. Provider throughput is not a guarantee. Answer:



Answer: This is acceptable.

F9 — Same-window selector proof — RESOLVED AS A PLANNED SPIKE

The scope remains same-window MapLibre-compatible selection and a complete packaged preparation pipeline. The Unreal browser widget is now the first host candidate; WebView2/other verified/native paths are alternatives after failure. This changes the technical probe, not your requirement. No purchases, software installation or capability escalation is automatically authorized.

F10 — Intended weather backend and host — P6 ONLY

Which existing engine is intended: standalone Weather Model Lab or current gameplay? May the unchanged executable model run in a local helper, or must algorithms run natively in C++? Recommendation: Select the actual backend first and use one tested offline adapter preserving behavior. No scientific redesign or remote runtime service. Does not block P0–P5. Answer:



Answer: Follow recommendation.

F11 — Model cadence — before routine delegation

Astra XHigh at architecture/major-review gates, Sol High for routine scoped coordination, Terra High for implementation and fresh adversarial review—or Astra as the active parent for each section? Recommendation: Gate-based Astra with Sol routine coordination. No quota-savings promise. Original Sol High High wording must map to actual supported settings, never an invented high_high value. Actual model availability/routing is verified in your VS Code client. User-only commits are already settled. Answer:



Answer: Astra should be used very sparingly. Sol High should due all delegation work and review. Terra High for all adversarial work and actual implementation. Astra is purely an orchestrator to make very high level decisions.

F12 — Hardware, two visual profiles and stutter — P1/P5 acceptance

Is a weaker physical PC available? May the game expose visibly different Low/High lighting/atmosphere profiles while preserving the same mechanics and meaningful terrain? The earlier GTX 1650 4 GB / 16 GB RAM / SSD / 1080p Low lane remains only a candidate; CPU/board/RHI must be selected and actually tested. Unreal does not silently raise your minimum spec. Recommendation: Keep 30-FPS minimum / 60-target intent, measure both a minimum lane and the actual reference PC, and provisionally require no ordinary-gameplay frame gap over 250 ms alongside percentile/stall counts. Agree thresholds before qualification. Cold shaders/loading/intentional Build transitions are separate predefined windows, not excuses for live planning freezes. Low may disable unsupported expensive lighting features; its appearance still needs your approval. Answer:



Answer: Follow recommendation.

F13 — Local prepared-save loading — P2.5

Is <=30 seconds to genuinely interactive play an acceptable first target on a declared standard prepared fixture? Recommendation: Yes as a measured target with cold/warm conditions; required mesh/query/shader readiness counts, not just a dismissed loading screen. No provider request or repeated full preparation on reopening. Answer:



Answer: Yes this is a good target.

Answer priority

First resolve U1/U2/U3 and F11 for direction and execution. F7/F8/F12 govern accepting the terrain envelope; U5 supplies a recognizable visual target. F1/F3/F13 shape the designer; F4 precedes snowmaking; F5/F6 precede simulation; F10 can wait. U4 matters only for an actual dependency escalation. Do not block a small reversible bootstrap on distant decisions.
