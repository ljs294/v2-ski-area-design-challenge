# Owner responses — source transcription

From the supplied `04_QUESTIONS_AND_DECISIONS.docx`; native Google Doc text was also read. This is a transcription, not a new decision proposal. Original question/recommendation text is retained so “Follow recommendation” has its original context.

Comment: lower fps is acceptable with a bigger scope like unity engine. Min of 30, target of 60 fps.

## Q1 — What does a successful full port preserve?

Question: Is acceptance based on current new-game behavior, every feature present anywhere including legacy saves, or a selected list that can intentionally remove weak features? Recommendation: Current new-game behavior as the primary reference, plus an explicitly approved legacy-feature list. No silent omissions. Mark intentional redesigns separately. Why it matters: Supporting all historical behavior is a different project from porting the latest product. Blocks P0 scope acceptance.

Answer: It is acceptable to trim or defer weakly implemented features to future scope. Base work right now is to be able to build a lift and trail network (and associated node map and node map viewer), including lifting building tool and trail building tool. Snowmaking should also be ready to implement sooner rather than later as that feature has a solid base, but could be implemented graphically and organized better.

## Q2 — What should the final game optimize for?

Question: Rank beautiful resort design, smooth interaction, deep operating simulation, realistic analysis, and rapid addition of new features. Which would you sacrifice first when they conflict? Recommendation: Smooth interaction and useful design first; simulation correctness next; extra visual detail within that budget. The first milestone remains the saved designer. Why it matters: Determines where simplification is acceptable. Needed before P1 acceptance.

Answer: Follow recommendation

## Q3 — Which operating systems are launch requirements?

Question: Windows only initially, or must macOS/Linux be first-class before the first public release? Recommendation: Windows first; avoid unnecessary platform lock-in but qualify other systems only when required. Why it matters: Build automation, file semantics, graphics backends and testing cost. Blocks P0 platform lock.

Answer: Windows only. MacOS is not in scope. If there are easy changes to make throughout development that could help port to Mac in the future, we should consider, but not a priority.

## Q4 — What is the minimum hardware and display target?

Question: Is the documented Ryzen 5600X/RTX 3060 Ti a reference machine or the weakest machine you intend to support? Must integrated graphics run acceptably? What resolution and memory floor matter? Recommendation: Keep that machine as the initial reference, not an assumed minimum. Agree one real lower-end lane and a 1080p standard comparison; test the existing ultrawide separately. Why it matters: Makes the 60-FPS target meaningful. Blocks P1 performance acceptance.

Answer: Low end graphics cards should be able to play the game smoothly at 30 fps. No clue what a low end graphics card is these days.

## Q5 — How should mountain selection be packaged?

Question: Is a separate MapLibre preparation tool acceptable for early releases? At final release, must selecting and preparing a mountain happen inside the Unity application's window? Recommendation: Separate preparation initially; require a unified player-facing workflow at cutover if ease of distribution is important. Do not introduce an embedded browser merely to avoid deciding. Why it matters: Controls whether a companion, native selector or web-view dependency belongs in the shipping product. Early choice P1; final choice before P8 implementation.

Answer: Keeping MapLibre for map/terrain selection is acceptable. It should all happen within the same window though, so it should be a module that runs within the main game engine. If there is a good way to have this internally, natively, I would be open to it, but IMO the terrain selection engine works pretty well right now.

## Q6 — What is the numerical world-size envelope?

Question: Keeping the current map/zoom concept, what maximum width × height must be editable? Can the boundary expand later, and must everything remain equally detailed? Recommendation: Freeze a finite resort envelope first, preserve lower-detail surroundings, and make expansion a later explicit feature. Use the current supported maximum as a candidate after P0 verifies it. Why it matters: Terrain tiling, floating-point error, memory and snow-grid density. Blocks P1 architecture acceptance.

Answer: For now, after user selects the resort boundary, it will be unchangeable. In the future, a good feature would be unlocking parts of the map as a game mechanic similar to cities sklyines.

## Q7 — What distribution and recurring-cost constraints apply?

Question: Personal project, free public download or commercial/Steam product? What limits apply to paid assets, build infrastructure, data providers and AI use? Recommendation: Offline desktop core with no mandatory account or recurring backend; minimize dependencies and approve each paid item before adoption. Why it matters: Packaging, licenses, keys, content rights and support architecture. Needed in P0; precise release mechanics can wait.

Answer:While this is a personal project, I eventually would find it cool to be able to sell. As a result, we should have a strong bias toward opensource / free commercial licensed tools. However, day1, this is just a personal project.

## Q8 — Where can Codex actually run Unity?

Question: Can Codex execute locally on the Windows machine with Unity installed, or will coding be cloud-only? Are you willing to run the player and approve visual/interaction milestones? Recommendation: A local or explicitly authorized Unity runner with access to the GPU for qualification, plus human visual approval. Cloud-only code generation needs a separate validation handoff. Why it matters: Prevents large amounts of uncompiled or untested Unity code. Blocks P0 toolchain gate.

Answer: Follow recommendation. Can run on local machine. User can verify.

## Q9 — What must a skier look like at the existing closest zoom?

Question: Dots/billboards, simple animated low-poly people, or detailed characters? Are individual collisions/carving mechanics desired, or only believable movement along a route? Recommendation: Simple distant representatives and optional nearby low-poly detail, not rigid-body skiing for every person. Why it matters: Rendering, animation, picking and CPU/GPU budgets. Basic choice P1; final detail P7.

Answer: Stick with just dots for now, keep it simple at day 1. No Carving animations for now.

## Q10 — Preserve or redesign the current two-clock experience?

Question: Keep the current macro/micro distinction and high-speed aggregate modes, or make visual skier movement track business time directly at all speeds? Recommendation: Preserve current dual-clock behavior first. Record a redesign separately if it feels confusing or artificial. Why it matters: Affects virtually every event, visit, time skip and checkpoint. New-game source uses 40 macro seconds/real second at 1×, with a different micro rate. [R4, R5] Blocks P4.

Answer: Follow recommendation.

## Q11 — Which legacy-only systems are mandatory?

Question: Must injury/patrol, road vehicles and lodging all appear in the final native game, or are some unwanted? Which should come first? Recommendation: Choose individually; do not port an entire second legacy runtime to recover three capabilities. Why it matters: Those systems are not currently running in the new cohort engine. [R4] Blocks full scope closure; decisions needed before P6.

Answer: Day 1, just worry about these mechanics. User should choose a guest spawn point and they should pick runs, but no need to simulate all these other mechanics; they will all be future features.

## Q12 — Which weather model should become authoritative?

Question: Preserve current gameplay package/session behavior, or adopt the standalone weather lab generator as part of this migration? Recommendation: Preserve gameplay first; validate and adopt the lab model as a separately versioned change unless its behavior is already a core goal. Why it matters: They are separate paths, so adopting the lab is a model change, not just C# translation. [R2, R3] Blocks P4 weather port.

Answer: Let’s make linking the weather engine a later core goal. The weather simulation back end is solid; it doesn’t need to be reworked, just wired up to the UI.

## Q13 — What does snow depth have to do visually and mechanically?

Question: Is a snow-depth/condition map enough initially? At the final closest zoom, must piles visibly raise the surface and affect placement, skier height or collisions? Recommendation: Preserve numerical depth/condition first, plus convincing terrain materials. Add bounded local geometry where it genuinely matters. Why it matters: Determines whether a separate snow-surface geometry and query system is required. Terrain-risk choice P1; full implementation P7.

Answer: For day one implementation, a layer map is fine for now. Future feature will be simulating depths on top of the terrain to physically change the terrain heights.

## Q14 — Is operational snowmaking/grooming part of this port or the next product increment?

Question: Must the target include water consumption, pond depletion, pump capacity, snowgun production, machine dispatch, schedules and snow redistribution? Rank the minimum useful subset. Recommendation: Separate infrastructure-design parity from these new operating mechanics. Approve one vertical slice at a time, such as one gun consuming water and depositing snow before a full fleet scheduler. Why it matters: Current documentation defers continuous snowmaking and dispatched grooming. [R4] Blocks P6 extension scope.

Answer: Out of scope; future feature implementation.

## Q15 — How large must the actual operating resort be?

Question: What are the maximum lifts, trails, daily admissions, active representatives and simultaneously visible people? Do you require every admitted guest to be simulated individually? Recommendation: Start from the existing 3,000-representative cap and a genuinely integrated complex fixture, while keeping authoritative aggregate demand separate. Increase only with a defined reason and measured budget. Why it matters: “10,000 guests per day” is not the same as 10,000 simultaneous animated actors. [R5, R11] Blocks P5 scale acceptance.

Answer: Would like each guest to be simulated separately for lower numbers of guests. For busier days, simulating multiple people with one actual guest is ok. Idk what the limits should be. 3,000 individuals is a good start..

## Q16 — Is the financial model a design estimate or a management game?

Question: Preserve current costs/tickets/amenities, or add payroll, electricity, fuel, debt, maintenance and profitability as major new mechanics? Recommendation: Port the verified existing metrics, then scope additional accounting explicitly. Never invent plausible readouts for absent systems. Why it matters: Changes ledgers, time stepping and data requirements. Needed before P3/P5 metric design.

Answer: Lets only have daily ticket cost for revenue right now. No amenities, payroll, or other mechanics  right now. This is mostly future scope.

## Q17 — May players edit while the simulation is running?

Question: Should entering a construction tool pause, should only confirmation pause, or must live construction coexist with moving guests? Recommendation: Permit camera/inspection continuously and use an explicit construction pause/barrier initially. Resume according to a documented rule; later live editing must define affected journeys and resource commits. Why it matters: Transaction, cancellation and topology consistency. Needed before P2 command UX; binding for P5.

Answer: Users should be able to build blueprints (construction plans that allow the user to see an overview of things they want to build on the map without committing to it and see the cost) while the game is running. Clicking build should pause the game for the user to make operational adjustments prior to restarting the simulation.

## Q18 — How faithful should the port be when the source is wrong or awkward?

Question: Preserve every behavior for comparison, fix obvious bugs as discovered, or redesign selected workflows immediately? Recommendation: Characterize first. Fix with a documented approved difference and tests; avoid mixing a large algorithm redesign with its language port. Why it matters: Defines whether the original application is an oracle, a reference, or an anti-example for each feature. Needed in P0.

Answer: Follow recommendation. We are not trying to port so much as we are taking the game in a new direction.

## Q19 — Which regions must work?

Question: U.S. only initially, North America, or worldwide from the first public release? Which real mountain outside the initial coverage is a required test? Recommendation: Guarantee only a verified provider-coverage matrix at first. Daymet is not a global product. [U13] Why it matters: Elevation, imagery, cover, weather and timezone support differ by region. Needed for P1 fixtures and P8 scope.

Answer: Ideally North America, but can limit scope to lower 48 states at first if there is trouble getting good elevation and weather data elsewhere.

## Q20 — How accurate must terrain-derived measurements be?

Question: Is source-DEM-consistent game analysis sufficient, or do you expect survey/design-grade elevations, quantities or construction validation? Recommendation: Clearly identified game/planning estimates with displayed source resolution and uncertainty; no unvalidated engineering-grade claims. Why it matters: Resampling, vertical datum, numerical tolerance and product representations. Blocks P1 accuracy acceptance.

Answer: I want elevation data to be as accurate and precise as possible, while still reasonable to acquire and render. Amazing ski areas are made by the tiny chutes and features they have around the mountain like cliff bands, couloirs, etc. The better we can capture these, the more authentic and stunning the game will feel.

## Q21 — How far can players reshape the mountain?

Question: Trail grading only, broad cut/fill sculpting, ponds/dams with changed terrain, or caves/overhangs/tunnels? Recommendation: Preserve verified heightfield-compatible grading and water structures. Treat topology-changing terrain and underground features as new requirements. Why it matters: Unity Terrain versus custom mesh/voxel techniques and collision architecture. Blocks P1 terrain strategy if ambitious.

Answer: For now, trail grading option only; no landscaping tools at this stage, this will be a future feature.

## Q22 — Are prepared mountains shareable?

Question: Should users export a resort to someone else as a complete package, a design referencing a separately installed mountain, or a recipe that downloads source data? Recommendation: Separate design saves from immutable content, with optional legally redistributable package export. Never assume imagery rights allow bundling. Why it matters: Package identity, deduplication, storage and attribution. Needed before P2 format hardening.

Answer: At day one this is not needed, but in the future saves should be fully shareable.

## Q23 — How strict is offline mode?

Question: Does offline mean gameplay needs no provider requests, or must the executable make zero network requests, including update/analytics checks? Must package creation itself be offline from supplied data? Recommendation: No required gameplay network; a strict offline switch; preparation may use explicitly requested online services. Why it matters: Tests and optional service architecture. Needed before P1 offline acceptance.

Answer: After initializing a game (selecting terrain) the game should be able to operate fully offline, no streaming of data.

## Q24 — How much storage and preparation time is acceptable?

Question: Is a large once-per-mountain download acceptable? What package-size, installed-storage and preparation-time limits should the UI promise? Recommendation: Show source/size estimates and cancellable progress; do not set a universal high-resolution download until map size and region are known. Why it matters: Chunking, caching, interruption/resume and provider budgets. Needed before P8; influences P1.

Answer: One time large download of 5 minutes would be acceptable, but needs excellent status bars , eta reporting, and lots of detailed updates of what the game is doing to ensure users that the game is not hung while loading. Saves should be able to load a magnitude faster.i

## Q25 — May non-Unity preparation tools remain permanently?

Question: Does “full Unity port” require every developer/data tool to be C#, or only native gameplay, UI and simulation? Is a maintained TS or Python offline builder acceptable? Recommendation: Native gameplay authority; retain whichever preparation/validation tooling is simplest and reproducible. Do not rewrite functioning data tools solely for language uniformity. Why it matters: Prevents unnecessary ingestion/model-fitting rewrites. Needed for final scope definition.

Answer: Follow recommendation, but also follow best practices for smooth gameplay.

## Q26 — Which three current interactions are worst?

Question: Name the construction/selection/navigation workflows that should not be copied literally. Which current interactions must feel unchanged? Recommendation: Preserve recognizable organization but redesign the identified pain points during P1/P2 rather than freezing bad interaction contracts. Why it matters: Determines tool state machines and usability acceptance. Needed before P1 interaction approval.

Answer: Follow recommendation.

## Q27 — What must infrastructure look like at full-port completion?

Question: At full-port completion, are simple buildings/lift structures sufficient, or are animated chairs/cables and recognizable buildings mandatory? The simple, terrain-first initial milestone remains unchanged. Recommendation: Functional simple infrastructure in P2/P3; approved higher-detail assets in P7. Keep the earlier terrain-first milestone. Why it matters: Asset work and early acceptance, not just rendering code. Needed before P2/P7 scope lock.

Answer: For the scope of this effort, lines/layer on the map is acceptable. Not looking to add anything 3d yet in this effort accept for the terrain mesh itself.

## Q28 — How should undo behave?

Question: Undo construction only, or also grading, deletions, parameter edits and operations? Should history survive reopening, and how far back? Recommendation: Undo coherent authored design commands, including associated terrain changes; finite session history initially. Never “undo” accrued revenue/time without an explicit simulation rewind design. Why it matters: Command payloads and memory. Needed before P2.

Answer: Undo should behave differently depending on the tool and what action the user is taking with the tool.

## Q29 — What save protections are required?

Question: Manual saves only, autosaves, multiple slots, rolling backups, save-as copies or quick-save? Should a running game resume paused after a crash/reload? Recommendation: Manual save plus bounded autosaves/previous-generation recovery, with simulation restores paused. Old TS save import remains excluded. Why it matters: Scheduling coherent checkpoints and file lifecycle. Needed before P2 minimum save UX; P5 simulation behavior.

Answer: Start with just a basic save function. Autosave can be added later. Recommendation is good here.

## Q30 — Which accessibility and input requirements are non-negotiable?

Question: Keyboard-only access, remapping, color-vision-safe overlays, reduced motion, high-DPI scaling, controller support or screen-reader support? Recommendation: Preserve keyboard/focus/scale behaviors and readable overlays from the start. Controller and full assistive-technology support need explicit tests and scope. Why it matters: Input/UI technology acceptance. Needed before P1 UI decision.

Answer: Follow recommendation.

## Q31 — Are other languages required at launch?

Question: English only, localization-ready text, or fully translated interfaces and number/date formatting for specific locales? Recommendation: Avoid hard-coded text in business logic and use explicit units/formatting; ship translations only when required. Why it matters: UI layout, fonts, calendar and numeric formatting. Needed before P3 UI breadth.

Answer: English only for now.

## Q32 — What export and inspection features matter?

Question: Screenshots, clean trail maps, CSV-style quantities/cost reports, terrain exports, or comparison between resort designs? Recommendation: Preserve verified capture behavior first; scope analysis exports separately with explicit units and caveats. Why it matters: Data contracts and presentation-independent reporting. Needed before P3/P8 closure.

Answer: Scope for now should be screenshots and a clean trail map.

## Q33 — Is multiplayer a real requirement?

Question: None, shared asynchronous designs, cooperative live editing, or synchronized multiplayer simulation? Recommendation: Single-player plus shareable content first. Cooperative simulation is a major architecture requirement, not a harmless future checkbox. Why it matters: Determinism, authority, command validation and networking. Must answer before broad architecture approval if desired.

Answer: No multiplayer planned at this time.

## Q34 — What kind of modding is required?

Question: User data/catalog files only, custom art/content, scripted behavior, or unrestricted executable mods? Recommendation: Versioned data/catalog extension points only until a concrete mod requirement exists. No plugin execution runtime by default. Why it matters: Security, serialization, AOT and API stability. Needed before P6/P8; early if executable mods required.

Answer: Leave the door open for modding, but not a priority per se, but don’t want to box users in.

## Q35 — Are cloud saves/accounts required?

Question: Local-only, optional store cloud synchronization, or account-based hosted saves across devices? Recommendation: Local authoritative saves first, with coherent generations suitable for an optional later sync adapter. Why it matters: Conflict resolution, identity, backend cost and offline guarantees. Needed before P8.

Answer: Not in scope yet. Follow recommendation.

## Q36 — Should the old game keep receiving features during the port?

Question: Maintenance only, parallel feature development, or immediate freeze? Recommendation: Maintenance plus essential fixture/export changes; explicitly record any baseline changes adopted into Unity. Why it matters: Prevents a moving-target migration and doubled implementation work. Needed in P0.

Answer: No. this is a new Repo, the old game lives in its own repo. Focus solely on the unity version.

## Q37 — Which Codex surface and model setting is “Sol High High”?

Question: Are you using the CLI, desktop app, IDE or another client? Does the second “High” refer to a separate setting, a UI preset or a repetition? Recommendation: Use the verified Astra-medium parent/Terra-high profile as the concrete starter. Map the Sol preset to actual supported fields before enabling it; never invent high_high as a config value. Why it matters: Prevents silent model inheritance or unsupported configuration. Blocks P0 routing acceptance.

Answer: Using Codex VSCode extension. I want to save tokens as I am only on the Pro 20x plan. I would like to use Astra but it destroys tokens. Open to negotiation here thought, lets hash this out further.

## Q38 — What autonomy do agents have?

Question: May agents create branches/commits, change dependencies and fix source defects on their own, or must those decisions be approved? Who authorizes merges and public releases? Recommendation: Bounded implementation tasks and local commits are permitted only in the agreed workflow; owner approves product changes, new paid dependencies, merges and release/cutover. No automatic publication. Why it matters: Agent task contracts and tool permissions. Needed in P0.

Answer: Agents should only  work on a very predefined task. Commits should be made exclusively by the user once a phase section is implemented. Basically Astra overall orchestrator, sol work scoper, terra agents actually perform the work. I imagine an Astra Xhigh overall owner, Sol-High work scoping, terra high work implementation. Updated the Agents.md and Claude.md as needed to account for this in all future work.

## Q39 — How much parallel work is acceptable?

Question: Prefer lower AI cost and smaller review batches, or more simultaneous independent tasks? Is the machine able to run multiple build/test workloads? Recommendation: Start with at most two implementation workers plus a reviewer, and one active Unity integration/test owner. Raise concurrency only after observing conflicts, memory use and review cost. Why it matters: Parallel agents can increase coordination and context cost rather than reduce it. Needed before large-scale implementation.

Answer: Follow recommendation.

## Q40 — What is the final acceptance story?

Question: Describe the sequence that would convince you the port is done: choose mountain → build → operate a season → inspect → save/reopen → share? Who else must be able to install and complete it unaided? Recommendation: One written end-to-end story, a closed required-feature ledger, independent review, and a clean-machine install test on supported hardware. Why it matters: Prevents a technically complete but unusable release. Draft in P0; execute in P8.

Answer: No need to operate a season in testing. Testing is important, but don’t want to waste that much time for testing. Keep testing robust but agile to save tokens and time.
