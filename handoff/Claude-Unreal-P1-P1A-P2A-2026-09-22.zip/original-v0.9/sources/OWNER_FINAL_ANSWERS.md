# Latest owner answers — September 18, 2026

Source: current conversation; verbatim answers to the five v0.8 follow-ups. These take precedence over the captured questionnaire recommendations. No Drive refresh or repository inspection was needed for these directly supplied answers.

## F1_GROUPING

A blueprint should be able to hold a number of items at one time. For example, a user should be able to save an entire trail pod with lifts, trails, snowmaking, buildings in it at one time.

## F5_REVENUE

Follow recommendation

## U5_REFERENCE

Crystal mountain WA

## F12_HARDWARE

Have a 10 year old laptop lol

## F10_BACKEND

I like the weather backend we have, but if we need to rewrite it in another language, that is fine. For actual weather effects, I am fine with having that be built from scratch in game with dynamic clouds eventually as a future feature.
