# Unreal decision records and feasibility matrix

Statuses: ACCEPTED_PRODUCT is an owner instruction; PROPOSED is a recommendation; SPIKE requires measured proof; BLOCKED_GATE prevents only dependent broad implementation. All runtime closure is NOT_EXECUTED.

| ADR | Status | Decision / alternative | Gate / owner dependency |
|---|---|---|---|
| UE-01 | ACCEPTED_PRODUCT | Unreal replaces the application in v2; original repo read-only | P0 instructions, current message |
| UE-02 | PROPOSED | Released UE5.8 binary patch; exact toolchain pinned; no source fork by default | P0.3 installed version/compile/cook; U4 only if costly escalation |
| UE-03 | PROPOSED | C++ pure domain, UBT application/presentation/editor boundaries; BP view/config only | CORE01–04 and P0.3/P0.5; not owner permission for unbounded code |
| UE-04 | SPIKE / CRITICAL | Runtime heightfield tile candidate with explicit LOD and pre-cooked materials; Dynamic Mesh first | P1.1/P1.7 combined runtime/editability/look; U1–U3/F7/F8/F12 |
| UE-05 | PROPOSED | Deferred dynamic lighting/atmosphere tiers; RHI and feature compatibility measured | P1.2/P1.7; no Nanite/Lumen guarantee on runtime tiles |
| UE-06 | PROPOSED | Fixed map, local-disk tile residency if needed; World Partition not mandatory | P1 resource/camera behavior; F7 |
| UE-07 | SPIKE | MapLibre in packaged Unreal browser widget; narrow bridge | P1.4/IO01/SEC04; native/WebView2 alternative only after scoped failure |
| UE-08 | PROPOSED | Runtime UMG/C++/Slate tools and graph UI, no editor graph dependency | P1.3 and P2.2 UI/cook test |
| UE-09 | PROPOSED | Canonical double ENU meters; UE Xnorth/Yeast/Zup centimeters | TER01–04; no raw .Transform save authority |
| UE-10 | INCORPORATED_SAFEGUARD | Revisioned Build/sync recovery and runtime LIFO undo | BLD01–08/BP01–11; mixed plans and explicit saves accepted; F1_BUILDINGS limits only building-tool scope |
| UE-11 | ACCEPTED_DIRECTION / DEMO_GATE | Accepted individual-only direction; concrete macro/micro/service/capacity demo before scheduler | P4.0 concrete clock demo and accepted F5 daily-input boundary tests |
| UE-12 | PROPOSED | Manual versioned data saves, cook-independent user terrain, no old save import | IO04–08; F13 <=30s initial load target accepted, not measured |
| UE-13 | PROPOSED | Binary asset ownership/recipes, source freeze and effective read-only review including editor tools | P0.2/5 and every section; user-only commits |
| UE-14 | OPTIONAL_SPIKE | First-party Experimental MCP for scoped local editor tasks | SEC03/05; no exposed service or shipping bridge |
| UE-15 | LATER_CORE | Preserve selected existing weather model through one tested offline adapter | P6; F10, no blocking early work |

## Not equivalent to approval

A documented API is not a packaged feasibility result. An editor level that uses Nanite is not proof of runtime Nanite authoring. A runtime mesh that changes shape is not proof of acceptable LOD/lighting. Lumen enabled in project settings is not proof that runtime geometry participates. UMG available in a player does not mean an editor GraphEditor widget is shippable. A successful source compile is not a successful cook. A read-only shell is not a read-only editor MCP connection.

## Bounded terrain escalation

Start one candidate under the declared resource/time scope. Produce a small live imported/edited visual scene, exact limitations and actual measurements. If it fails, scope one alternative supported by verified package/runtime capability. Engine source modification, extra asset budget, restricted geographic coverage, higher hardware, removed grading or curated-only mountains each requires explicit owner acceptance. Do not endlessly implement speculative alternatives or conceal a failed visual requirement behind “future polish.”


## v0.9 reconciliation precedence

Use DECISION_STATUS.json and sources/OWNER_FINAL_ANSWERS.md. Mixed multi-item plans, revenue inputs and Crystal Mountain WA are accepted; the older laptop is an optional unqualified probe and weather translation is permitted. F1_BUILDINGS is the sole current product clarification. Laptop inventory, reference shots and weather source identification are implementation evidence tasks, not unanswered broad choices. All runtime proof and independent execution remain NOT_EXECUTED.

## New accepted owner decisions

- **UE-16 — ACCEPTED_PRODUCT:** explicit Save Blueprint/Load Blueprint separate from Save Game; small local plan library with current-scope bindings. Mixed pods are accepted; building-tool timing is F1_BUILDINGS, not a blocker to the one-lift proof.
- **UE-17 — ACCEPTED_PRODUCT:** Sol High routine coordinator and review synthesizer, Terra High implementation/adversarial review, rare Astra high-level consultation. User-only commits.
- **UE-18 — ACCEPTED_DIRECTION / DEMO_PENDING:** true individual authority with deferred weighting; owner reviews specific clock changes in P4.0. No full engine before terrain.
- **UE-19 — ACCEPTED_TARGETS / MEASUREMENT_PENDING:** hybrid look and readable overlays at agreed cameras; 2–10 km footprint target, Standard/High source options, Low/High rendering, initial <=30s prepared-save target. Crystal Mountain WA is selected; older laptop specs and actual measurements remain unverified.
