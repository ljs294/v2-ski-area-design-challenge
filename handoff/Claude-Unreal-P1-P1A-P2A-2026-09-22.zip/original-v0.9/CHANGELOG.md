# Package changelog

## v0.9 — September 18, 2026 — final planning handoff after owner answers

Reconcile all 16 new answer blocks while preserving the original 40 responses. Accept hybrid look, camera and renderer-independent visual approval; explicit Save Blueprint/Load Blueprint; Closed new infrastructure; limited snowmaking layout; informational costs; true individual guests and weighted deferral; footprint/quality/load targets; and Sol-led/Terra-executed work with very sparse Astra consultation.

Add the small explicit blueprint-library contract with independent game/plan saves, dirty/concurrent-save handling, stale bindings/IDs and library reference protection. Update P2.1 so it already saves/loads one plan. Keep grouped Build Selected unresolved rather than inferring approval. Rescope P4.3 to individual cap/arrival handling; preserve weighted service requirements as future tests, not release gates. Add Open/Closed safety and overlay interaction assertions.

Fix discovered test-ID semantic drift: registry-generated definition blocks and phase case sets now agree. Remove obsolete parent-config alternatives; add sole Sol High profile example. Keep final author audit separate from unexecuted fresh Terra review. Preserve prior package as an unchanged historical ZIP; original source/repo/Drive unchanged.

## v0.7 — September 18, 2026 — historical Unreal switch

Replaced active engine-specific implementation prescriptions with Unreal/C++; preserved R01–R10 and ER01–ER08 safeguards. Added same packaged runtime-terrain editability/appearance gate, Unreal cook/shader/binary-asset/MCP controls and the follow-up questionnaire now answered in v0.9. Exact old material is inside sources/HISTORICAL_UNREAL_V07.zip, not an active task list.

## v0.9 — latest five owner answers, September 18, 2026

Applied whole-pod mixed blueprint records, accepted ticket inputs, Crystal Mountain WA reference, optional older-laptop inventory lane, numerical-weather translation permission and explicitly future dynamic effects. Added dependency/capability-safe mixed-plan requirements and tests. Only building-footprint tooling timing needs a product answer; later hardware/source identity are engineering gates. Retained original 40+16 answer sources, all R/ER safeguards, user-only commits and sparse-Astra/Sol/Terra policy. No game/engine/cloud/repository changes or new independent-agent approval.
