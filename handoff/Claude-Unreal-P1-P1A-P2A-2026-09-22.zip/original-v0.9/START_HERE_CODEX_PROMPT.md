# Codex handoff — Sol High, Unreal v0.9

Work only in `ljs294/v2-ski-area-design-challenge`. Use this v0.9 planning folder as the active package; do not merge old tasks from historical archives. Historical TypeScript reference commit is `1cca4e0808b96fa0fc43d48c4289a118b29b30ec`, not proof of the current checkout. Read actual root/scoped AGENTS.md and CLAUDE.md before any work. Preserve dirty/untracked owner changes.

## Authority

This initial prompt authorizes inspection, genuine review and scoping **one smallest P0 task**. It does not authorize game implementation, deleting/moving files, installing engines/plugins, replacing agent configuration, saving unrelated editor assets, network publication, staging or commits. The user authorizes each implementation section and alone stages/commits. No automatic next section.

**Sol High is the routine parent/coordinator.** Perform all scoping, delegation and coordinating review at that level. Terra High implements authorized tasks and performs every fresh independent adversarial review. Astra is a very sparing high-level escalation only; never the default parent or a mandatory phase-review step. Verify actual model/effort availability and effective permissions in the installed client. No silent model substitution or routing claims from role labels.

## First read

Read README.md, REVIEW_BRIEF.md, DECISION_STATUS.json, the P0 rows in 03_PHASE_PLAYBOOKS.md and 15_OWNER_ANSWER_RECONCILIATION.md. The v0.8 audit in 14_FINAL_ADVERSARIAL_REVIEW.md is retained history, not the current open-input list. For the unanchored Terra first pass, give reviewers the owner source and relevant current contracts **without the author's audit conclusions**. Do not flood every implementer with historical plans or complete transcripts.

## Preserve accepted decisions

Unreal is the sole native Windows game. Terrain-only modeled 3D; infrastructure overlays/dot guests; same-window real-mountain preparation and offline play. Blueprints persist only after explicit Save Blueprint; Load Blueprint restores proposed data without building or changing simulation. Ordinary Save Game excludes working plans. Build commits Closed infrastructure after acknowledged pause/readiness, then manual opening/Play. Trail grading, safe undo, manual saves, limited snowmaking layout and ticket revenue are current; costs estimates only; no weighted guests in first operation. No amenities/physical snow/grooming/autosave/multiplayer/cloud expansion.

True individual guests and deferred weighting are approved. The actual event-clock mapping still needs a tiny P4.0 demonstration and owner approval before production host code—not before terrain. Appearance and runtime editability must pass on the **same packaged terrain representation**. No automatic Nanite/Lumen, editor-only workflow, prebuilt-only mountains, high-spec-only fallback or engine fork.

## Initial actions

1. Establish active package identity and run its read-only planning checker. Inspect the actual checkout, installed engine/toolchain and current instruction/configuration files without changing them. Distinguish absent from unverified.
2. Read the latest five answers in sources/OWNER_FINAL_ANSWERS.md. Ask only F1_BUILDINGS if a building-tool task needs it. Grouping, ticket policy and Crystal Mountain are settled; inventory the laptop and trace weather code only at their engineering gates. Nothing here blocks bounded P0.
3. Run the four review assignments in independent-review/ using fresh Terra High sessions when available, at most two concurrently. Verify read-only access including editor/MCP/connector routes. Reviewers return findings, never repairs; write-producing experiments require a separately authorized scratch task. Missing spawn/permission capability is BLOCKED, not simulated review.
4. Sol reconciles actual reports, then compares against the final author audit. Use evidence/counterexamples, not votes or automatic Astra escalation. A real unresolved high-level architecture tradeoff may justify a compact Astra question.
5. Return the smallest P0 task with outcome, allowed files, tests/negative controls, non-goals, asset ownership and user acceptance. Propose necessary AGENTS/CLAUDE/config changes; do not install them in this review-only step.

## Required return

Verified inputs and current drift; actual model/session/permission evidence; concrete reviewer findings and dispositions; remaining local capabilities; the next bounded task. No manufactured engine/graphics/test pass. If later authorized to implement: Terra performs the work, Sol coordinates, freeze source/editor writes for final evidence, then hand uncommitted/unstaged changes and suggested commit message to the user.

## v0.9 specifics to preserve

Whole mixed trail-pod blueprints are approved, including future/current building records; building tool timing alone is not settled. Current Save/Load Blueprint stays explicit. Use Crystal Mountain WA for owner visual reference. Daily arrival count and fixed daily ticket pricing have been approved. The old laptop is an optional probe, not a minimum-spec commitment. Retain numerical weather behavior with language translation permitted; new dynamic-cloud/weather effects are future work and no P0–P6 backend gate. Read 15_OWNER_ANSWER_RECONCILIATION.md after a reviewer's unanchored first pass, not as conclusions they must adopt.
