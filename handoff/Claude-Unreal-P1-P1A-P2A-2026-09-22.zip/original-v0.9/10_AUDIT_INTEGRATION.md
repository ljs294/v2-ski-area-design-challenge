# R01–R10 integration — Unreal v0.9

Every prior accepted planning correction remains INCORPORATED_IN_PLAN. Unreal mechanisms replace previous engine APIs; no old runtime check becomes an Unreal pass. IMPLEMENTATION and INDEPENDENT_REVIEW are NOT_EXECUTED for all rows.

| Finding | Unreal planning correction | Gate | Verification / question |
|---|---|---|---|
| R01 | Plain C++ event-clock/population contract approved before reduced host/lifecycle | P4.0 before P4.1/2 | SIM01–04; F5/F6 |
| R02 | Separate browser-host proof from owned fresh acquisition/derive/portable package/native activation | P0.4/P1.4–1.8 | IO01–06; no editor/dev server/player Node requirement |
| R03 | First lift includes proposed/built separation, Build and manual save/reopen | P2.1 before network extension | BLD01/02/IO07; F1 |
| R04 | Canonical commit vs mesh/query/collision/index readiness; PausedRecovery, idempotence | P2.4/P4.5 | BLD07/08/TER04; no UnrealEd undo assumption |
| R05 | Runtime command system with tool-local drafts and ONE committed cross-tool LIFO history | P2.3/4 | BLD05/06; no selective older terrain before-image restore |
| R06 | Frozen C++/assets/config/cook inputs, dirty-package and editor/MCP mutation control | P0.2 and every evidence window | SEC01; no commit/worktree workaround |
| R07 | Measured footprint/quality, tile/LOD/native/GPU/grade/undo/shader/IO envelope | P1.7 -> actual grade P2.4 -> integrated P5.2 | TER04/05/PERF02; F7/F8/F12 |
| R08 | Included weights require partial seats, residual FIFO, wait/price/checkpoint semantics | P4.0 before P4.3 | SIM05/06/07; explicit F6B deferral alternative |
| R09 | Complete windows with max/start/end frame gaps and stall counts/durations | P1 capture/P5.2 | PERF01–04; accepted initial F12 approach plus measured hardware and frozen engineering thresholds, no relabeled stutters |
| R10 | Fresh non-author read-only reviewers; editor MCP write capabilities also disabled | P0.2/every review | SEC02/03; actual sessions not role-play |

## Required contract links

[Core](contracts/CORE_AND_ANALYSIS.md), [construction/undo](contracts/CONSTRUCTION_AND_UNDO.md), [simulation](contracts/SIMULATION_AUTHORITY.md), [runtime terrain/visuals](contracts/RUNTIME_TERRAIN_AND_VISUALS.md), [coordinates](contracts/COORDINATES_AND_RENDERING.md), [preparation/persistence](contracts/PREPARATION_AND_PERSISTENCE.md), [evidence](contracts/EVIDENCE_AND_REVIEW.md), and [phases](03_PHASE_PLAYBOOKS.md) contain the active rules.

R02 protects old preparation code until a native replacement exists without maintaining a second game. R06/R10 protect binary assets and external editor write routes as well as text code. R07 now also includes the cost of runtime mesh LOD and cold shaders. R04 permits an explicit canonical query path instead of unnecessary full-map physics, but does not waive display/query agreement.

## Still owner-controlled

Latest follow-up answers now approve explicit plan saving, operating controls, limited snowmaking layout, individual-first authority, weighted deferral, footprint/quality targets, Sol-led roles and load/performance direction. Five parameters remain in 09_FOCUSED_FOLLOW_UP.md. Concrete clock changes still need a P4.0 demo; purchases, source forks, extra 3D objects and untested hardware claims are not authorized.

The package is complete planning, not a claim its gates passed. Closure must name the implemented section, frozen inputs, actual test/visual/runtime evidence, fresh reviewer and user acceptance.


## v0.9 reconciliation precedence

Use DECISION_STATUS.json and sources/OWNER_FINAL_ANSWERS.md. Mixed multi-item plans, revenue inputs and Crystal Mountain WA are accepted; the older laptop is an optional unqualified probe and weather translation is permitted. F1_BUILDINGS is the sole current product clarification. Laptop inventory, reference shots and weather source identification are implementation evidence tasks, not unanswered broad choices. All runtime proof and independent execution remain NOT_EXECUTED.
