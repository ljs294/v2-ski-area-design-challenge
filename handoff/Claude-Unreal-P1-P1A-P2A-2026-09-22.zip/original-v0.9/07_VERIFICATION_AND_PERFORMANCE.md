# Verification and visual/performance acceptance — Unreal v0.9

## Evidence classes and cadence

Local document checks do not execute C++ or Unreal. Pure C++ tests do not establish cooked-player functionality. Editor/PIE screenshots do not establish runtime import, Shipping dependencies, hardware timing or offline behavior. Every receipt identifies class, exact frozen inputs, build/cook identity, actual commands, exit and nonzero test counts, failures/skips, and unknown metrics.

Per task run affected pure/unit and failure tests; per section run relevant engine/package workflow; at playable milestones run the selected integrated story and focused performance/visual evidence. Use near-boundary fixtures rather than mandatory simulated seasons. Do not replace explicit correctness with a screenshot, or replace appearance approval with a passing compiler. [O: Q40]

Minimal pure tests compile the SAME canonical C++ sources without Unreal include paths. Use a compatible small test runner, with pinned dependency/license, rather than mandating an engine source build. Engine Automation/Functional tests and packaged executable checks cover adapters, runtime geometry/UI/cook. P0 proves failure propagation, not merely successful execution. [E10/E11]

Read [contracts/EVIDENCE_AND_REVIEW.md](contracts/EVIDENCE_AND_REVIEW.md) for freeze and reviewer restrictions. A writable MCP endpoint makes a supposedly read-only reviewer unsafe even when its shell sandbox is read-only. Tests needing writes run in explicitly allowed scratch/output areas, not the immutable source under review.

## Canonical test catalogue

`TEST_CASES.json` owns definitions. No engine/game case has executed here. Current cases are NOT_EXECUTED; weighted cases SIM05–07 are DEFERRED_BY_OWNER and do not block P4/P5. BP08–BP11 now cover current approved grouping/data safety. WEA05 is deferred future-effects isolation; it is not a P0–P6 gate. A deferred test is not a pass. Local package checks are distinct illustrative/structural checks.

<!-- TEST_DEFINITIONS_START -->
- **CORE01** — Pure same-source C++ compilation and forbidden include/dependency negative control; no UObject/Engine source set. **NOT_EXECUTED** (CURRENT).
- **CORE02** — Deliberately failed, empty, crashed and timed-out test runs cannot produce a pass receipt. **NOT_EXECUTED** (CURRENT).
- **CORE03** — UBT/UHT, native Development/Shipping cook/package and no editor module dependency in player. **NOT_EXECUTED** (CURRENT).
- **CORE04** — Domain events remain independent of Actor visibility, recreation, frame rate and view tick frequency. **NOT_EXECUTED** (CURRENT).
- **AN01** — Analysis is keyed to input/session/terrain/config revisions; stale results cannot commit. **NOT_EXECUTED** (CURRENT).
- **AN02** — Bounded convergence/CPU/allocation/cancellation; unknown/failed analysis is not a valid estimate. **NOT_EXECUTED** (CURRENT).
- **TER01** — Meters-centimeters, axis/inverse, raster orientation/nodata and dimensions; explicit datum. **NOT_EXECUTED** (CURRENT).
- **TER02** — Adjacent tile borders, normals and different LODs show no cracks or orphaned geometry. **NOT_EXECUTED** (CURRENT).
- **TER03** — Near/far/corners/grazing picking and query-to-render error meet declared tolerance. **NOT_EXECUTED** (CURRENT).
- **TER04** — Bounded region mutation and delayed collision/query/render completion obey revision/readiness. **NOT_EXECUTED** (CURRENT).
- **TER05** — Measured load/pan/preview/grade/undo/reopen tile and CPU/GPU/staging envelope. **NOT_EXECUTED** (CURRENT).
- **VIS01** — Real mountain ground materials, sun/sky/atmosphere in agreed midday/low-angle/overcast scenes. **NOT_EXECUTED** (CURRENT).
- **VIS02** — Moving dots, thin overlays and selection remain legible at declared camera and AA/upscaling modes. **NOT_EXECUTED** (CURRENT).
- **VIS03** — The same packaged runtime-editable terrain implementation passes editability and visual acceptance. **NOT_EXECUTED** (CURRENT).
- **VIS04** — Snow layer shows identified numerical source, units and thresholds without claiming live production. **NOT_EXECUTED** (CURRENT).
- **UI01** — Mouse capture, focus, Escape, DPI, scale, resize and camera/tool ownership. **NOT_EXECUTED** (CURRENT).
- **UI02** — Runtime node viewer separates proposed, built-closed and built-open graph; layer visibility never changes operational eligibility. **NOT_EXECUTED** (CURRENT).
- **UI03** — Screenshot/clean-map export restores transients, UI visibility and camera state on success/failure. **NOT_EXECUTED** (CURRENT).
- **IO01** — In-window browser runs actual MapLibre/WebGL in packaged player with correct cleanup. **NOT_EXECUTED** (CURRENT).
- **IO02** — Preparation cancellation/retry invalidates superseded work and preserves valid installed content. **NOT_EXECUTED** (CURRENT).
- **IO03** — Required provider failure blocks activation; optional data absence is explicitly declared. **NOT_EXECUTED** (CURRENT).
- **IO04** — Paths/lengths/dimension products/checksums/nonfinite values validated before allocations. **NOT_EXECUTED** (CURRENT).
- **IO05** — Portable manifest/native import and derived-cache input+generator versions agree. **NOT_EXECUTED** (CURRENT).
- **IO06** — New mountain prepared after executable build, activated, then reopened network-denied without editor/devserver. **NOT_EXECUTED** (CURRENT).
- **IO07** — Save Game built-only coherent generations, interrupted/full-disk recovery and paused restore; never implicitly persists working blueprints. **NOT_EXECUTED** (CURRENT).
- **IO08** — Cooked content/helper dependencies present; no uncooked uasset, editor-only API or developer PATH prerequisite. **NOT_EXECUTED** (CURRENT).
- **BLD01** — Proposed first lift visible/costed but absent from live graph. **NOT_EXECUTED** (CURRENT).
- **BLD02** — Build operation is idempotent, precommit failure retains plan, success yields one canonical revision. **NOT_EXECUTED** (CURRENT).
- **BLD03** — Trail holes/reversal/splits/junctions and approved pipe nodes have valid topology. **NOT_EXECUTED** (CURRENT).
- **BLD04** — Visual/picking/index callbacks use stable IDs/revisions; deleted/reused view cannot mutate another entity. **NOT_EXECUTED** (CURRENT).
- **BLD05** — Cross-tool committed LIFO undo includes overlapping graph and terrain changes. **NOT_EXECUTED** (CURRENT).
- **BLD06** — Redo invalidates on committed edits; Load Game resets committed history, Load Blueprint does not; simulation advancement seals historical undo. **NOT_EXECUTED** (CURRENT).
- **BLD07** — Fault before commit versus during derived sync has distinct recovery, no false rollback or early Play. **NOT_EXECUTED** (CURRENT).
- **BLD08** — Actual trail preview/grade/undo fits bounded resource envelope; new operations barred during recovery. **NOT_EXECUTED** (CURRENT).
- **SIM01** — Accepted F6 individual direction implemented only after owner-approved concrete event-clock demo with units/rates/order; no hidden aggregate authority. **NOT_EXECUTED** (CURRENT).
- **SIM02** — One person/one lift/one trail and short queue complete under every included preset. **NOT_EXECUTED** (CURRENT).
- **SIM03** — Day boundary, speed change, pause/cancel and save continuation preserve declared semantics. **NOT_EXECUTED** (CURRENT).
- **SIM04** — Admissions/active/departed/service/revenue conserved independently of rendered dots. **NOT_EXECUTED** (CURRENT).
- **SIM05** — Weighted group larger than seats uses declared partial-service/residual policy without wasted capacity or overbooking. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM06** — Non-dividing weights, waits and residual queue order match promised quantities of individual reference. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM07** — Partial-service save/restore and day carryover retain weights/residual credits. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM08** — Building while running affects only built graph after coherent pause; in-flight journeys follow approved closure/removal policy. **NOT_EXECUTED** (CURRENT).
- **SIM09** — Player-set daily arrivals and fixed per-day ticket price recognize integer-cent revenue once on actual admission; estimates-only construction never changes cash and price does not change demand. **NOT_EXECUTED** (CURRENT).
- **SEC01** — Source/editor/asset freeze before build/review; mutation causes invalidation, including untracked and binary inputs. **NOT_EXECUTED** (CURRENT).
- **SEC02** — Actual independent reviewer cannot write via filesystem, GitHub, browser or editor/MCP tools. **NOT_EXECUTED** (CURRENT).
- **SEC03** — Owned binary asset automation is bounded, repeatable and does not overwrite unrelated dirty/manual changes. **NOT_EXECUTED** (CURRENT).
- **SEC04** — Browser origin/message/path validation rejects forged, stale and oversized messages. **NOT_EXECUTED** (CURRENT).
- **SEC05** — Shipping player has no unexpected MCP/editor/dev/debug listener or write bridge. **NOT_EXECUTED** (CURRENT).
- **PERF01** — Complete frame interval window incl start/end/max gaps; two-second synthetic stall rejected. **NOT_EXECUTED** (CURRENT).
- **PERF02** — Cold/warm first-use shaders/PSO/load/view-travel/first-grade separated and honestly recorded. **NOT_EXECUTED** (CURRENT).
- **PERF03** — Live guest/clock/revision progress and real workload shown during integrated camera/build/save test. **NOT_EXECUTED** (CURRENT).
- **PERF04** — Only actual hardware/RHI/quality/resolution lanes can be qualified; inventory the optional old laptop and never infer compatibility or minimum support from age. **NOT_EXECUTED** (CURRENT).
- **WEA01** — Existing numerical backend identified through traced source and pinned behavior fixtures before helper/package integration or permitted language translation; preserve versions, seed, units and timezone identity. **NOT_EXECUTED** (CURRENT).
- **WEA02** — Host cancellation/checkpoint/restore/event order with one game-clock authority. **NOT_EXECUTED** (CURRENT).
- **WEA03** — Offline weather projection and near-boundary snow/UI tests without a default full season. **NOT_EXECUTED** (CURRENT).
- **BP01** — Only explicit Save Blueprint persists proposal content; Save Game excludes dirty working plans and warns without implicit save or discard. **NOT_EXECUTED** (CURRENT).
- **BP02** — Load Blueprint creates proposed data only: no Build, clock/speed/pause change, ticket event, operating-state change or committed undo reset. **NOT_EXECUTED** (CURRENT).
- **BP03** — Independent game-save and blueprint-save generations survive interruption/full disk/failed overwrite without corrupting each other. **NOT_EXECUTED** (CURRENT).
- **BP04** — Saved blueprint terrain/document/anchor bindings validate; stale costs/grading recompute; reused built IDs and build operation tokens never resurrect. **NOT_EXECUTED** (CURRENT).
- **BP05** — Save captures one draft revision; later edits remain dirty, and out-of-order completion cannot overwrite a newer saved generation. **NOT_EXECUTED** (CURRENT).
- **BP06** — Dirty plan replacement/exit uses explicit Save/Discard/Cancel; repeated load replaces safely rather than appending duplicate working entities. **NOT_EXECUTED** (CURRENT).
- **BP07** — Saved blueprint and active blueprint write references protect required terrain content from cleanup; missing content never substitutes another mountain. **NOT_EXECUTED** (CURRENT).
- **BP08** — Multi-item trail-pod Build All or explicitly selected subset uses shown dependency closure and one canonical commit; single-item P2.1 is only the bootstrap slice. **NOT_EXECUTED** (CURRENT).
- **OP01** — New infrastructure is Closed; Open validates declared connectivity/exit policy; node viewer separates built existence and operational eligibility. **NOT_EXECUTED** (CURRENT).
- **OP02** — Close prevents new entries, preserves in-flight geometry and safe completion, and rejects changes that would strand guests. **NOT_EXECUTED** (CURRENT).
- **OP03** — Deletion rejects live journey/queue/anchor references; operating changes stay coherently paused until user Play; no teleport/depopulation/revenue rewind. **NOT_EXECUTED** (CURRENT).
- **SIM10** — Individual active-cap admission at cap and cap+1 is bounded and visible; pending arrivals are not guests, weights or earned tickets. **NOT_EXECUTED** (CURRENT).
- **SIM11** — Requested/admitted/pending/unadmitted and active/departed accounting survives retries, capacity release, day end and save/restore without hidden demand loss. **NOT_EXECUTED** (CURRENT).
- **VIS05** — Overlapping design/analysis layers retain readable contrast, stable hit priority and bounded updates at agreed cameras/profiles; hiding layers changes no game state. **NOT_EXECUTED** (CURRENT).
- **BP09** — Mixed saved pod preserves lifts, trails, snowmaking and bounded building plan records plus typed internal/external links; fresh-ID remapping retains shared nodes and does not duplicate live entities. **NOT_EXECUTED** (CURRENT).
- **BP10** — Unsupported or future building entries retain bounded non-executable payloads and visible diagnostics through save/load; dependent Build is blocked and no item is silently dropped or costed as zero. **NOT_EXECUTED** (CURRENT).
- **BP11** — Successful selected Build coherently rewrites remaining working-plan links through proposal-to-built mapping; undo and later builds preserve topology without overwriting the saved source plan. **NOT_EXECUTED** (CURRENT).
- **SIM12** — Locked daily arrivals/price and next-day edits survive restore; pending/duplicate/re-entry-not-supported/day-boundary cases cannot double-charge or introduce price-demand feedback. **NOT_EXECUTED** (CURRENT).
- **WEA04** — Any backend language translation compares pinned source fixtures, discrete events, RNG/checkpoint/calendar behavior and declared continuous tolerances; no unapproved numerical model redesign. **NOT_EXECUTED** (CURRENT).
- **WEA05** — Future cosmetic weather/cloud effects consume read models and independent cosmetic randomness; quality toggles never alter authoritative weather, clocks, guest state or saves. **DEFERRED_BY_OWNER** (FUTURE_WEATHER_EFFECTS).
<!-- TEST_DEFINITIONS_END -->

## Visual acceptance is a real gate

Freeze reference mountain/package/camera, output and internal resolutions, graphics backend, quality and material settings. Accepted U1/U2/U3 specify hybrid terrain/overlays, overview/moderately close camera and appearance-based acceptance. U5 still needs an actual reference; record the concrete camera shot and profile identity. Suggested scenes are clear midday, low-angle sunlight and overcast, each resort-wide and closest zoom. They are visual fixtures, not a weather model requirement.

The same runtime-created/editable terrain is shown in every scene. A static Nanite asset, cooked landscape or editor preview cannot substitute. Show near/far normals/seams, grade before/after, picking at cliffs, readable trails/dots, and scaled UI. Owner approves appearance and interaction; the reviewer checks representation identity and measurements. Do not silently add decorative meshes or raise minimum hardware to pass. Record antialias/upscaler ghosting/shimmer on thin lines and dots as well as terrain appearance.

## Performance lanes: proposals versus promises

Owner contract remains 30-FPS minimum / 60-FPS target. F12 accepts the candidate two-profile approach and provisional 250-ms stall backstop; no weaker physical machine was supplied. Record actual hardware and freeze any remaining engineering percentile targets before qualification. Proposed initial lanes are the existing reference PC and a candidate lower-end desktop GTX1650 4GB/16GB RAM/SSD/1080p Low; exact CPU/GPU/RHI must be recorded. No claim that this candidate achieves any frame rate or even supports the desired feature combination. Epic's renderer targets are not game measurements. [E08]

Record physical output AND internal render resolution, AA/upscaler/frame-generation setting, quality components, actual GPU/driver/CPU/RAM/OS/power state, RHI/shader model, executable/config/cook hashes, content hashes, counters and availability of memory data. Disable frame generation for primary timing or report it as a distinct lane; interpolated frames cannot disguise stalled input/simulation. DX12/SM6 is a conditional visual-feature candidate, not a reason to claim a DX11 fallback is equivalent or tested.

| Metric | Initial proposed ordinary-gameplay bound | Status |
|---|---|---|
| Frame p95 | <=33.3ms Low lane; <=20ms reference lane | F12 proposal; not an absolute guaranteed 30/60 lock |
| Frame p99 | <=50ms Low; <=33.3ms reference | F12 proposal |
| Intervals over50ms | <1%, report count and duration | Alone insufficient; synthetic test demonstrates loophole |
| Maximum ordinary frame gap | <=250ms, with start/end gaps included | Accepted initial backstop; not measured, and visible stutter may still fail visual review |
| Selection/pause feedback p95 | <=100ms on qualified lane | Proposed measurable responsiveness |
| Cancellation acknowledgment | <=250ms | Proposed; never fake completed cancellation |
| Terrain/query readiness after Build | Report actual; input/progress stays responsive | Scoped bounded-work budget, not instant completion |
| Reopen to required interactive readiness | <=30s standard prepared fixture | Accepted initial fixture target; not measured |

Always report maximum gap and counts/durations over50/100/250ms. The 250ms backstop is not a claim occasional quarter-second hitches look good; appearance review can reject visible stuttering even when a loose threshold passes. Freeze final acceptance before measuring. All start/end/unrendered portions of the wall-time window count. A stopped renderer or non-advancing required simulation invalidates the run.

Preparation, deliberately paused Build/derived recovery and manual save/load are separate PREDECLARED operation windows with UI-liveness/latency/readiness metrics. Do not relabel accidental gameplay freezes after the fact. Blueprint planning while running remains ordinary gameplay. Tag work consistently in both candidates when comparing.

Begin with a bounded repeatable warm-up and roughly120s representative integrated lane, plus distinct cold-start/first-use samples. These durations are measurement proposals, not waiting instructions or season tests. Repeat only enough to establish stability or investigate a decision; diagnostic traces and low-overhead timing are separate runs. Frame samples are not independent experiment replications. Report variance/inconclusive outcomes rather than claiming statistically established speedups from one pass.

P1 synthetic dots isolate rendering; P4/P5 require actual guest routing/queues/clocks and selected snow/visual updates. Report requested/admitted/pending/unadmitted arrivals, active actual people and submitted/visible/drawn dots separately. Current weighted population is explicitly absent; do not implement it to populate a benchmark field. Do not win a benchmark by silently reducing work. Targeted repeated map reload, construction and checkpoint cycles assess retained resources; long retention work is bounded and justified by the change under review, not a default season exercise.

## Cook, shaders and release

Before qualification use one frozen input state and a normal native compile/cook. Live Coding/hot reload cannot certify a clean build. First camera travel, unseen materials, first grade and cold PSO/driver cache are explicit hitch cases. Cook the referenced materials/permutations and test first use; a PSO setting alone does not certify completeness. [E15/E16]

Packaged Development may supply diagnostics. Required Shipping functional smoke proves absent editor-only classes/listeners and real content/helper staging. Shader caches, debug overhead and different package settings are identified rather than mixed across results. Test offline with actual required mountain/imagery/fonts/UI rendered, not simply with blocked network exceptions hidden.

## Completion story for selected scope

In one packaged Windows application: select a mountain -> prepare with informative progress -> enter convincing terrain -> plan lift/trail network and inspect nodes -> explicit Save Blueprint/Load Blueprint -> Build Closed while pausing and synchronize correct queries -> validate/Open -> separate Save Game/reopen -> use selected snowmaking layout -> spawn simple guests and observe approved queues/runs/ticket revenue -> plan during play/Build/pause/manual resume -> capture a clean map -> reopen offline. Test small controlled time boundaries, not a full season. Deferred weather is separately named, not silently necessary for a phase declared complete.

## Staged assertion evidence, not premature gate inflation

A case may be introduced by a source/specification task, exercised by a tiny fixture, and repeated in the actual packaged integration. Receipts must name which assertions and implementation were tested. An accepted definition, test double or scoping decision is not a blanket runtime PASS. P0.4 owns extraction inventory, not the later packaged helper test. P3.1 defines analysis expectations; actual AN01/AN02 execution occurs with P3.2. P4.0 is a small timing proof; production-host cases repeat after implementation. Future weighted cases remain deferred and never enter the P5 required-test denominator.

## v0.9 reference and weather/effects qualification

Use Crystal Mountain WA as the named real-terrain visual reference and retain synthetic numerical fixtures. Exact acquired data/bounds and camera shots are implementation evidence; no provider data was fetched in this amendment. The available older laptop is a separate optional hardware probe after actual specification capture, never an age-derived guarantee or replacement for a qualified reference/minimum lane.

P2 tests multi-item storage/link remapping with currently available tools; P3.4 adds the actual snowmaking-member workflow. Building-record tests can use labeled data fixtures before a building tool exists. A retained unsupported record is not proof it is buildable. Weather translation tests start from pinned existing outputs; future visual effects/clouds may be independently implemented but cannot gate P6 numerical acceptance or change simulation truth when toggled.
