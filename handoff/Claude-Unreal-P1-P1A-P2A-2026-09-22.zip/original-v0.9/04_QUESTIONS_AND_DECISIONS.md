# Owner-authoritative decision register — Unreal v0.9

## Precedence and evidence

Latest [five direct answers](sources/OWNER_FINAL_ANSWERS.md) supersede the [captured follow-up questionnaire](sources/OWNER_FOLLOW_UP_RESPONSES.md); original [forty answers](sources/OWNER_RESPONSES.md) remain authoritative where unchanged. DECISION_STATUS.json preserves earlier verbatim answers and the later overrides separately. Product acceptance is not runtime evidence.

All 16 questionnaire answers and all five latest replies are incorporated. Mixed blueprint grouping, revenue input policy and the mountain identity are settled. One building-tool scope clarification remains; laptop specifications and exact weather source tracing are engineering tasks at their owning phases, not five repeated open questions.

## Reconciled follow-up directions

| ID | Status | Current rule |
|---|---|---|
| U1 | ACCEPTED | Hybrid naturalistic terrain/light/atmosphere with clean, performant overlays; no modeled-object scope increase. |
| U2 | ACCEPTED | Overview and moderately close camera, not walking/skiing. Concrete camera shot remains a technical/visual fixture. |
| U3 | ACCEPTED | Judge the same editable playable result, not Nanite/Lumen branding; approve both visual profiles. |
| U4 | ACCEPTED | Free/built-in first; no item is authorized for purchase. No numeric ceiling supplied; no spending mandate inferred. |
| U5 | ACCEPTED_CRYSTAL_MOUNTAIN_WA | Crystal Mountain, Washington is the named visual reference. Technical work selects source data/bounds and proposes overview/moderately-close shots for owner review; no invented must-preserve named chute or measured data quality. |
| F1 | ACCEPTED_MULTI_ITEM_EXPLICIT_SAVE | One saved blueprint may hold an entire mixed trail pod: lifts, trails, snowmaking and building plan records, retaining links and grouping. Explicit Save/Load remains separate from Save Game. Building placement/tool delivery timing is the only remaining product clarification. Build Selected with visible dependency closure is an engineering UI default, not a verbatim owner answer. |
| F2 | RESOLVED | Existing cross-tool committed LIFO safety remains; Load Blueprint is not Load Game. |
| F3 | ACCEPTED | Explicit Open/Closed; new infrastructure Closed; validate/open while paused; Play remains manual. |
| F4 | ACCEPTED | Nodes, pipes, guns, existing-water references and verified estimates only. No pump layout/hydraulic sizing commissioned. |
| F5 | ACCEPTED | Informational construction costs; player-set daily arrivals and a fixed ticket price per operating day; no price-demand feedback or budget gate. Recognize integer-cent revenue once per actual admission; price-lock/re-entry details are scoped engineering defaults. |
| F6 | DIRECTION_ACCEPTED_DEMO_REQUIRED | Genuinely individual people; retain dual-clock intent, approve exact revised mapping after a tiny demo; first operating milestone individual-only, weighting deferred. |
| F7 | TARGET_ACCEPTED_NOT_QUALIFIED | 2–10 km per side, fixed boundary and lower-detail surround; limits require measured quality/footprint envelope. |
| F8 | ACCEPTED | Source-aware Standard/High; explicitly selected High can exceed about five minutes; no silent degradation. |
| F9 | RESOLVED_SPIKE | Same-window selector plus full preparation proof; actual host remains technical candidate. |
| F10 | PRESERVE_BEHAVIOR_TRANSLATION_ALLOWED | Retain the existing numerical weather backend behavior. Another-language rewrite, including C++, is permitted when justified and behavior-tested. At P6 trace gameplay versus lab source before freezing the intended reference; user has not chosen one by name. New Unreal visual effects/dynamic clouds are separate future work, not required for P0–P6 backend integration. |
| F11 | ACCEPTED | Sol High owns all routine delegation/coordinating review. Terra High implements and performs all adversarial review. Astra very sparing, high-level decisions only. |
| F12 | LAPTOP_AVAILABLE_SPECS_UNVERIFIED | Owner has an approximately ten-year-old laptop. Treat it as an optional physical compatibility/performance probe after CPU/GPU/RAM/OS/storage/driver inventory, not a committed minimum specification or a proxy for the candidate GTX1650 lane. Existing accepted targets remain. |
| F13 | TARGET_ACCEPTED_NOT_MEASURED | Prepared-save <=30s to genuine interactive readiness on declared standard fixture; cold/warm reported, no provider work. |

## Carried-forward original answers, reconciled

| Question | Status | Interpretation and remaining work |
|---|---|---|
| Q1 | ACCEPTED | Lift/trail/node tools and viewer first; F4 now approves the limited early snowmaking layout subset. |
| Q2 | ACCEPTED | Smooth/useful design first, simulation correctness next, extra detail within budget. |
| Q3 | ACCEPTED | Windows only; cheap future portability welcome but no macOS/Linux workstream. |
| Q4 | TARGET ACCEPTED; OPTIONAL LAPTOP | Older laptop available, specs/compatibility unverified; Low/High targets unchanged. Inventory/test actual hardware before claims. |
| Q5 | ACCEPTED UX; SPIKE | Single window mandatory. Bounded host and complete preparation proof planned under R02; F9 permission-to-plan resolved, final host selected only after technical proof. |
| Q6 | TARGET ACCEPTED | F7 accepts fixed 2–10 km per-side target; qualify each footprint/quality combination. Expansion future. |
| Q7 | ACCEPTED | Personal now, possible commercial later; prefer free/open commercially usable dependencies; not blanket approval of licenses/services. |
| Q8 | ACCEPTED | Local Unreal runner and owner visual checks available; verify actual installation in P0. |
| Q9 | ACCEPTED | Dots only; no carving or character art now. |
| Q10 | DIRECTION UPDATED BY F6A | True individuals take precedence where exact old mappings conflict; retain dual-clock intent and familiar controls. Concrete changed mapping requires tiny demo approval at P4.0. |
| Q11 | ACCEPTED | Spawn selection and run choice; injuries/patrol, vehicles, lodging deferred. |
| Q12 | LATER CORE; TRANSLATION PERMITTED | Preserve numerical backend behavior; C++/other-language port permitted. P6 traces exact source; new dynamic visual weather is future work. |
| Q13 | ACCEPTED | Snow layer map now; physical depth geometry future. Initial data/source and detailed natural-snow behavior not fully specified. |
| Q14 | ACCEPTED EXCLUSION | Operational snowmaking/grooming deferred; layout is separate. |
| Q15 | INDIVIDUAL FIRST; WEIGHTING DEFERRED | F6B explicitly defers weighted mode beyond first operating release; ~3,000 active individuals is a target. Cap/arrivals accounting still needs a contract. |
| Q16 | ACCEPTED | Daily arrivals set by player; fixed daily ticket price; no price-demand feedback; once-only admission revenue. Construction estimates only. |
| Q17 | ACCEPTED MULTI-ITEM PLANS | Explicit save/load can hold an entire pod with heterogeneous records including buildings. Building tool timing remains F1_BUILDINGS; no 3D art expansion. |
| Q18 | ACCEPTED | New direction. Characterize selected reference behavior; approve/test differences instead of rigid full parity. |
| Q19 | ACCEPTED FLEXIBILITY | Prefer North America; lower 48 acceptable for initial guaranteed coverage if other data inadequate. |
| Q20 | ACCEPTED INTENT; CRYSTAL REFERENCE | Crystal Mountain WA is the visual reference. Real source feature preservation, Standard/High and performance require actual proof. |
| Q21 | ACCEPTED | Trail grading only; general landscaping future. Dam/pond construction not automatically retained. |
| Q22 | ACCEPTED FUTURE | Sharing future; do not implement complete package export now. |
| Q23 | ACCEPTED | Fully offline gameplay after initialization; no data streaming over the network. |
| Q24 | TARGETS ACCEPTED | F8 permits explicitly longer High preparation. F13 accepts <=30s standard prepared-save interactive target, not measured performance. |
| Q25 | ACCEPTED | Reusable data tools allowed; numerical weather may be translated. Choose one evidence-based offline host at P6, not multiple speculative adapters. |
| Q26 | PARTIAL | Preserve organization/redesign bad interaction as recommended; no three concrete pain points supplied. Use actual P1/P2 workflow review. |
| Q27 | ACCEPTED EXCLUSION | Terrain-only modeled 3D. Infrastructure lines/layers, no modeled buildings/chairs now. |
| Q28 | TECHNICAL SAFETY RESOLVED; UI task-scoped | Tool-local draft undo plus one cross-tool committed LIFO history incorporated under R05/F2. No selective rollback or simulation rewind. Per-tool focus/gesture details are specified and demonstrated with the tool. |
| Q29 | ACCEPTED | Manual Save Game, safe writes and paused restores; explicit separate Save/Load Blueprint. Autosave not current. |
| Q30 | ACCEPTED | Keyboard/focus/scale/readable overlays. Controller/full assistive technology not automatically approved. |
| Q31 | ACCEPTED | English only; keep formatting/units explicit. |
| Q32 | ACCEPTED | Screenshots and clean trail map only; broad reports/terrain export deferred. |
| Q33 | ACCEPTED EXCLUSION | No multiplayer planned. |
| Q34 | ACCEPTED INTENT | Avoid needless barriers to future mods; no current executable-mod commitment. |
| Q35 | ACCEPTED EXCLUSION | No cloud saves/accounts now; local authority. |
| Q36 | ACCEPTED | Unreal-only work in v2; original game remains separate and must not be maintained or changed here. |
| Q37 | ROLE POLICY ACCEPTED; CLIENT CHECK | VS Code Codex, Sol High routine coordinator/reviewer; Terra High actual implementation/adversarial review; Astra very sparing. Verify installed routing, not token-saving claims. |
| Q38 | ACCEPTED | Only predefined tasks; user alone stages/commits. Latest F11 replaces older always-Astra/mandatory-gate Astra cadence. |
| Q39 | ACCEPTED | At most two implementers plus a reviewer, fewer for shared files; one integration/test owner, frozen qualifying inputs. |
| Q40 | ACCEPTED | Robust targeted tests; no full-season default acceptance run. Does not waive integrity, boundary or independent review checks. |

## Explicitly NOT inferred

Mixed-plan grouping is now expressly approved. It does not alone approve 3D building art, amenities or a full building tool. Crystal Mountain is named, but no specific data tile/resolution or must-preserve named chute is claimed. Laptop availability is not a hardware specification or support guarantee. Weather language translation is allowed, but gameplay-versus-lab source identity must still be traced before implementation. U4 remains no purchase without item-specific approval.

The accepted F6 direction permits proposing necessary mapping changes; the exact event-clock table still needs the agreed P4.0 demonstration before production implementation. Weighted-mode deferral is already approved and must not be reopened as an unanswered scope choice.

## Engineer-owned choices

Implementers select scoped APIs, serialization layouts, cancellation mechanics, temporary IDs, collision/query tactics and test-fixture parameters within the contracts. Safe initial defaults (same-resort plan binding, no implicit build on load, no unsafe closure/teleportation) are labeled in their contracts rather than described as verbatim owner requests. No generic framework, infinite rewrite or expansion is authorized by missing details.
