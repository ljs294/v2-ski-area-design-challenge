# Unreal v0.9 — concise implementation/review brief

## Product and settled answers

One Windows Unreal replacement in the v2 repository, not a parallel old game. Runtime-selected real mountain, fixed 2–10 km target, offline after preparation. Hybrid naturalistic terrain/light with clean legible overlays. Overview/moderately close camera; terrain is the only modeled subject, dots for guests. No Nanite/Lumen requirement; same runtime-editable mountain must satisfy appearance and performance.

Lift/trail/node tools and runtime node-map viewer; costs for estimates only; plan while running. **Separate Save Blueprint/Load Blueprint**, persistence only on explicit plan save. Save Game excludes working plans. Load Blueprint never builds or changes clocks. Build pauses coherently, creates Closed infrastructure, synchronizes graph/mesh/queries, and remains paused for operating adjustments/manual Play. Cross-tool committed LIFO undo remains safe across grading.

Limited snowmaking nodes/pipes/guns/existing-water references and verified estimates; no pump/hydraulic sizing or operating production commissioned. Basic individual guest loop and ticket revenue; approximately 3,000 active target, weighted mode explicitly deferred. Exact clock interpretation requires a P4.0 demo. No amenities, full economy, modeled objects, landscaping, physical snow, grooming, autosave, cloud or multiplayer. Weather later.

## Work and audit

Sol High performs all normal delegation and coordinating review. Terra High implements and performs fresh adversarial review. Astra participates very sparingly for exceptional high-level decisions. Only the user stages/commits. One binary-asset writer and one build owner; freeze sources/editor/MCP writes while qualifying. Read-only reviewers must lack external editor/connector write routes.

Sequence: P0 small pure C++/native/tooling boundary -> P1 SAME packaged runtime terrain visual/editability/setup proof -> P2 explicit saved blueprint/lift/trail designer -> P3 selected snowmaking + P4 reduced operation -> P5 qualified selected scope -> P6 weather. No full engine before terrain or season-long default tests.

Latest audit added explicit plan-library failure semantics, safe operating closures, individual cap/arrival accounting, and a single canonical test-ID definition source. R01–R10 and ER01–ER08 safeguards remain. Synthetic/document checks are NOT Unreal validation or independent-agent review.

## Still missing, not permission to guess

Only F1_BUILDINGS asks whether simple current footprint placement or future building tooling is intended. Multi-item plans and revenue inputs are approved; Crystal Mountain WA is selected. Inventory the optional old laptop and trace the exact weather source at their engineering gates. F6's high-level choice is resolved; the concrete mapping demo is a future engineering approval. None of the missing inputs blocks bounded P0. See 09_FOCUSED_FOLLOW_UP.md.

## Critical evidence

Same packaged terrain instance imports a package created after the executable, renders the intended look, accepts local changes, keeps queries/picking aligned and reopens offline. Blueprint and game saves fail independently without corruption. Load Blueprint cannot reset the world. Closed/open state differs from graph existence and layer visibility. Measurement includes cold shaders, full frame gaps, real capacity and visible-vs-simulated counts. Local target approval is not a hardware pass.

No independent agents, C++ game compile, Unreal/GPU/provider runs or repository/cloud edits occurred in this planning revision. Current answer audit and blockers: 15_OWNER_ANSWER_RECONCILIATION.md. The v0.8 audit is retained historical evidence. Independent assignments exist for actual Codex execution.

## Current answer amendments

Save an entire mixed trail pod in one blueprint: lifts, trails, snowmaking and building plan records with intact links. Unknown/not-yet-buildable members stay intact with diagnostics; no silent removal or partial transaction. Building record support is approved; placement tooling timing alone is open. Build Selected remains a minimal engineering interface recommendation with explicit dependency confirmation.

Player-set daily arrivals and fixed daily ticket price are approved, with once-per-actual-admission revenue and no price elasticity. Crystal Mountain WA is the real-terrain reference. Treat the ten-year-old laptop as optional/unqualified until inventoried. A language rewrite of the numerical weather backend is allowed; do not redesign it accidentally. New Unreal weather effects and dynamic clouds remain future features, independent of P6 backend completion.
