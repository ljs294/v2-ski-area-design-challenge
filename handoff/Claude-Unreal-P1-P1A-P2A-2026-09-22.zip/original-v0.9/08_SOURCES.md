# Evidence and source register — Unreal v0.9

**Research checked:** September 18, 2026. Source facts, owner decisions and planning recommendations are different categories. No webpage constitutes a performance or feasibility test of this game. Versioned behavior must be rechecked against the installed patch before implementation.

## Owner and prior plan

- **O:** Original forty answers and FPS note in [sources/OWNER_RESPONSES.md](sources/OWNER_RESPONSES.md), preserved exactly from v0.6. Not refreshed from Drive; no claim about later unseen edits.
- **CHANGE:** Current Unreal instruction in [sources/OWNER_ENGINE_CHANGE.md](sources/OWNER_ENGINE_CHANGE.md). It selects engine, not new feature scope.
- **H:** Unchanged [historical Unreal v0.7 archive](sources/HISTORICAL_UNREAL_V07.zip), SHA-256 `7c92b120e1c6b497f84bcb281884bb29a28e3f87c2c8b1048ec35361a33aadb7`. It contains the prior Unity v0.6 archive as nested historical reference. Historical instructions/tests are not active v0.9 requirements.
- **R/ER:** Earlier audit and external-review decisions are mapped in current ledgers; their historic numerical examples are not newly measured game failures.

## Repository basis

Connected GitHub read of `main` returned `1cca4e0808b96fa0fc43d48c4289a118b29b30ec`, matching the planning reference. This read verifies remote main identity only, not local working changes, all branches, CI health or a new whole-source audit. The prior sampled architecture, preparation, terrain/storage, dual-clock and UI paths remain source navigation targets. P0 must trace actual selected code before moving/removing it.

Remote identity: https://api.github.com/repos/ljs294/v2-ski-area-design-challenge/branches/main
Pinned root: https://github.com/ljs294/v2-ski-area-design-challenge/tree/1cca4e0808b96fa0fc43d48c4289a118b29b30ec

## Primary research

### E01 — Epic: Unreal Engine 5.8 release announcement

https://www.unrealengine.com/news/unreal-engine-5-8-is-now-available

**Supports / limit:** Released June 23, 2026; Mesh Terrain and MCP identified as Experimental. Establishes a released series, not a locally tested patch.

### E02 — Epic: Geometry Scripting User Guide

https://dev.epicgames.com/documentation/unreal-engine/geometry-scripting-users-guide-in-unreal-engine

**Supports / limit:** Dynamic Mesh runtime updates; Geometry Framework separate from Geometry Scripting; documented Nanite/Lumen and other limitations; Blueprint call threading caveats.

### E03 — Epic: Mesh Terrain and compiled sections

https://dev.epicgames.com/documentation/unreal-engine/crafting-mesh-terrain-in-unreal-engine

**Supports / limit:** Editor preview versus compiled sections. Does not establish arbitrary player-runtime authoring/cooking.

### E04 — Epic: Blueprint vs C++

https://dev.epicgames.com/documentation/unreal-engine/coding-in-unreal-engine-blueprint-vs-cplusplus

**Supports / limit:** Context-dependent tradeoffs, C++ foundation/Blueprint composition, text collaboration and high-workload considerations.

### E05 — Epic: Unreal Engine modules

https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-modules

**Supports / limit:** Build.cs/Target.cs and module dependency structure; not a compiler proof of this proposed pure source set.

### E06 — Epic: editor modules

https://dev.epicgames.com/documentation/unreal-engine/setting-up-editor-modules-for-customizing-the-editor-in-unreal-engine

**Supports / limit:** Runtime/editor separation and editor-only compilation.

### E07 — Epic: Nanite with Landscapes

https://dev.epicgames.com/documentation/en-us/unreal-engine/using-nanite-with-landscapes-in-unreal-engine

**Supports / limit:** Derived build/rebuild workflow and retained data costs; no automatic runtime import/mutation guarantee.

### E08 — Epic: Lumen performance guide

https://dev.epicgames.com/documentation/unreal-engine/lumen-performance-guide-for-unreal-engine

**Supports / limit:** Current quality tiers, internal/output resolution and Low disabling Lumen. Epic targets are not game benchmarks.

### E09 — Epic: World Partition

https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition-in-unreal-engine

**Supports / limit:** Cell/source-based world streaming; not required merely because a bounded map is open or proof of runtime generated-terrain identity.

### E10 — Epic: Low-Level Tests

https://dev.epicgames.com/documentation/en-us/unreal-engine/low-level-tests-in-unreal-engine

**Supports / limit:** Catch2-based lightweight tests. Available build targets must be checked in the actual installation.

### E11 — Epic: Automation Test Framework

https://dev.epicgames.com/documentation/en-us/unreal-engine/automation-test-framework-in-unreal-engine

**Supports / limit:** Engine automation testing surfaces; does not replace packaged functional/visual checks.

### E12 — Epic: units and coordinate system

https://dev.epicgames.com/documentation/en-us/unreal-engine/units-of-measurement-in-unreal-engine

**Supports / limit:** Default centimeter distance units. Companion coordinate documentation below establishes handedness/Z-up; our East/North mapping is a design choice.

### E13 — Epic: Large World Coordinates

https://dev.epicgames.com/documentation/en-us/unreal-engine/large-world-coordinates-in-unreal-engine-5

**Supports / limit:** Large-world precision support, not a guarantee that every custom render/physics path is double precision.

### E14 — Epic: Unreal Insights

https://dev.epicgames.com/documentation/en-us/unreal-engine/unreal-insights-in-unreal-engine

**Supports / limit:** Profiling/tracing tooling; actual game measurements have not been performed.

### E15 — Epic: Packaging Unreal Engine projects

https://dev.epicgames.com/documentation/unreal-engine/packaging-your-project

**Supports / limit:** Build/cook/stage/package; cooked assets versus runtime content; cook-on-the-fly is not an approved end-user dependency.

### E16 — Epic: PSO precaching

https://dev.epicgames.com/documentation/unreal-engine/pso-precaching-for-unreal-engine

**Supports / limit:** Shader pipeline-state precache and possible first-use costs. Enabling a setting alone is not proof of hitch-free gameplay.

### E17 — Epic API: UWebBrowser

https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/WebBrowserWidget/UWebBrowser

**Supports / limit:** Runtime browser widget surface. MapLibre/WebGL, security and packaged cleanup still require proof.

### E18 — Epic: Python editor scripting

https://dev.epicgames.com/documentation/unreal-engine/scripting-the-unreal-editor-using-python

**Supports / limit:** Editor-only Python; supported asset APIs and caveats. Does not provide Python in the shipped game.

### E19 — Epic: Unreal MCP

https://dev.epicgames.com/documentation/unreal-engine/unreal-mcp-in-unreal-editor

**Supports / limit:** Experimental bridge, toolsets, local listener/security, serialized calls, config generation and runtime-capable modules. Installed capability and permissions must be verified.

### E20 — Epic: engine licensing

https://www.unrealengine.com/license

**Supports / limit:** Current licensing overview. Before release review actual EULA, distribution/royalty obligations and all independent asset/data/plugin terms. Source access is not a permissive open-source license.

### E21 — OpenAI: Codex subagents

https://developers.openai.com/codex/subagents

**Supports / limit:** Current model/effort configuration, agent files and inherited session settings; model names in examples do not prove account availability or effective permissions.

### E22 — Epic: Visual Studio toolchain setup

https://dev.epicgames.com/documentation/unreal-engine/setting-up-visual-studio-development-environment-for-cplusplus-projects-in-unreal-engine

**Supports / limit:** UE5.8 supports documented MSVC/VS/SDK combinations. VS Code editing does not replace required Windows C++ build tools; verify local versions.

### E23 — Epic: coordinate system

https://dev.epicgames.com/documentation/en-us/unreal-engine/coordinate-system-and-spaces-in-unreal-engine

**Supports / limit:** Left-handed, Z-up conventions. Our canonical ENU-meters to north/east/up-centimeters adapter and winding tests are recommendations.

## Recommendations not asserted as source facts

The C++ pure-source layout, UMG presenter structure, fixed local frame, initial runtime tile candidate, quality acceptance, LIFO runtime undo, review isolation and phase sequencing are project design recommendations. They are supported by source capabilities and owner goals, but they are not claims Epic/OpenAI endorses this architecture or that it has been built. U1–U5 and remaining F choices retain proposal status until answered.

The prior conversation's broad visual endorsement of Unreal is narrowed here: Nanite/Lumen capabilities for pre-authored assets do not prove the same features on player-created editable terrain. This limitation is central to P1, not postponed until final polish.

## Verification limits

No Unreal editor/player, MSVC/UBT/UHT/cook, graphics backend, MapLibre runtime, provider acquisition, shader/PSO benchmark, actual model routing or independent review was executed during this revision. Local structural and synthetic checks are in DOCUMENT_CHECKS.json. No material/texture/font/engine binary is supplied.

## v0.9 owner reconciliation and targeted rechecks

The supplied `09_FOCUSED_FOLLOW_UP.docx` is preserved as exact paragraph text in [OWNER_FOLLOW_UP_RESPONSES.md](sources/OWNER_FOLLOW_UP_RESPONSES.md), with its byte hash in [PROVENANCE.json](evidence/PROVENANCE.json). All 16 answer blocks are accounted for; F2/F9 were already resolved. No live Drive refresh or repository refresh was performed in this edition. Current decision interpretations are separate from that source.

- **V08-E1:** Epic, Geometry Scripting User Guide, checked September 18, 2026: https://dev.epicgames.com/documentation/en-us/unreal-engine/geometry-scripting-users-guide-in-unreal-engine . Runtime Dynamic Mesh updates documented, Nanite/Lumen unsupported for the component, generated-mesh actor functions can be editor-only. Does not certify this game's terrain.
- **V08-E2:** Epic, UE5.8 availability, checked September 18, 2026: https://www.unrealengine.com/news/unreal-engine-5-8-is-now-available . Released engine, with experimental features individually qualified. No patch installed/tested here.
- **V08-O1:** OpenAI subagent configuration, checked September 18, 2026: https://developers.openai.com/codex/subagents . Explicit model/effort and sandbox configuration are documented; runtime account/client availability and effective tools are not proven by a template.

The former MCP article could not be refreshed in this session; its E19 citation remains a historical reference, not newly verified availability. No new factual conclusion relies on that failed refresh. Security requirements remain project safeguards. No numerical pricing/royalty or product-purchase advice is supplied.

## O-final — directly supplied five answers (v0.9)

[sources/OWNER_FINAL_ANSWERS.md](sources/OWNER_FINAL_ANSWERS.md) and its JSON capture the current conversation answers verbatim. These approve multi-item pods and ticket inputs, name Crystal Mountain WA, identify an older laptop of unknown specification, and permit numerical-weather translation with future visual effects. Technical references elsewhere are carried forward from the earlier plan; they were not newly retrieved/verified in this amendment. User-provided place/machine descriptions are not provider coverage or benchmark evidence.
