# Unreal incremental implementation playbooks — v0.9

Each section has one scoped task or small task group, explicitly allowed files, source identity, tests, fresh review, and user acceptance. Only the user commits. An unresolved gate blocks its dependent implementation, not unrelated small experiments. No overall implementation authorization is implied by this planning request.

## Dependency and stop policy

P0 minimal native/test/governance -> P1 packaged runtime terrain + visual/editability proof + same-window preparation -> P2 saved designer -> P3 selected snowmaking layout and P4 basic operation -> P5 qualification. P6 weather is later core. P3/P4 may exchange priority; P5 includes both selected scopes. P4.0 must precede host/lifecycle code. No completed simulation is a prerequisite for terrain.

The first terrain candidate is allowed to fail. Stop broad engine-specific infrastructure expansion until its packaged visual/runtime gate passes. Return measured failure, smallest alternate path and maintenance consequences. Do not abandon Unreal or downgrade product requirements without owner direction.

## P0 — Native bootstrap, pure boundary and asset-safe tools

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P0.1 / scoper + integration owner | Inspect actual checkout/dirty state; reconcile owner answers and engine change; prepare bounded AGENTS/CLAUDE and retirement/extraction changes | No edits outside authorized task; preserve original repo/data; accepted follow-up answers recorded; all five latest answers recorded; only building-tool timing remains a product clarification; new source drift reported |
| P0.2 / tooling + reviewer | Verify Sol High coordinator and Terra High execution/review routing, sparse Astra escalation; freeze/read-only evidence and task/asset ownership | SEC01, SEC02: No reviewer write-capable MCP route; mutation invalidates receipt; actual independent sessions recorded, absent capabilities BLOCKED |
| P0.3 / C++ integration owner | Lock UE patch/MSVC/SDK; minimal UBT modules and pure same-source test build; blank packaged Windows Development and Shipping smoke | CORE01, CORE02, CORE03: forbidden Engine dependency and failing/empty test controls detected; player runs without editor; no full simulation, no production assets yet |
| P0.4 / preparation owner | Map old provider/worker/browser/storage closure; extract only approved data/reference tooling; enumerate obsolete entrypoint retirement | Source/extraction inventory only; IO08 closes at P1.8/P5.3. Essential source remains until P1.6/P1.8 replacement accepted; no maintained second app, destructive sweep or changes to original repo |
| P0.5 / asset integration owner | Reproducible small bootstrap map/material/widget creation + ownership/diff report; optional bounded MCP evaluation | SEC03, SEC05: no unauthorized saves/bulk rebuild; second generation run is safe; dirty-package handling and restart requirements recorded; bridge not required at runtime |

Use the released binary engine first. New paid dependencies, source builds/forks, global configuration edits and tool installations require explicit bounded authorization. An absent LLT target in a launcher build is not a reason to compile the entire engine: a tiny standalone same-source C++ test runner is sufficient for the pure boundary. The C++ test runner is not the native packaged player.

## P1 — Real mountain in the shipped runtime, with convincing appearance

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P1.1 / terrain + package owner | Explicit metric/datum package import; small runtime heightfield tile candidate in packaged player; pre-cooked materials | TER01, TER02, TER03: package created after build, no editor APIs; axis/cm/round-trip/seam/LOD checks; bounded allocation; no Nanite/Lumen assumption; small exploratory fixture does not wait for a named final visual mountain |
| P1.2 / rendering owner | Sun/sky/snow/rock ground materials/atmosphere; near/far camera; line overlays and synthetic 3,000 dots | VIS01, VIS02, VIS05, PERF01: same runtime tiles, selected lighting quality, ordinary camera motion, legible dots/overlays; character/tree art excluded |
| P1.3 / UI/input owner | UMG shell/presenters; runtime node-view interaction prototype; camera/tool/focus ownership | UI01, UI02: DPI/scale/focus/Escape/drag capture; no editor graph classes; camera movement cannot commit a preview |
| P1.4 / selector owner | MapLibre in UWebBrowser first; packaged WebGL/local bundle/security/process lifecycle proof | IO01, SEC04: actual selector draws/accepts boundary; failure fallback scoped, not second app; browser resources released on gameplay entry |
| P1.5 / preparation owner | Acquisition, decode, cover/context, derive, staging; progress and cancel/retry; package hosting | IO02, IO03: owned subprocesses; no editor Python/dev server; fixture provider failures honest; bounded memory/concurrency |
| P1.6 / preparation + importer owners | Portable package writer/native validator/activation handshake | IO04, IO05: hashes/frame/revisions/schema/size limits; invalid or stale output cannot activate; readonly install identity and atomic manifest |
| P1.7 / integrator + terrain/visual reviewer | Combined runtime import/update/picking/lighting/LOD/resource proof, first-use shaders and cold/warm loads | TER04, TER05, VIS03, PERF02, VIS05: one implementation must meet both editability and agreed appearance; no split-demo pass; record actual RHI/hardware/internal resolution; use accepted F7/F8/F12/U1–U3 targets; concrete U5 reference/camera shot and actual hardware remain evidence requirements |
| P1.8 / integration owner | End-to-end fresh small mountain from same-window selector in packaged build; close/reopen offline | IO06, IO08: isolated data directory; actual acquisition separately from deterministic fixtures; complete content rendered; no editor/Node/Python installed prerequisite |

P1.7 uses bounded grade-like mutations, not the full trail tool. Own heightfield queries can avoid unnecessary whole-mountain physics collision, but their numerical/render alignment must be proved. Any required collision representation gets the same revision and failure readiness tests. P2.4 repeats the actual grading/undo path.

P1.8 reopens the installed terrain package before design saving exists; it does not depend on P2.1. Required provider assets must be present; optional imagery/context gaps use an approved transparent policy. Shader permutations/material families are cooked beforehand, not produced through a hidden end-user editor or server. Reopen must work under network denial, not just caught request errors.

U5 now names Crystal Mountain, Washington. Use that mountain for the real visual proof, with synthetic steep/seam checks alongside it. A locally available older fixture can bootstrap code but cannot replace the Crystal reference at final visual approval. The task proposes exact data bounds/camera shots and verifies actual availability; do not invent a named must-preserve chute or assume ignored assets exist.

## P2 — First saved blueprint/lift, then the full network designer

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P2.1 / lift + domain owner | One lift: working plan/cost -> explicit Save Blueprint -> Load Blueprint -> Build Closed -> inspect -> separate Save Game/reopen | BLD01, BLD02, BP01, BP02, BP03, IO07, OP01: explicit plan library, proposal excluded from ordinary Save Game; load never builds or changes clocks; Build idempotent; first slice not blocked on multi-item grouping |
| P2.2 / trails/topology + UI owner | Trail nodes/paths/junctions; runtime node-map viewer; stable-ID/picking projections | BLD03, BLD04, UI02: holes/reversal/split/connectivity; node viewer and geometry share one graph authority; view deletion/callback cannot orphan canonical state |
| P2.3 / plan/undo owner | Extend explicit blueprint library and accepted mixed-pod grouping, typed internal links and capability-safe building records; tool-focus matrix and one committed LIFO history | BLD05, BLD06, BP04, BP05, BP06, BP07, BP08, BP09, BP10, BP11: independent save generations, stale/mismatched anchors and dirty replacement, bounded cross-tool undo; no Load Blueprint reset of built history |
| P2.4 / grading + terrain owner | Actual bounded trail grading preview, canonical commit, mesh/query sync, recovery and undo | BLD07, BLD08, TER04, TER05: failure before/after commit; stale tile/async query never enables Play; bound CPU/GPU/undo memory; no global per-frame rebuild |
| P2.5 / persistence/UI owner | Manual-save UX/recovery, screenshots and clean trail-map export, offline reopen | IO07, IO08, UI03, BP01, BP03: interrupted write preserves last valid save; migration/generation; transient visibility restored; F13 genuinely interactive timing |

Before P4, the Build pause acknowledgment uses a minimal deterministic paused host/test double. It is not evidence of the actual guest engine. Do not implement a complete scheduler just to provide that interface. F3 accepts Open/Closed controls and Closed initial state; OP01–03 enforce safe eligibility/closure rather than renderer visibility. Paused host/test-double checks do not certify actual guest safety; repeat at P4.5.

## P3 — Early snowmaking layout and numerical snow layer

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P3.1 / domain scoper | Implement accepted F4 nodes/pipes/guns/existing-water subset; enumerate only relevant verified estimates and triggers | AN01, AN02: definitions/fixtures here; runtime assertions at P3.2. No new hydraulic operating/catenary engine; fixture expected results tied to pinned source; missing data not fabricated |
| P3.2 / snowmaking + UI owner | Approved node/pipe/gun/source overlays, plans, selection, saved definitions and approved estimates | BLD03, BLD04, AN01, AN02: common Build/undo; invalid links/stale results fail; data work off hot loop only when needed |
| P3.3 / surface-display owner | Snow depth/condition layer using identified static/imported/test data | VIS04: frame/cells/units correct; no assertion of weather/snowgun production; no physical geometry deformation |
| P3.4 / integrator | Layout/user review and shared construction/save/export workflows | BP01, IO07, BLD05, BP08, BP09, BP10, BP11: All selected P3 behavior works offline, undo safe across tools, no scope beyond F4 |

New dam/pond earthworks, pump operation, water depletion, snow output and groomer dispatch remain out of scope. Existing-water references are included; pump layout/hydraulic sizing is not commissioned. Even proven old algorithms are not automatically required.

## P4 — Joint authority gate, then minimum resort operation

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P4.0 / architecture + fresh simulation reviewer | Accepted true-individual direction and deferred weighting; resolve remaining F5 arrivals/price; concrete event-clock/service/cap demo before host | SIM01, SIM02, SIM03: owner reviews any specific changed clock mapping after tiny demo; no aggregate rewrite or weighted implementation; cap/demand policy visible |
| P4.1 / simulation owner | Reduced pure C++ host/scheduler, then lifetime/game-thread bridge | CORE04, SIM01, SIM03: same commands/horizon across frame schedules; pause/cancel/load fence; no Actor/Blueprint/TimeDilation authority |
| P4.2 / routing/guests owner | Chosen spawn, reachable runs/lifts, queues, movement and visit completion | SIM02, SIM03, SIM04: capacity and population conservation, invalid exits and in-flight edit policy; no facilities/needs by stealth |
| P4.3 / capacity owner | Individual-only active-cap handling and visible pending/unadmitted demand | SIM10, SIM11: cap distinct from daily admissions, bounded queues, no revenue before admission, restore/day-end accounting; weighted SIM05–07 future and not a current gate |
| P4.4 / ledger/UI owner | Player-set daily arrivals and fixed daily price, next-day edit semantics, once-per-admission ledger and inspection | SIM09, SIM12: accepted F5; no price elasticity; locking/retry/save/day-end cases; no receipts for pending arrivals or lift rides |
| P4.5 / integration owner | Actual live blueprint planning, pause-on-Build, F3 states and manual resume | SIM08, BLD07, BLD08, OP01, OP02, OP03, BP02: built-open eligibility only; safe closure/removal with retained journeys, no stranding; sync failure stays paused; explicit blueprint save/load during play |
| P4.6 / integrator + performance reviewer | Full selected operation/save/offline loop with dense dots and camera | PERF03, IO07, SIM04, SIM10, SIM11: 3,000 is target not assumed pass; selected detail and GPU submissions bounded; no default season-length trial |

Only weighted implementation is DEFERRED_BY_OWNER under F6B. P4.3 itself is now a required individual-cap/demand-accounting section and cannot be skipped. A renderer-only benchmark remains separate from P4.6.

## P5 — Selected-scope release qualification

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P5.1 / integrator | Written choose -> prepare -> plan -> Save/Load Blueprint -> Build Closed -> open -> basic operate -> Save Game/reopen -> clean map story | IO06, IO07, BP01, BP02, OP01, UI03: Selected ledger complete; no implied full season, sharing workflow or later weather requirement |
| P5.2 / performance/visual reviewer | Short integrated workload and resource/stall/visual matrix on actual hardware | PERF01, PERF02, PERF03, PERF04, VIS01, VIS02, VIS03, VIS04, VIS05: full windows/start-end gaps, cold/warm first-use costs, actual lane settings, agreed thresholds; no unavailable GPU certified |
| P5.3 / release integrator | Clean-machine packaged Development/Shipping checks, cook/plugin/asset manifest, content rights and recovery | SEC02, SEC05, IO06, IO07, IO08: no editor/server dependency, no MCP automation listener, required materials cooked, local writable save path, supported limitations documented |

No signing/publishing/telemetry/upload or paid deployment action is authorized merely because release planning exists. The owner performs commits and authorizes distribution.

## P6 — Later-core weather

| Section / owner | Owned work | Acceptance / stop rule |
|---|---|---|
| P6.1 / weather scoper | Trace intended existing weather call paths and fixtures; choose one host or permitted language translation | WEA01, WEA04: preserve numerical behavior; source/version/RNG/calendar pinned before translation; specific gameplay/lab ambiguity resolved by evidence or focused P6 question, no scientific redesign |
| P6.2 / weather owner | One offline helper/package/native adapter; package install/update outside gameplay | WEA01, WEA02, WEA04: chronological hours, retries/errors, seeded continuation, DST, missing chunks; helper is not a second game clock |
| P6.3 / surface/UI owner | Weather data readouts and approved numerical snow effects, separate from future visual effects | WEA01, WEA03: units/order correct; initial art presets not generated truth; no new dynamic-cloud subsystem or physical snow commissioned |
| P6.4 / integrator | Short boundary checkpoint and offline failure/performance cases | WEA02, WEA03, WEA04: save/restore/cancel/speed controls and resource bounds; no default season benchmark |

Later weather is separately authorized and does not block the saved designer or selected P5 acceptance.

## Answer-specific execution notes — v0.9

**P1 reference:** use Crystal Mountain, Washington for the recognizable real-mountain proof, plus synthetic steep/seam checks. Select the exact boundary/data and propose overview/moderately-close shots during the task; source availability/precision remains unverified until acquisition. No need to ask for the mountain again.

**P2/P3 mixed pods:** P2.1 is deliberately one lift; P2.3 adds actual multi-item links/save/load/dependency handling. Snowmaking entries join through P3.2, and P3.4 exercises a mixed lift/trail/snowmaking pod through explicit Save/Load and Build/undo. Do not require an unimplemented snowmaking tool to pass the early P2 proof. Building record format checks can use clearly labeled synthetic fixtures, while building placement is commissioned only after F1_BUILDINGS. Unsupported entries must remain intact and visibly non-buildable.

**P4 inputs:** player-set arrivals and per-day ticket pricing are accepted. Sol specifies, and Terra tests, deterministic scheduling, daily locking, next-day edits, admission identities and bounded end-of-day backlog. The P4.0 clock demonstration remains required; no new broad finance questionnaire.

**P5 hardware:** inventory the approximately ten-year-old laptop as an optional probe, use the packaged player only if compatible, and retain unsupported/failed results. This does not change the minimum target or demand a laptop purchase/upgrade.

**P6/weather effects:** a language rewrite is permitted, numerical-model replacement is not assumed. Resolve source identity from actual call paths/fixtures, not an abstract repeated question. Backend/UI/numerical integration can complete without new dynamic clouds or a weather-effects system; those are later independently authorized work.
