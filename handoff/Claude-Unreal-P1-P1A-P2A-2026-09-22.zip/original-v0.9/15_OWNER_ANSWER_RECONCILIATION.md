# Owner-answer reconciliation and amendment review — v0.9

**Date:** September 18, 2026. **Source:** five direct answers preserved verbatim in [sources/OWNER_FINAL_ANSWERS.md](sources/OWNER_FINAL_ANSWERS.md). **Input:** v0.8 ZIP, SHA-256 `8b6d6a96e52ba783d0ddd447dc147c73dde270af366feea46d90d663b501bfd2`.

## Disposition of every answer

| Reply | Recorded decision | Active changes / evidence gate |
|---|---|---|
| 1 | A saved blueprint can hold a whole mixed trail pod, including lifts, trails, snowmaking and building records | Master, scope, phase P2.3/P3.4, BLUEPRINT_LIBRARY contract, BP08–BP11. Only building placement/tool delivery timing is an open product clarification; schema support is not silently dropped. |
| 2 | Accept player-set daily arrivals, fixed per-day ticket price, no price elasticity and once-per-actual-admission revenue | F5 accepted; master, simulation contract and P4.0/P4.4. Daily lock/re-entry defaults labeled engineering choices. |
| 3 | Crystal Mountain, Washington is the visual reference | Master, terrain contract, P1 reference tasks and decision register. Exact bounds, data availability and camera examples must be established; no geographic feature or measured resolution invented. |
| 4 | Approximately ten-year-old laptop available | Optional compatibility/performance probe after inventory. Neither age nor ownership establishes a minimum GPU/OS or a support guarantee. Existing performance targets unchanged. |
| 5 | Preserve existing numerical weather; rewrite language when needed; new game visual effects/dynamic clouds may be future work | WEATHER_AND_EFFECTS contract, P6 tasks, WEA01–WEA05. Numeric source is traced before translation; visual effects are not model authority and do not gate P6 completion. |

The five earlier questions are answered at the product-direction level. F1_BUILDINGS is one scope clarification introduced by the new explicit building example. Later laptop inventory and weather source identification are technical tasks, not a repeat questionnaire. Read [09_FOCUSED_FOLLOW_UP.md](09_FOCUSED_FOLLOW_UP.md).

## Adversarial amendment review

This is a single-assistant review of the amendment, not a new independent-agent panel. Prior genuine-review assignments remain supplied for Codex. The original v0.8 findings are preserved; no historical independent/runtime approval is inferred.

### AR09-01 — A whole-pod save must be more than a list of item files

**Risk:** converting one saved object into multiple objects can leave broken internal links after fresh IDs are assigned, especially shared trail junctions or pipe connections. **Plan correction:** one coherent typed plan snapshot; explicit internal-versus-built-anchor references; one complete ID-remap table; stable shared nodes. **Required proof:** BP08/BP09, then a real mixed lift/trail/snowmaking workflow at P3.4. The early one-lift proof remains intentionally smaller.

### AR09-02 — Building compatibility is not a silent new building game

**Risk:** ignoring buildings would fail the newly stated grouping goal; automatically adding 3D buildings/amenities would violate the retained scope. **Plan correction:** accommodate building plan payloads now, preserve unsupported capabilities with diagnostics, and ask only whether simple footprint placement is current or future. **Required proof:** BP10. Unknown fields are never silently discarded, executed or costed as zero. Building gameplay/rendered art remains uncommissioned.

### AR09-03 — A selected build must keep the remaining plan coherent

**Risk:** a partially selected pod builds a shared node, while remaining proposal links still reference a consumed proposal ID; a second build can duplicate it. **Plan correction:** transaction-owned proposal-to-built mapping, typed conversion of remaining links and coherent undo. Source saved blueprint is not automatically overwritten. Show/confirm dependency closure and block unsatisfied members before commit. **Required proof:** BP08/BP11.

### AR09-04 — Accepting ticket inputs must not leave re-entry/retry accounting open-ended

**Risk:** daily settings changing during a queue retry can price one admission twice or inconsistently. **Plan correction:** propose explicit daily locking/next-day edits, stable admission IDs, bounded pending demand and visible day-end accounting. No re-entry feature by default. **Required proof:** SIM09/SIM10/SIM11/SIM12 and the P4.0 demonstration. The user accepted the product direction, not arbitrary mathematical clock rates.

### AR09-05 — Machine age and a mountain name are not measured evidence

**Risk:** mark the old laptop as supported by age or the chosen mountain as already acquired at high resolution. **Plan correction:** inventory/verify each; qualify actual hardware only, use Crystal source data and owner-selected camera approval, preserve unknown results. **Required proof:** actual P1 visual/data evidence and P5 lane checks. No new imagery, terrain data, benchmark or current driver support check ran here.

### AR09-06 — Permission to change language must not become permission to change weather science

**Risk:** either rewrite unrelated numerical behavior or hold backend delivery hostage to cinematic clouds. **Plan correction:** trace and pin source/fixtures before translation; keep one authoritative numerical backend and separate future cosmetic effects/RNG. **Required proof:** WEA01–WEA04 at P6; WEA05 remains DEFERRED_BY_OWNER until a visual-effects task is explicitly authorized. Exact gameplay/lab source identity remains an evidence task, not a silently chosen backend.

## Local checks and limits

The parent v0.8 archive passed its existing 64 checks before modification. The v0.9 checker retains applicable old checks, updates checks for resolved answers, and adds source/hash, mixed-plan capability/link, daily-input and future-effects checks. Local Python illustrations test the consistency of these proposed invariants; they are not copies of, or substitutes for, future C++/Unreal implementation tests. See DOCUMENT_CHECKS.json for the executed results and rerun evidence/check_package.py for the delivered manifest.

No independent agent, C++/Unreal build, game, GPU, live-provider acquisition, new web research, current-repository inspection, Drive refresh or cloud/repository write occurred in this amendment. Original files and archives are unchanged. New Engine/API facts are not asserted; inherited technical choices remain proposals requiring their established local validation. All implementation test statuses remain NOT_EXECUTED or explicitly DEFERRED_BY_OWNER.
