# Adversarial self-review — Unreal v0.9

> **v0.9 status:** this file retains the v0.8 review findings for traceability. Its original five missing inputs have since received answers. The current amendment review and their dispositions are in [15_OWNER_ANSWER_RECONCILIATION.md](15_OWNER_ANSWER_RECONCILIATION.md) and DECISION_STATUS.json. Historical findings are not newly executed agent/runtime tests.


**Method:** author self-review against owner answers, R01–R10, ER01–ER08, current primary docs and active-file consistency. Independent agents: NOT_EXECUTED. No engine/API/graphics/runtime validation was run. The following corrections are incorporated in planning; real feasibility remains gated.

| ID | Risk found while adapting | Correction / remaining proof |
|---|---|---|
| UAR01 | Replacing engine names could falsely carry over runtime Terrain capability | Separate runtime import/edit from Landscape/Mesh Terrain cook; combined packaged candidate gate P1.7 |
| UAR02 | “Unreal looks better” could promise Lumen/Nanite on unsupported Dynamic Mesh | Explicit documented limits and U3 visual outcome; test same editable representation, no split-demo approval |
| UAR03 | Naive port retains meters/old axes and corrupts positions/costs | Double ENU meters -> UE north/east/up centimeters, inverse/winding/normal tests; canonical quantities never render units |
| UAR04 | Unreal Blueprint graph and in-game design blueprint become one concept | Separate ProposedPlan data from Blueprint presentation assets; simulation reads built data only |
| UAR05 | Domain module still quietly depends on UObject/Engine | Same pure sources compile without engine paths; registration shim explicitly isolated; deliberate dependency failure control |
| UAR06 | Runtime node viewer uses GraphEditor or editor transactions | Runtime UMG/Slate graph and application undo; editor module excluded from packaged target |
| UAR07 | Read-only reviewer can mutate via local editor HTTP | Remove write-capable MCP/connector tools in review; verify effective permissions and unchanged assets |
| UAR08 | Experimental MCP assumed editor-only and accidentally shipped | Audit runtime-capable module/service exclusion; loopback/allowlist/serialized editor calls; no service in Shipping |
| UAR09 | Asset hashes only capture disk while editor/cook consumes unsaved content | Save only owned dirty assets, freeze editor mutation, verify generated inputs/cooked outputs and before/after identity |
| UAR10 | Warm demo misses PSO/first-grade/view-travel stalls | Cold/warm and first-use shader/PSO fixtures, complete frame gaps; operations declared before timing |
| UAR11 | Terrain quality claim quietly expands no-objects scope or raises GPU floor | Original exclusions preserved, no asset/hardware scope expansion; U1/U2/U3 direction and F12 approach now accepted; concrete reference/hardware evidence still missing |
| UAR12 | Browser/fixture importer mistaken for full preparation | Fresh player-selected package after executable build; no editor/Node/dev server; complete offline gate |
| UAR13 | Heavy simulation-first proof delays key terrain/UI risk | Small core boundary first, terrain next; F6 resolved only before host, not an early complete engine |
| UAR14 | Runtime tile LOD assumed built-in | Declare project-owned finite LOD/seams/residency as measured tasks; bounded alternative if candidate fails |
| UAR15 | Floating LWC/terrain queries/persistent actor positions mix authorities | Canonical model independent of camera/Actors/tile residence; representation/query revision gates |

## Final follow-up reconciliation

The UAR safeguards above remain. Latest decisions and the final author audit are in DECISION_STATUS.json and [14_FINAL_ADVERSARIAL_REVIEW.md](14_FINAL_ADVERSARIAL_REVIEW.md). Do not reuse v0.7's open-question list: only F1_BUILDINGS are missing. F6 direction is accepted; its concrete demo remains required.

No independent-agent/Unreal/graphics/provider execution occurred. Runtime terrain editability, appearance and resource envelope must still pass together. The code/asset build and test environment, model routing and reviewer restrictions require local validation. Local package checks do not prove those capabilities.
