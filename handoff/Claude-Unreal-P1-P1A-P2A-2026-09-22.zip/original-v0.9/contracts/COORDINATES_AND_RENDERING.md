# Coordinate, unit and presentation contract

## Canonical coordinates

Geographic input uses an explicit horizontal CRS and vertical datum (or an honest unknown marker). Retain true returned bounds and source spacing. Select a documented local metric frame appropriate for the finite footprint; geographic degrees and Web Mercator values are not automatically physical meters.

Canonical authoring uses double East/North/Up meters. Proposed Unreal world conversion is:

```
X_cm = 100 * (North_m - OriginNorth_m)
Y_cm = 100 * (East_m  - OriginEast_m)
Z_cm = 100 * (Up_m    - OriginUp_m)
```

Subtract in double. Translate geometry to a nearby tile origin before using float vertex buffers. Unreal's default distance unit is centimeters and world convention is Z-up/left-handed; the swapped East/North adapter is deliberate. Test inverse mapping and heading, triangle winding/backface/normal orientation rather than relying on naming. [E12/E13]

A change from meters to centimeters multiplies length by 100, area by 10,000, volume by 1,000,000. Internal costs, slopes, snow depth, capacity and canonical analysis stay in their explicit units; never apply render scaling to money or event time. A saved coordinate is canonical, not a camera-relative engine transform. UI formatters state meters/feet and percent/degrees distinctly.

## Precision and tolerance

Use LWC-capable engine transforms as appropriate, but do not infer that custom shaders, GPU buffers, collision and material math are all double. At 500,000 cm (5 km), adjacent float32 values are 0.03125 cm = 0.3125 mm; this spacing is not an end-to-end accuracy guarantee. Retain numerical tests for large-origin subtraction and actual corners, seam normals, distant terrain, nearest zoom and steep picking. Test material/world-position precision independently.

A fixed near-center origin is the default. No automatic floating-origin subsystem without measured need. If introduced, transition render transforms, camera, indexes, pending jobs and interpolation coherently without changing canonical coordinates. The platform's large-world support is a tool, not a save/schema authority.

## Shared terrain interpretation

Specify sample cells versus vertices, row direction, datum/unit transform, nodata, interpolation and triangle split. Tile borders share deterministic samples, including normal support neighbors. Analysis and display resolutions may differ, but selected points/overlay alignment must meet a declared error budget. Elevation quantization and resampling are recorded. Mesh normals/UVs/winding tests include a sloped ramp and north/east asymmetric pattern to expose transposition.

## View projections

Terrain meshes, line/ribbon/footprint overlays, hit targets and graph views reference stable entity IDs + canonical revision. Opaque terrain, depth-aware overlays and analysis modes have explicit draw/hit priorities; do not blindly copy browser layer order. The proposed/built distinction is visible and testable. Avoid ridge-through selection unless an explicit graph-map mode is intended. Selected dots use a stable CPU logical identity, not transient GPU instance index.

Cache route cumulative distances and prepared geometry; interpolation must follow valid bends/direction and not shortcut gaps. Dots may use instanced/batched rendering but are not authoritative people. Do not assume component groups have optimal per-dot culling; measure broad/dense visibility. No per-dot UObject/AIController/collider default.

## Test scenarios

TER01: zero/negative elevations, non-square/asymmetric grids, 100x conversion and inverse; normals/UVs/headings correct.
TER02: same edge shared by two tiles at same/different LOD; no cracks, flips, dark seams or duplicate IDs.
TER03: closest camera, corners/surrounds and grazing rays; declared query/display tolerance.
TER04: region grade before/after commit, LOD switch and async query/collision failure remain same revision.
VIS02: thin overlays and moving dots remain readable across antialias/upscale quality profiles; clean map mode has intentional occlusion policy.

Numeric examples in package checks test math only, not engine behavior.
