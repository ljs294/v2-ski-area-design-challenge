# Runtime terrain, editable surface and visual acceptance

## A. Hard product boundary

The Windows executable is built before the player chooses a supported real mountain. The player does not install the editor or run a developer cook server. The terrain package is data, not an uncooked `.uasset` level. After preparation all needed gameplay content is local. Trail grading changes the canonical surface and must be reflected in display and picking. Do not quietly replace these requirements with curated maps.

## B. Capability matrix — documented baseline vs unproven capability

| Candidate | Known basis | Do NOT assume | First action |
|---|---|---|---|
| Geometry Framework Dynamic Mesh | Epic documents runtime geometry updates; components can be used independently of Geometry Scripting | Nanite/Lumen, mesh distance fields, automatic LOD, instancing, automatic whole-world collision/lighting solution | Small direct-C++ packaged tile import/update proof with explicit material/shadow path |
| Landscape / Nanite Landscape | Supported editor/cooked landscape workflow; Nanite representation rebuilt after changes | Arbitrary player-time Landscape import, safe shipping height mutation, runtime Nanite rebuild or free memory | Only consider a precisely verified packaged runtime path; source/header/editor module inspection + end-to-end test |
| Mesh Terrain | UE5.8 Experimental; preview and compiled sections distinct | Runtime authoring/modifier/compilation parity with editor; permission to depend on unstable systems | Excluded from foundation by default; limited research only when a specific blocker justifies it |
| Bounded runtime mesh/plugin or project render adapter | May offer different LOD/update/lighting support | Marketing guarantees, LGPL/GPL/paid terms compatibility, actual mesh-distance-field or Nanite support | Compare one actual candidate against exactly the same proof after a failure; no automatic dependency purchase |
| Prebuilt cooked mountain | Strong reference for look/performance | Satisfaction of user-selected runtime mountain requirement | Diagnostic visual reference only unless the owner changes the product explicitly |

Sources: E02/E03/E07. Ray-tracing support alone does not establish Lumen integration. Enabling a project-level Lumen switch does not make every representation appear in its scene. Screen-space contribution can look acceptable from one camera and fail offscreen; test actual shadows/reflections/indirect response while orbiting. Record unsupported paths rather than inventing distance fields or runtime Nanite baking.

## C. First packaged proof

Use one small real mountain package and a synthetic seam/steep-slope fixture. Create a second input after the executable was compiled; load it through the player UI. Use bounded regular-grid tiles, explicit triangle/edge topology, pre-cooked terrain material families and runtime texture/scalar parameters. Perform a small canonical height change, update only affected presentation/query data, then reopen the package plus a scratch edit record. P1 proves representation; P2 provides full authored grading/undo/save semantics.

Measure the SAME candidate's visual quality, runtime editing, memory and camera response. A pretty editor landscape plus separate unlit editable mesh is NOT a pass. The owner approves the actual look (U1/U2/U3) within stated hardware/resolution (F12). Changing terrain after initial shader warm-up is part of the proof.

First candidate: C++ tile math -> bounded Geometry Framework component application. Heavy mesh generation/normal computation works on plain buffers off the game thread when worthwhile; final UObject/resource updates are game-thread owned. API calls through Blueprints may remain synchronous even when internals parallelize; do not treat a Blueprint geometry node as an asynchronous job. [E02]

## D. Scale without an early world-engine project

Start with finite fixed tile resolutions and a finite LOD ladder. Explicitly own tile index, screen/error-based resolution choice, nearest-neighbor difference rules, stable shared samples, seam stitching/skirt policy, normal continuity, and LOD-transition artifacts. Dynamic Mesh supplies no built-in LOD promise; this is project work that must be measured. Do not start with unrestricted adaptive tessellation, voxel caves, global collision, or a custom Nanite encoder.

Canonical base/grading query access is independent of which tiles are currently visible. Local disk residency and renderer LOD cannot remove simulation graphs or change travel durations. Camera teleports get bounded staged loading and honest readiness, not invisible terrain with a passing FPS metric. Persist canonical edits, not per-camera meshes.

## E. Picking and collision

For the initial map-style camera/dot guests, canonical heightfield ray queries are a valid candidate instead of a dense full-map Chaos collider. They must handle holes/nodata, grazing rays and region bounds, and agree with visible geometry to a declared tolerance. This is not permission to click through a ridge hidden by the renderer. Separate high-precision analysis sampling from visible-surface selection when needed and test the difference.

If Chaos collision is required for the approved workflow, record cook/update support in the packaged runtime, dirty bounds, async ownership and readiness acknowledgment. CanonicalCommitted does not equal collision-ready. Never enable Play/commit using a stale collision body. Future first-person physics would require a separate scope and collision gate, not a silent promise from this camera mode.

## F. Lighting, materials and close-up evidence

Minimum current presentation: authentic source terrain; restrained multi-scale snow/rock/ground surface treatment; sun/sky; spatial depth through atmosphere/fog where supported; readable overlays and guest dots. No modeled environmental assets without explicit scope expansion. Terrain texture richness cannot be used to fabricate measured geological geometry.

Prepare clear-midday, low-angle and overcast ART presets. They are not weather-generation features. Control exposure and compare the same scene from overview and closest approved zoom. U2 establishes camera bounds. Include tile-edge motion, snow-to-rock transitions, night only if separately approved, overlays on light/dark regions and temporal shimmer/ghosting of moving dots and thin lines. Do not use Movie Render Queue or a static screenshot to certify gameplay quality.

High/Standard/Low profiles record output and internal resolutions, antialiasing/upscaler, RHI, lighting/reflections/shadows/cloud settings, terrain source/resident LOD and material permutations. A low-end fallback cannot silently reduce source data or change game rules. Nanite/Lumen are optional only where the representation supports them and the player proof passes. U3 resolves whether appearance without those features is acceptable; the technical path cannot force that answer.

## G. Resource envelope and first-use costs

Record peak CPU/native allocation and known GPU allocation separately, resident/decoded tile counts, vertex/index bytes, changed-region buffers, pending completions, IO concurrency, query/collision data, preview + undo footprint and save staging. Bound uploads and game-thread component creation per frame. First camera visit, first grade, cold driver/PSO cache and warm reopen are distinct samples. Do not attribute absent VRAM instrumentation a zero.

P1.7 qualifies terrain feasibility only at measured footprint/quality. P2.4 retests actual grade/undo/recovery. P5.2 qualifies integrated operation on actual hardware. Reject or offer a visible alternative before unsupported preparation, without claiming every 10-km/1-m option works.

## H. Branch/stop rule

One initial candidate, one targeted alternative only after a documented failure and new bounded task. If required editability and intended visual quality cannot coexist within the accepted envelope, stop that phase and show the exact conflict. Options may include a better runtime representation, explicit dependency budget or a smaller quality envelope. Do not change to a prebuilt-only product, require an engine source fork, eliminate grading or change minimum hardware without owner approval.

No guaranteed Nanite/Lumen path is being withheld for later: it is unresolved and tested FIRST because it bears directly on why the owner chose Unreal.

## Accepted visual answers and overlay contract — v0.9

U1–U3 accept hybrid terrain and clean robust overlays, overview/moderately close cameras, and evaluating the same editable runtime rather than requiring Nanite/Lumen. F7/F8 accept fixed 2–10 km target and explicit Standard/High preparation. F12 accepts Low/High quality, initial performance approach and provisional stall backstop, not qualification of an absent GPU. U5 names Crystal Mountain, Washington; actual data and camera shots still need the planned visual proof. The optional older laptop is not a certified specification or required minimum.

VIS05 covers stacked proposed/built/analysis layers on snow and rock, toggling visibility, selected emphasis, anti-alias/upscaler behavior, hover/hit priority and rapid camera movement. Updating one layer should not regenerate all layers or topology. Keep screen-space selection tolerances separate from metric validation. A hidden visual layer cannot change Open/Closed state or guest routes; stale hit entries cannot select removed entities. Choose finite declared stress counts and measure CPU/GPU/update costs rather than promising an arbitrary number of overlay layers. Existing toolbar/panel constraints remain; do not add persistent UI divisions without approval.

## Named reference and optional physical test lane — v0.9

Owner-selected real reference: **Crystal Mountain, Washington**. Verify acquisition coverage, frame/bounds and actual resolution during preparation. Propose one resort-wide and one moderately close shot for owner approval; the owner did not name a mandatory chute, so do not invent one or treat reference-image detail as measured elevation data. Synthetic seam/slope tests remain necessary and distinct. This is a test reference, not a change to arbitrary supported mountain selection.

The owner has an approximately ten-year-old laptop. Inventory actual CPU/GPU/RAM/OS/storage/drivers before a compatible packaged-player trial. It may fail or be unsupported; age does not prescribe a minimum spec, RHI, GPU, or measured frame rate. No requirement to run the editor or buy an upgrade. Keep the earlier GTX1650 lane unqualified unless actually tested on that hardware.

Current appearance uses artist-controlled presets; new dynamic weather/cloud effects are future scope. Backend integration and an attractive editable terrain proof do not require that future system.
