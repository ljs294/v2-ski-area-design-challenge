# Explicit construction-plan save/load contract — owner F1

## Authority and vocabulary

“Construction blueprint” means game data, never an Unreal Blueprint scripting asset. Owner F1 explicitly requires a small separate **Save Blueprint / Load Blueprint** workflow and persistence only after that action. The library is current scope, not a future convenience. First proof is in P2.1 with one lift. P2.3 extends it to approved multi-item trail pods containing lifts, trails, snowmaking and building plan records. It must not finalize a single-item-only schema.

Keep five distinct things: transient input gesture, working proposal, saved blueprint generation, built ResortDocument, and saved-game generation. The library is neither the live graph nor an event log.

## Four user actions, four effects

| Action | Reads / writes | Must NOT do |
|---|---|---|
| Save Game | Capture built canonical document, terrain modifications, operating flags and applicable simulation checkpoint into a game-save generation | Persist working proposal geometry, mutate a saved blueprint, charge construction money, or implicitly Build |
| Save Blueprint | Capture a coherent non-transient working-plan revision into an explicitly selected named library entry/generation | Save/advance/reset the game simulation, mutate built topology, or silently overwrite a newer entry |
| Load Blueprint | Read/validate a saved entry and create editable proposed data in the current session | Build, auto-open, change pause/speed, issue tickets, reset committed undo, or load the saved game's world |
| Build | Validate and commit the selected permitted proposal into built state, Closed initially, through the acknowledged pause/readiness barrier | Persist the game or overwrite the source saved blueprint; duplicate an already acknowledged operation |

A built change remains unsaved until Save Game. A saved blueprint remains in the library after it is used. Editing or consuming its working copy does not overwrite that saved generation. Current Save Game and explicit Save Blueprint are not coupled into one transaction.

## Minimal interface and dirty behavior

Expose separate small Save Blueprint and Load Blueprint controls in the owning construction panel, not new permanent toolbar divisions. Reuse existing dialog patterns. A simple name/list suffices; no folders, cloud sharing or asset-browser subsystem. Save only completed non-transient geometry; active pointer samples are not persisted.

Save Blueprint confirms success only after the captured revision is durable. If the player edits while IO is running, the saved captured revision remains valid but the latest working revision remains dirty. Generation/expected-version checks prevent a delayed save overwriting a newer save to the same entry. Do not clear the dirty marker for changes not included in the successful save.

On Save Game with dirty proposal edits, explain that plans are separate and offer explicit Save Blueprint, Continue Saving Game Without Blueprint, or Cancel. Continuing does not destroy the working plan, but it will not be restored by Load Game. Save Blueprint is still an explicit action if chosen in this dialog; no silent bundling. Avoid repeated warning loops within one Save Game request.

Before Load Blueprint replaces a dirty working proposal, offer explicit Save/Discard/Cancel. Game exit/reload must also warn about unsaved proposals. No accidental autosave. Load Blueprint leaves clocks and built undo untouched. Load Game restores built state paused and starts new committed history; it does not automatically instantiate the last saved blueprint.

## Data and validation (engineering defaults, not added owner features)

Use a non-executable versioned record in the application's user-writable construction-plan library, separate from game-save slots. Store stable plan identity, library generation, captured draft revision, prepared-terrain content hash/frame, resort document identity, proposed items, explicit links between them, stable references to existing built anchors, original metadata and provenance. Large source terrain is referenced rather than copied. A format-valid incomplete plan may be saved with diagnostics; **saving does not certify buildability**.

Initial scope is same prepared mountain/resort. Reject an incompatible terrain/frame or document binding with a useful explanation; do not reinterpret coordinates or snap to a different mountain. Cross-resort copy/stamping is future scope unless explicitly requested. Proposed item links and external built-anchor references have different types.

Loading creates a fresh working instance/generation. Never reuse stored built entity IDs, Actor pointers, instance slots, build operation tokens or stale worker completions as live authority. Revalidate external anchors against current built state and rederive cost/grading/query caches. Missing/moved anchors leave a proposed plan visibly invalid for Build; do not silently repair by nearest-node snapping. Repeated load must not append duplicate working copies without an explicit add action. Loaded IDs remain local proposal IDs until a successful coherent Build assigns canonical built IDs.

A grouped Build has explicit dependency closure and no partial canonical commit. Multi-item grouping is owner-approved. Build All / Build Selected with a visible dependency preview is the initial engineering UX default. The single-item path remains sufficient only for P2.1. The common runtime Build/undo rules apply; no editor transactions.

## Multi-item trail-pod records and dependencies — latest answer 1

A saved construction blueprint may contain an entire mixed pod: multiple lifts, trails, snowmaking components and building plan entries together. Save/load must preserve relationships, per-item kinds/versions, plan-local IDs, anchor roles and geometry. Do not create one independent blueprint file per item and call it a grouped save. One library generation captures one coherent plan revision.

Use typed entries with bounded payloads and explicit distinctions between (a) internal proposed-item references, (b) external built-anchor references, and (c) optional visual associations. Declare mandatory dependencies rather than inferring them solely from overlapping geometry. Remap every internal reference through one old-to-new proposal-ID map on load; external anchors are revalidated, not remapped as new items. Shared junctions remain shared.

Build All / Build Selected are the proposed minimal UX. Before Build show the requested set, required dependency closure, unresolved/unsupported members and recomputed estimates. Adding a mandatory dependency requires visible confirmation; never quietly include optional items or a whole pod. If closure cannot be satisfied, reject the transaction before canonical commit. Cost unknown is visibly unknown, not zero. Saveability, inspectability, cost completeness and buildability are distinct capabilities.

After a successful selected Build, retain one map from committed proposal IDs to newly built IDs and update still-working internal links to typed built-anchor references coherently. Consume/mark only the built working subset. Leave the saved source blueprint unchanged unless explicitly saved again. Undo must reverse that mapping and the connected graph/terrain changes as one current command. Subsequent remaining builds and repeated load must not duplicate already acknowledged operations or silently substitute a nearby anchor.

### Building capability without invented building gameplay

The owner explicitly includes buildings in the desired mixed-plan contents. The blueprint record model must therefore accommodate non-executable building kind/version/identity, descriptive data and footprint/reference payloads. This does not automatically approve a new building placement tool, 3D models, amenities, simulation, operating Open/Closed rules or invented costs. F1_BUILDINGS decides whether simple current footprint placement is delivered or building tooling is later work.

Before a kind has a supported builder, retain its bounded payload and visible unsupported status through save/load. Known footprint metadata may support a diagnostic outline, but must not imply Build works. Unknown schema versions follow the format policy: preserve as a bounded non-executable unsupported record or reject loading without altering the source file; never silently coerce/drop fields. Build All with an unsupported required member fails as a whole. An explicitly selected independent supported subset may build; any selection transitively depending on the unsupported member is blocked. The test harness may synthesize building records for format checks without pretending a building editor exists.

### Scope and scale

No cross-mountain relocation, rotation/stamping UI, sharing service, generic plugin VM or arbitrary executable payload is commissioned. Bound item/link counts and allocations using declared validation limits. An entire practical pod is the product target; exact stress-fixture count is engineering-owned and measured, not an invented user maximum. Validate cyclic or missing mandatory construction dependencies and return stable diagnostics without recursive runaway.

## Persistence and failure isolation

Save Blueprint uses its own stage -> validate -> durable manifest/generation commit -> prior-generation recovery. A failed plan write leaves the prior plan and game save intact. A failed Save Game leaves the plan library intact. Late callbacks check session, library-entry generation and captured draft revision. Pending writes cannot activate a plan in a replaced session. Package garbage collection treats saved plan references and in-flight library writes as roots, alongside game saves; otherwise a plan could outlive deleted terrain it depends on.

Normal game save is gated by required world readiness. Saving/loading a working blueprint may continue during ordinary play using coherent plan data. During Build/DerivedSync/PausedRecovery, defer structural proposal edits/library loads for that active plan until the operation resolves; an attempted save returns a useful busy outcome rather than capturing mixed revisions. This bounded rule does not pause every ordinary blueprint action.

## Required cases

BP01–BP08 in the canonical [test catalog](../TEST_CASES.json) cover explicit-only persistence, Load Blueprint non-mutation, independent transaction recovery, stale bindings/IDs, racing saves, dirty replacement, library reference lifetime and grouped dependencies where approved. These are planned engine/player tests, NOT_EXECUTED here.


<!-- TEST_DEFINITIONS_START -->
- **BP01** — Only explicit Save Blueprint persists proposal content; Save Game excludes dirty working plans and warns without implicit save or discard. **NOT_EXECUTED** (CURRENT).
- **BP02** — Load Blueprint creates proposed data only: no Build, clock/speed/pause change, ticket event, operating-state change or committed undo reset. **NOT_EXECUTED** (CURRENT).
- **BP03** — Independent game-save and blueprint-save generations survive interruption/full disk/failed overwrite without corrupting each other. **NOT_EXECUTED** (CURRENT).
- **BP04** — Saved blueprint terrain/document/anchor bindings validate; stale costs/grading recompute; reused built IDs and build operation tokens never resurrect. **NOT_EXECUTED** (CURRENT).
- **BP05** — Save captures one draft revision; later edits remain dirty, and out-of-order completion cannot overwrite a newer saved generation. **NOT_EXECUTED** (CURRENT).
- **BP06** — Dirty plan replacement/exit uses explicit Save/Discard/Cancel; repeated load replaces safely rather than appending duplicate working entities. **NOT_EXECUTED** (CURRENT).
- **BP07** — Saved blueprint and active blueprint write references protect required terrain content from cleanup; missing content never substitutes another mountain. **NOT_EXECUTED** (CURRENT).
- **BP08** — Multi-item trail-pod Build All or explicitly selected subset uses shown dependency closure and one canonical commit; single-item P2.1 is only the bootstrap slice. **NOT_EXECUTED** (CURRENT).
- **BP09** — Mixed saved pod preserves lifts, trails, snowmaking and bounded building plan records plus typed internal/external links; fresh-ID remapping retains shared nodes and does not duplicate live entities. **NOT_EXECUTED** (CURRENT).
- **BP10** — Unsupported or future building entries retain bounded non-executable payloads and visible diagnostics through save/load; dependent Build is blocked and no item is silently dropped or costed as zero. **NOT_EXECUTED** (CURRENT).
- **BP11** — Successful selected Build coherently rewrites remaining working-plan links through proposal-to-built mapping; undo and later builds preserve topology without overwriting the saved source plan. **NOT_EXECUTED** (CURRENT).
<!-- TEST_DEFINITIONS_END -->
