# Construction, projections and runtime undo

## State separation

Transient pointer gesture, ProposedPlan and BuiltResortDocument are separate. A proposed edge/node may share canonical coordinate types but not operational membership. The graph viewer explicitly labels proposed vs built. Cost estimates and grading preview cannot change routes, earth, operating status or ticket revenue. F1 determines persistent/multi-item proposal behavior; separation is mandatory even for a single lift.

## Common Build state machine

| State | Authoritative state | Allowed action / failure handling |
|---|---|---|
| PlanReady | Prior built revision; visible proposal | Edit/cancel plan; request Build with stable operation ID and expected revisions |
| PauseRequested | Prior built revision; simulation may still acknowledge last coherent work | No duplicate Build; wait for real host barrier, not a UI label |
| PausedValidated | Paused; validated current dependencies/inputs | Reject stale/malformed/invalid selected closure and retain proposal |
| CanonicalStaging | New graph/grading prepared but not published | Cancellation/failure drops staging, preserves prior built state and proposal |
| CanonicalCommitted | Exactly one new canonical revision published | Operation is applied once; postcommit cancel cannot claim it never happened |
| DerivedSync | Rendering/query/collision-if-used/index projections updating | No Play, new built mutations or normal Save; publish only coherent identified inspection |
| PausedReady | All required representations acknowledge same revision | Inspect/adjust approved controls; manual Save and user-requested Play allowed |
| PausedRecovery | Canonical commit succeeded; a required derived update failed | Rebuild from that revision, never rerun Build; preserve durable old save; retry or exit warning |

Operation results are idempotent within the relevant session/retry window. Bound retained operation records without discarding IDs while a completion could still arrive. A stale session callback cannot commit into a different resort. Multi-item blueprint grouping is now approved. A selected build commits its visibly confirmed required canonical dependencies or none; unsupported building entries cannot be silently omitted. Build selection details are the engineering UX default, not a new event-sourcing system. Explicit plan persistence itself is approved and defined in BLUEPRINT_LIBRARY.md. Do not partially apply successful children and discard a failed plan silently.

## Queries, meshes and in-flight data

Canonical grade data, visible mesh, analytical height query, optional collision body, graph, spatial index and hit registry carry revision/generation. Any mismatch affecting interaction blocks readiness. Own heightfield query is permitted, but choosing it does not remove the need for visible/query consistency. No plan/dot callback carries authority merely because its Actor survived.

Game-thread owner applies UObject/component updates after checking immutable result identity. Worker code must not hold raw live UObject pointers or mutate assets. Instance slots and Actor pointers are not EntityIds. Rebuild/reload preserves canonical IDs and clears stale view mappings. Terrain LOD/streaming only affects representation, not route membership.

F3 now requires built Open/Closed flags with initially Closed construction. Structural topology includes both open and closed elements; routing eligibility excludes new entry into closed ones. Render visibility is separate. Operating changes use the application pause/revision barrier and leave the game paused for manual Play. Engineering default: existing travelers retain the geometry/version of their journey; deny a closure with no safe completion/exit, and deny deletion while journeys, queues or other canonical anchors still reference it. Queue re-evaluation must remain deterministic and cannot silently delete guests. No teleportation, forced evacuation, refund or extra management system is inferred. OP01–03 demonstrate open validation, closed-new-entry rules, preserved completion and rejection of unsafe closure/removal. A graph edit never retroactively changes earned ticket revenue.

## Undo/redo safety

Draft gesture undo can remove the last point or restore that plan edit according to focused tool ownership. Text input undo stays with text input. Committed design commands use ONE cross-tool last-in-first-out history. Each command includes linked topology, parameters and grade effects together. New commit clears redo. Load Game starts an empty committed history. Load Blueprint replaces only working-plan state/history after dirty-plan resolution; it must not clear the built history or alter simulation state. A simulation-progress boundary seals prior reversible history; subsequent delete/close is a current-state command.

Arbitrary selective undo of an old before-image is rejected. Two overlapping grades must be undone in reverse order, or a future explicit dependency/replay design is required. Preview histories must also not overwrite later independent changes silently. Shared mutable cells in two proposals require revisioned revalidation before commit. Record caps and memory accounting for history; a large grade cannot allocate unlimited terrain before-images.

Runtime undo is an application feature. Do not depend on UnrealEd `FScopedTransaction`/editor transaction buffers or editor-only tool graphs in the packaged player. Saved current state plus bounded reversible commands is sufficient; no mandatory durable event-sourced database.

## Focused tests

Use BLD01–08 and OP01–03 from the canonical test catalog; pair independent save/load behavior with BP01–08 and IO07. Definitions below are generated from that catalog, not maintained as a second set of meanings.

<!-- TEST_DEFINITIONS_START -->
- **BLD01** — Proposed first lift visible/costed but absent from live graph. **NOT_EXECUTED** (CURRENT).
- **BLD02** — Build operation is idempotent, precommit failure retains plan, success yields one canonical revision. **NOT_EXECUTED** (CURRENT).
- **BLD03** — Trail holes/reversal/splits/junctions and approved pipe nodes have valid topology. **NOT_EXECUTED** (CURRENT).
- **BLD04** — Visual/picking/index callbacks use stable IDs/revisions; deleted/reused view cannot mutate another entity. **NOT_EXECUTED** (CURRENT).
- **BLD05** — Cross-tool committed LIFO undo includes overlapping graph and terrain changes. **NOT_EXECUTED** (CURRENT).
- **BLD06** — Redo invalidates on committed edits; Load Game resets committed history, Load Blueprint does not; simulation advancement seals historical undo. **NOT_EXECUTED** (CURRENT).
- **BLD07** — Fault before commit versus during derived sync has distinct recovery, no false rollback or early Play. **NOT_EXECUTED** (CURRENT).
- **BLD08** — Actual trail preview/grade/undo fits bounded resource envelope; new operations barred during recovery. **NOT_EXECUTED** (CURRENT).
- **OP01** — New infrastructure is Closed; Open validates declared connectivity/exit policy; node viewer separates built existence and operational eligibility. **NOT_EXECUTED** (CURRENT).
- **OP02** — Close prevents new entries, preserves in-flight geometry and safe completion, and rejects changes that would strand guests. **NOT_EXECUTED** (CURRENT).
- **OP03** — Deletion rejects live journey/queue/anchor references; operating changes stay coherently paused until user Play; no teleport/depopulation/revenue rewind. **NOT_EXECUTED** (CURRENT).
<!-- TEST_DEFINITIONS_END -->
