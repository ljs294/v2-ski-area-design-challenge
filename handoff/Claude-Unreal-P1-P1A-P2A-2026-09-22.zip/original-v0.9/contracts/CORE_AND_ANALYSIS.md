# Pure C++ core, application ownership and bounded analysis

## Enforced boundary

Use ordinary C++ data, explicit units/stable IDs, deterministic algorithms and versioned records. The pure source set has no Actor/UObject/reflection, world lookup, engine math/container, browser, UI, file, clock or asset dependency. External effects enter through minimal application ports. An isolated UE Core module registration/export shim is explicitly outside that source set. P0.3 compiles the same domain sources without any engine include paths, and in the actual UBT target. This is a small boundary, not a complete engine-first rewrite. [E04/E05]

Generated IDE projects are not maintained build truth. Pin compiler/C++ standard/runtime/linkage choices compatible with the actual Unreal version. A toolchain proposal is not a successful MSVC build. Where a selected third-party geometry library requires exceptions/RTTI/CRT choices that differ from defaults, isolate and test that adapter instead of changing the entire project silently. Use precise integer types and explicit overflow behavior for RNG/hash ports; TypeScript coercion behavior must not be assumed equivalent to signed C++ overflow.

Tests use the same sources, not parallel algorithms. Standalone Catch2 or a small equivalent harness is a candidate; Unreal LLT/Catch2 is optional if available without a needless engine source build. Unreal Automation/functional/cooked-player tests cover UObjects, packages, input and view lifecycle separately. A NullRHI/headless pass cannot certify GPU, browser or image quality. [E10/E11]

## Ownership and lifetimes

A single application session owns canonical ResortDocument and one simulation host. A session-scoped UGameInstanceSubsystem is a candidate lifetime adapter, not an extra database. Separate sessions/PIE worlds must not share mutable global simulation state. Destruction/recreation/streaming of visual Actors/components cannot change canonical people, IDs, graph connectivity or revenue.

All UObject/component/asset interaction is game-thread owned unless a specific documented thread-safe API is deliberately used. Worker inputs are plain immutable value snapshots. Completion is dispatched to the game thread and revalidates session/generation/revision and weak view identity before any application. Do not dereference raw view pointers on a worker. RAII owns buffers/jobs; shutdown cancels/fences work and joins/reclaims it through a bounded explicit policy. A future callback cannot resurrect a closed resort. Bounded queues and coalescing avoid unlimited catch-up and transient allocation.

Blueprint assets compose tested C++ UI/view interfaces and presentation defaults. They do not perform authoritative admission/financial loops, contain hidden guest arrays, or drive canonical time through Tick. Do not prohibit legitimate camera ticks, presentation interpolation or event delegates. Measure suspected hot paths rather than predicting failures from agent model names.

## Model/view/index consistency

Stable EntityId + session generation + source revision ties canonical records to view slots. Slot reuse in instancing and pooled widgets cannot reuse logical identity. Graph caches, hit registries and spatial indexes must either rebuild from canonical truth or apply one revisioned update. Late selections/callbacks reject mismatched IDs/revisions. Invalidation is independent of visibility. Removal of a view is not a model-delete command.

## Analysis scheduling contract

Every accepted cost/geometry/hydraulic calculation records: actual source/fixture, input units, trigger, relevant dependency revisions, cache key, budget, cancellation checkpoints, non-convergence/error state, and which result Build requires. Costly work starts on input change or an explicit analysis action—not camera frames. Coalesce superseded requests; retain an identified last valid result only as stale/read-only. Stale results cannot permit Build. Cheap bounded validation can stay synchronous. No blocking wait for a background solve on the game thread.

Lookup tables and approximations require an approved validity/error range. No live solver or structural load engine is added because the old source contains one. F4 controls hydraulic design sizing; operational snowmaking is excluded.

## Required tests

CORE01 — Pure same-source C++ compilation and forbidden include/dependency negative control; no UObject/Engine source set [NOT_EXECUTED].
CORE02 — Deliberately failed, empty, crashed and timed-out test runs cannot produce a pass receipt [NOT_EXECUTED].
CORE03 — UBT/UHT, native Development/Shipping cook/package and no editor module dependency in player [NOT_EXECUTED].
CORE04 — Domain events remain independent of Actor visibility, recreation, frame rate and view tick frequency [NOT_EXECUTED].
AN01 — Analysis is keyed to input/session/terrain/config revisions; stale results cannot commit [NOT_EXECUTED].
AN02 — Bounded convergence/CPU/allocation/cancellation; unknown/failed analysis is not a valid estimate [NOT_EXECUTED].

These are implementation acceptance requirements. None ran in Unreal while preparing this document.
