# Frozen evidence, runtime boundaries and independent review

The plan is not execution evidence. Distinguish PLANNED, EXECUTED_PASS, EXECUTED_FAIL, BLOCKED and INCONCLUSIVE, with actual artifact IDs and dates. Engine/product choice does not certify a runtime feature. Label domain-only, editor, Play-In-Editor, packaged Development/Test and Shipping results separately. No NullRHI test qualifies GPU visuals.

## Identity and source protection

Use base commit plus dirty diff/new-file hashes; no agent commit is required. Include code, build rules, `.uproject`/plugin versions, `.ini`, assets/sidecars, cook inputs, tool scripts, test fixtures and generated inputs. Record actual engine patch and compiler/SDK/backend. Output manifests identify executable/cooked assets separately from source. The selected test fixture includes immutable terrain/geometry/weather hash and scenario seed/workload.

Freeze source writers AND editor/asset/MCP mutations. Save only authorized dirty packages before hashing; editor memory can otherwise diverge from disk. Prefer frozen source snapshots for reproducible tests. Cache exclusions are explicit; do not exclude generated inputs needed to reproduce a build. Detect/deny writes throughout the window where practical, compare before/after and at review acceptance, and invalidate receipts on drift. A matching final hash alone is not proof that no transient mutation occurred.

## Independent roles and tool permissions

Non-author reviewers get the frozen input and relevant requirements/source references. They may not repair code or assets. Filesystem read-only mode is insufficient when another tool can command a writable editor/server; disable write-capable MCP and connector routes. Test experiments use separately approved scratch/output locations and executor ownership, followed by review of produced evidence.

Record requested/effective model, effort, session ID, permission/tool restrictions and what is unobservable. Unknown model routing is not verified routing. Separate sessions mean role separation, not statistical independence or a correctness guarantee. No agent executor was available in this planning session; independent acceptance is still required in Codex.

## Unreal-specific controls

Unreal MCP/remote-control/editor Python are development-only policy choices; a shipping audit must prove no automation listener or unauthorized tool endpoint. Never assume a plugin cannot ship solely because it was used inside the editor. Content license/runtime dependencies and untrusted external package paths are reviewed separately.

Serialize editor operations and asset writers. Review scripts refuse to clobber unowned generated assets. Structural Blueprint/C++ reflection/module changes require a qualified rebuild/restart, not only Live Coding. An asset mutation has a property/relationship diff, not only a changed hash. Keep large fixtures and installed runtimes out of ordinary source control.

## Required receipts

SEC01 — Source/editor/asset freeze before build/review; mutation causes invalidation, including untracked and binary inputs [NOT_EXECUTED].
SEC02 — Actual independent reviewer cannot write via filesystem, GitHub, browser or editor/MCP tools [NOT_EXECUTED].
SEC03 — Owned binary asset automation is bounded, repeatable and does not overwrite unrelated dirty/manual changes [NOT_EXECUTED].
SEC04 — Browser origin/message/path validation rejects forged, stale and oversized messages [NOT_EXECUTED].
SEC05 — Shipping player has no unexpected MCP/editor/dev/debug listener or write bridge [NOT_EXECUTED].

A deliberate negative control is a small known failure used to prove the gate rejects failure. It must not mutate real user data, install software, expose services or exercise unapproved privileges.
