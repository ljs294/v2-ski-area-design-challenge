# Native preparation, offline content and manual-save contract

## Preparation ownership and stages

A single preparation operation owner coordinates request identity and cancellation. The browser selector owns only a bounded boundary/options proposal. A packaged local helper or native importer owns acquisition/derive/storage through narrow adapters. Neither owns a game clock. One integration owner is accountable for the full pipeline.

States: Selected -> Validating -> Acquiring -> Decoding -> Deriving -> WritingStaging -> Verifying -> Activating -> Installed. Failed/Cancelled are explicit outcomes. Each progress record carries operation generation, phase, measurable completed/total units when known, elapsed time, and retry/stall detail. Do not fabricate percent/ETA where total work is unknown. Cancellation invalidates late provider/worker results and releases operation-owned resources. Reusing a completed immutable download is distinct from accepting a stale activation result.

P0 extraction inventory identifies all old browser worker, cover sampling, GeoTIFF, vector/provider, storage/IPC and package validation dependencies. Port adapters without retaining the old game. Unreal editor Python does not supply player Python; bundle an explicitly approved helper/runtime or implement that operation natively. No hidden developer server, editor or source tree on the player machine. [E18]

Required content failure blocks installation. Missing optional imagery/context is visible and requires a stated product fallback; no invented source terrain/weather. Validate returned extents rather than requested bounds alone. Describe coverage differences and source resolution; North America is preferred, lower 48 may be the initially guaranteed lane per Q19. Provider tests use saved legal responses except for separately labeled small real acquisition.

## Portable terrain manifest

Minimum fields: schema, immutable content ID/hash, source/provider and request/date, actual bounds, horizontal frame/transform and vertical datum or unknown, local origin, dimensions/spacing/row orientation, cell/vertex convention, elevations/units, nodata, sample encoding/endian, tile and normal-neighbor rules, resampling provenance, each asset's type/length/hash, required/optional status, attribution/redistribution constraints and optional weather binding/timezone. Non-executable file paths are relative to the package root and cannot escape it.

File lengths/dimensions/products are checked for overflow BEFORE allocation/decompression. Limit texture/DEM dimensions, tile and vertex/index counts, decompressed bytes and total staging size. Reject NaN/Infinity in accepted geometric state, broken checksums, duplicate conflicting tile identities and unsupported versions. Verify hashes before activation. Content-addressed IDs do not certify trusted provenance; still validate format and source terms.

Canonical base terrain is immutable. A design references that content and stores grading deltas separately. Do not write new data into shared base packages or silently resolve a missing hash to a different mountain. Cache derived files by generator version + input hash + renderer-relevant settings; stale generated content is not reusable merely because a filename matches.

## Unreal cook boundary

Ship engine assets such as material parents, shader permutations, icons/UI, sky assets and any approved decoration as cooked content with explicit references. Terrain heights/cover/raw images selected later are application data decoded through the runtime path. Do not attempt to load arbitrary uncooked `.uasset` assets from a downloaded package. No runtime compilation of material graphs or dependence on cook-on-the-fly infrastructure. [E15]

The helper bundle, browser-local resources and runtime DLLs must be intentionally staged, not accidentally found on the developer PATH. Record artifact hashes, versions and licenses. Unreal cooking/content stripping must not remove assets accessed only through approved identifiers. Verify a clean packaged player with no editor installed and no development source paths reachable.

## Native design saves

Manual Save is in scope; autosave scheduling is not. Store stable IDs, canonical coordinates/units, built document revision, immutable content references, grading/cover deltas, built operating flags and view settings; **exclude working construction plans**, then the selected simulation checkpoint when implemented. Version the design schema separately from renderer caches and reference packages. Do not serialize raw UObject pointers, engine instance indices, Actor hierarchy or GPU state as authority.

Save Game captures only a coherent readiness-accepted built snapshot, never partial gestures or unsaved proposals. Separate explicit Save Blueprint/Load Blueprint behavior is in [BLUEPRINT_LIBRARY.md](BLUEPRINT_LIBRARY.md). Warn about dirty proposals; no implicit plan persistence or automatic restore of a saved plan. Restores pause. Generation commit: stage assets -> flush/check -> stage manifest -> commit platform-appropriate replacement -> preserve prior valid generation. Treat disk-full, access-denied, interrupted write and corrupt new manifest as failures that leave previous save intact. A save is successful only after its referenced assets are durable. Build is not an autosave.

Content cleanup considers game saves, explicitly saved blueprint generations, their active writes and active save/preparation operations, so it cannot delete a referenced package during commit. Loading failures distinguish missing content, invalid hash, bad format, newer unsupported schema and failed optional adapter. Never regenerate a replacement simulation to hide a broken authoritative checkpoint.

Shared-save export/cloud/old-save import are not added now. Keep paths relative and schemas documented to avoid needless future barriers. Save migrations from the first native design milestone are tested; undo history is session-local unless separately approved.

## Reopen and security checks

Use canonical IO01–08 and BP01–08 definitions. Scope-specific recipe/library validation supplements, not replaces, non-executable path/hash/dimension validation.

<!-- TEST_DEFINITIONS_START -->
- **IO01** — In-window browser runs actual MapLibre/WebGL in packaged player with correct cleanup. **NOT_EXECUTED** (CURRENT).
- **IO02** — Preparation cancellation/retry invalidates superseded work and preserves valid installed content. **NOT_EXECUTED** (CURRENT).
- **IO03** — Required provider failure blocks activation; optional data absence is explicitly declared. **NOT_EXECUTED** (CURRENT).
- **IO04** — Paths/lengths/dimension products/checksums/nonfinite values validated before allocations. **NOT_EXECUTED** (CURRENT).
- **IO05** — Portable manifest/native import and derived-cache input+generator versions agree. **NOT_EXECUTED** (CURRENT).
- **IO06** — New mountain prepared after executable build, activated, then reopened network-denied without editor/devserver. **NOT_EXECUTED** (CURRENT).
- **IO07** — Save Game built-only coherent generations, interrupted/full-disk recovery and paused restore; never implicitly persists working blueprints. **NOT_EXECUTED** (CURRENT).
- **IO08** — Cooked content/helper dependencies present; no uncooked uasset, editor-only API or developer PATH prerequisite. **NOT_EXECUTED** (CURRENT).
<!-- TEST_DEFINITIONS_END -->

No provider, game-save or packaged installation tests ran while preparing the plan.
