# Numerical weather backend and future Unreal effects — latest answer 5

## Approved product direction

Keep the existing numerical weather backend's behavior. Rewriting it in another language, including C++, is acceptable if needed. Actual in-game weather effects can be designed from scratch; dynamic clouds are a future feature. Permission to rewrite implementation is not permission to replace the numerical model with unrelated plausible outputs.

## P6.1 source identification is an engineering gate

The earlier inspection identified distinct gameplay and standalone Weather Model Lab paths. The new answer does not select either by filename. Sol scopes a read-only trace of entrypoints, call sites, providers, model versions and saved state in the intended repository baseline; Terra proposes the reference implementation with evidence and a small behavior comparison. Do not automatically pick the newest directory. If the paths materially disagree and source/use cannot identify the intended behavior, ask one focused question with concrete contrasting outputs at P6, not the same abstract questionnaire now.

Pin inputs, RNG algorithm/state, timestamp/timezone semantics, units, versioned configuration and outputs before a translation. Use exact checks for discrete state and justified tolerances for continuous values. Resume/checkpoint tests and time-boundary tests must be based on the same model. Language portability differences are documented; no promise of universal bitwise cross-platform floating-point equality. Do not postpone source characterization until after replacement code has defined its own expected outputs.

## One offline integration, not two authorities

Choose the simplest supported native/packaged/local-helper path after tracing. C++ is permitted but not mandatory. No second game clock, remote live provider, independent hidden numerical weather system or concurrent duplicate backend may advance the same game. If a helper is retained, it uses an explicitly bundled runtime and bounded protocol; engine editor tooling is not a player prerequisite. If prepared finite output is chosen, prove the required horizon and continuation semantics rather than truncating them silently.

P6 contains backend integration, data views and the approved numerical snow effects only. Its completion does not require a cinematic weather-effects subsystem. A new implementation of the numerical algorithms gets parity fixtures; a new implementation of cosmetic effects does not have to imitate the old renderer.

## Future visual effects

A future bounded task may render clouds, storms, precipitation, wind cues or other weather visuals from the accepted numerical read model. Only dynamic clouds are explicitly mentioned as a desired future example; other effects remain options, not a commissioned feature list. Cosmetic presets/effects cannot mutate numerical weather, snow totals, finances, route state, clocks or the authoritative RNG stream. Use separate cosmetic randomness when appropriate. Disabling or lowering visual quality must leave simulation/checkpoint outputs unchanged.

The current mountain proof retains static/artist-controlled clear, low-angle and overcast appearance presets. It is not a dynamic-cloud simulation. New visual-weather assets/renderer features receive their own performance and capability gate when authorized; no early purchase, voxel clouds, actor-per-particle system or generic effects framework is implied.

## Evidence

WEA01–WEA04 are backend integration obligations introduced at P6; WEA05 is a deferred future-effects isolation requirement. None was executed while revising this plan.

<!-- TEST_DEFINITIONS_START -->
- **WEA01** — Existing numerical backend identified through traced source and pinned behavior fixtures before helper/package integration or permitted language translation; preserve versions, seed, units and timezone identity. **NOT_EXECUTED** (CURRENT).
- **WEA02** — Host cancellation/checkpoint/restore/event order with one game-clock authority. **NOT_EXECUTED** (CURRENT).
- **WEA03** — Offline weather projection and near-boundary snow/UI tests without a default full season. **NOT_EXECUTED** (CURRENT).
- **WEA04** — Any backend language translation compares pinned source fixtures, discrete events, RNG/checkpoint/calendar behavior and declared continuous tolerances; no unapproved numerical model redesign. **NOT_EXECUTED** (CURRENT).
- **WEA05** — Future cosmetic weather/cloud effects consume read models and independent cosmetic randomness; quality toggles never alter authoritative weather, clocks, guest state or saves. **DEFERRED_BY_OWNER** (FUTURE_WEATHER_EFFECTS).
<!-- TEST_DEFINITIONS_END -->
