# Accepted individual authority, event-clock demo and basic service — P4.0

## Decisions now settled

F6A accepts genuinely individual low-population people, retaining separate business/movement concepts and familiar controls. Where the old aggregate/sample mappings are incompatible, the engineer must propose the smallest explicit timing interpretation and obtain approval **after a tiny understandable demonstration**. Do not re-ask the high-level individual-versus-sample question. Exact numeric mappings are not yet approved simply because that direction is accepted.

F6B explicitly defers weighted groups beyond the first operating milestone. Current release code uses one authoritative record per admitted active person, not weighted cohorts or decorative samples with hidden aggregate authority. Approximately 3,000 ACTIVE individuals is the starting target; neither a maximum daily attendance guarantee nor a certified throughput result.

F5 now accepts player-set daily arrivals, a fixed ticket price per operating day, once-per-actual-admission integer-cent revenue, and no demand response to price. Construction costs remain informational, with no balance, affordability gate or cash deduction. No unanswered F5 product direction blocks P4.0; engineer-owned boundary choices below must be specified and tested.

## Event-clock table before production host

Sol scopes one table, Terra implements the tiny fixture and a fresh Terra reviewer challenges it. Assign admissions, seat service, queue release, travel completion, run choice, opening/closing, departure, ticket recognition, pause/speed switch and day boundary a canonical clock/unit, conversion rule, tie-break order, checkpoint representation and visible interpretation. Later weather is identified separately, not added as a second advancing game clock. Keep the familiar preset controls only with explicit supported semantics.

The historical 40 macro seconds per real second versus 1 micro second at 1x would turn a naively mapped 600-micro-second journey into 24,000 macro seconds. This is an illustrative coupling check, not proof of a bug in the original aggregate/sample engine. The accepted replacement may require an explicitly revised interpretation. A single-person, short-queue and near-closing fixture must establish coherence before P4.1/P4.2. No full-season test or completed simulation is a P0/P1 prerequisite.

Owner approves the concrete change, not mathematics delegated as a questionnaire. A fixture result is not a general approval of all future clock tuning; save format/version identifies the chosen contract.

## Individual capacity and arrivals — current P4.3

Distinguish requested arrival events, people waiting outside admission, admitted active people, departed people and explicitly not-admitted events. Require requested = admitted + pending + not-admitted over a stated arrival window, and admitted = active + departed for its tracked population (account for any declared initial population). No admission or income is recognized for a pending request. No duplicate admission on queue retry or checkpoint reload.

The implementation must enforce active_count <= configured_cap and bound pending representation/storage. An active cap is not a daily-arrival cap. Candidate engineering policy: when full, retain a bounded deterministic arrival backlog with visible status; admit when capacity frees; at closing explicitly account for pending requests as unadmitted under the chosen policy. Select/freeze the exact policy at P4.0 within accepted F5 rather than silently clipping a user setting. Overflow remains visible and earns no revenue. Compact scheduling/count storage for people not yet admitted is not weighted on-mountain guest simulation; do not smuggle in a second simulation engine under that label.

Define arrival identity, intended day/price binding, FIFO/tie-breaking, closing policy and checkpoint semantics. Never turn a pending arrival from yesterday into today's duplicate ticket without an explicit policy. Large requested inputs are bounded before allocating per-person arrays. P4.3 tests cap+1, capacity release, duplicate retries, finite backlog, save/restore and a day boundary.

## Daily settings and ticket ledger — accepted direction; proposed boundary defaults

Expose a player-set arrival total for the operating day and a daily ticket price in explicit currency units; store price and revenue as integer cents. Price never changes requested demand in this scope. Arrival scheduling must be bounded and deterministic with an explicit profile/default, not dependent on display FPS.

Initial engineering defaults to freeze in P4.0: edit today's settings before opening; lock the active day's planned arrival total and price when that day starts; edits made after opening are clearly labeled for the next operating day. Pending requests accepted into the same day use that day's locked price. At closing, classify remaining pending requests as visibly unadmitted rather than charging them or silently moving them to tomorrow. These defaults are implementation recommendations, not a verbatim owner selection of re-entry semantics.

Start with one visit per person and no re-entry feature. One stable admission-event ID records the charge; duplicate retry, checkpoint restore, lift boarding, blueprint loading, reopening a lift and a delayed UI callback cannot charge again. Persist day identity, locked inputs, next-day settings, admission deduplication/checkpoint state and ledger coherently. Price validation rejects invalid/negative/overflowing monetary inputs and reports the error; no floating-point currency accumulation. Fixtures use explicit test prices, not an invented product default price.

## Host and numerical requirements

Use one mutating pure-C++ host, explicit deterministic RNG/seed/hash encoding and event order, integer cents, numerical tolerances and defined duration units. Unordered container iteration, Actor lifetime, visibility, time dilation, UMG state, render ticks and wall-time backlog must not decide events. The engine may schedule bounded work, but workers consume immutable/revisioned inputs and never dereference live UObjects.

Selected inspection, movement snapshots and aggregate display summaries are separate bounded read models. A summary is derived from the individual authority, not a competing guest engine. Dots interpolate valid routes without cutting across disconnected geometry. Frame schedules may differ while the same command sequence and simulated horizon produce the same promised discrete state.

## Operation, saving and current scope

Spawn/access node -> reachable open route/lift -> queue -> ride -> ski -> choose again -> complete visit. F3's approved Closed initial state and operating flags determine eligibility. In-flight closure/deletion rules are in CONSTRUCTION_AND_UNDO.md. Every blocked/missing exit condition is explicit; no teleporting, hidden depopulation or fake completion.

Manual Save Game captures a coherent checkpoint and restores paused. Save/Load Blueprint never changes the clocks, individual population, tickets or committed undo. Actual Build still requests an acknowledged pause, commits, synchronizes required derived state and leaves manual Play to the user.

No amenities, injuries, patrol, lodging, vehicles, price elasticity, full finance, physical snow or operational snowmaking is imported because the old implementation calls it. Use a clearly labeled static environment until P6.

## Weighted mode — FUTURE, not release acceptance

Preserve R08's future contract: partial seats/residual FIFO, non-dividing integer/rational weights, person-weighted waits, service credits, route-choice approximations, checkpoint state and day carryover. SIM05–07 are catalogued as DEFERRED_BY_OWNER, not passed and not mandatory in P4/P5. A later explicit scope change must reactivate them before weighted code is written. No speculative group-splitting platform now.

## Canonical test definitions

The JSON catalog is authoritative. This block is generated, preventing the former SIM08/SIM09 meanings from drifting between documents.

<!-- TEST_DEFINITIONS_START -->
- **SIM01** — Accepted F6 individual direction implemented only after owner-approved concrete event-clock demo with units/rates/order; no hidden aggregate authority. **NOT_EXECUTED** (CURRENT).
- **SIM02** — One person/one lift/one trail and short queue complete under every included preset. **NOT_EXECUTED** (CURRENT).
- **SIM03** — Day boundary, speed change, pause/cancel and save continuation preserve declared semantics. **NOT_EXECUTED** (CURRENT).
- **SIM04** — Admissions/active/departed/service/revenue conserved independently of rendered dots. **NOT_EXECUTED** (CURRENT).
- **SIM05** — Weighted group larger than seats uses declared partial-service/residual policy without wasted capacity or overbooking. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM06** — Non-dividing weights, waits and residual queue order match promised quantities of individual reference. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM07** — Partial-service save/restore and day carryover retain weights/residual credits. **DEFERRED_BY_OWNER** (FUTURE_WEIGHTED).
- **SIM08** — Building while running affects only built graph after coherent pause; in-flight journeys follow approved closure/removal policy. **NOT_EXECUTED** (CURRENT).
- **SIM09** — Player-set daily arrivals and fixed per-day ticket price recognize integer-cent revenue once on actual admission; estimates-only construction never changes cash and price does not change demand. **NOT_EXECUTED** (CURRENT).
- **SIM10** — Individual active-cap admission at cap and cap+1 is bounded and visible; pending arrivals are not guests, weights or earned tickets. **NOT_EXECUTED** (CURRENT).
- **SIM11** — Requested/admitted/pending/unadmitted and active/departed accounting survives retries, capacity release, day end and save/restore without hidden demand loss. **NOT_EXECUTED** (CURRENT).
- **SIM12** — Locked daily arrivals/price and next-day edits survive restore; pending/duplicate/re-entry-not-supported/day-boundary cases cannot double-charge or introduce price-demand feedback. **NOT_EXECUTED** (CURRENT).
<!-- TEST_DEFINITIONS_END -->
