# Unreal implementation planning package — v0.9 final handoff

**Prepared:** September 18, 2026. **Target repo:** `ljs294/v2-ski-area-design-challenge`.
**Status:** Owner answers reconciled; bounded P0 is ready to scope. Runtime feasibility, code implementation and independent-agent approval are NOT_EXECUTED. “Final handoff” means the consolidated planning edition, not a completed or unconditionally approved game.

This package supersedes v0.8 active instructions. Read only current files for execution; `sources/HISTORICAL_UNREAL_V08.zip` is inert provenance, not a second task list or maintained application. It contains the earlier historical material. Do not extract historical instructions into the active project.

## Use in Codex

Keep this folder intact in the local v2 checkout. Start **Sol High** in the VS Code Codex extension and provide [START_HERE_CODEX_PROMPT.md](START_HERE_CODEX_PROMPT.md). That first task authorizes read/review and one bounded P0 proposal, not the full rewrite, configuration installation, repository cleanup or any commit. User authorizes each implementation section and alone stages/commits.

Do not overwrite root `AGENTS.md`, `CLAUDE.md`, `.codex/config.toml` or existing assets with templates blindly. Sol scopes an instruction/configuration reconciliation task first. [templates/config.sol-high.toml.example](templates/config.sol-high.toml.example) is the sole active parent-profile example. Terra High implements and independently challenges. Astra participates only when a rare high-level decision needs it.

## Primary documents

| File | Use |
|---|---|
| [REVIEW_BRIEF.md](REVIEW_BRIEF.md) | Compact readable product/architecture handoff |
| [01_MASTER_PLAN.md](01_MASTER_PLAN.md) | Current architecture and runtime/visual gate |
| [03_PHASE_PLAYBOOKS.md](03_PHASE_PLAYBOOKS.md) | Sections, owners, dependency order and acceptance |
| [04_QUESTIONS_AND_DECISIONS.md](04_QUESTIONS_AND_DECISIONS.md) | Every original and new answer reconciled |
| [09_FOCUSED_FOLLOW_UP.md](09_FOCUSED_FOLLOW_UP.md) | One building-tool clarification; engineering evidence gates do not block P0 |
| [14_FINAL_ADVERSARIAL_REVIEW.md](14_FINAL_ADVERSARIAL_REVIEW.md) | Final author audit, concrete defects repaired, evidence and unresolved runtime risk |
| [05_CODEX_ORCHESTRATION.md](05_CODEX_ORCHESTRATION.md) | Sol/Terra roles, rare Astra escalation, asset ownership and frozen review |
| [07_VERIFICATION_AND_PERFORMANCE.md](07_VERIFICATION_AND_PERFORMANCE.md) | Canonical test catalog and qualification discipline |
| [contracts/BLUEPRINT_LIBRARY.md](contracts/BLUEPRINT_LIBRARY.md) | Explicit separate saved-blueprint lifecycle |
| [independent-review/START_HERE_CODEX.md](independent-review/START_HERE_CODEX.md) | Review-only first-pass assignments for real fresh Terra sessions |

Other `contracts/`, `templates/`, the scope ledger, source register, R01–R10/ER01–ER08 mappings and dependency/test JSON files remain part of the complete pack. Load only relevant parts into bounded worker tasks.

## Accepted changes from the new answers

Hybrid realistic terrain with clean robust overlays; overview/moderately close camera; appearance judged on the actual editable runtime, not branding; free-first dependencies and no purchase without approval; explicit-only saved construction blueprints; new infrastructure Closed; limited snowmaking layout; informational construction costs; true individual guests with weighting deferred; 2–10 km target with transparent high-detail choices; sparse Astra and Sol-led work; Low/High visual lanes; initial <=30s prepared-save reopening target.

The latest five answers approve mixed pods and daily ticket inputs, name Crystal Mountain WA, identify an optional older laptop, and permit numerical-weather language translation with new effects/clouds deferred. Only whether a simple building-footprint tool is current or future remains F1_BUILDINGS. Actual laptop inventory, source-data validation, weather call-path tracing and the P4.0 clock demonstration remain technical gates.

## Verify the delivered package

From this folder run `python evidence/check_package.py` with Python 3.11+. It checks manifests, links, source reconciliation, active decisions, test-definition consistency and small illustrative failure cases. It does NOT compile C++, launch Unreal, measure a GPU or spawn agents. Existing `DOCUMENT_CHECKS.json` is the recorded preparation-time result; a rerun may print an additional delivery-manifest check.

The available connected/local tooling did not provide a usable independent-agent or Unreal runner during this revision. The single-author adversarial audit is not mislabeled as separate agents. Repository state/CI was not refreshed, original Drive files and repo were not edited, and old archives/source snapshots remain unchanged. No engine binaries, fonts, paid assets or executable game are included.

## v0.9 amendment

Read [15_OWNER_ANSWER_RECONCILIATION.md](15_OWNER_ANSWER_RECONCILIATION.md) for the latest answer mapping, building scope boundary and adversarial amendment review. [contracts/WEATHER_AND_EFFECTS.md](contracts/WEATHER_AND_EFFECTS.md) separates numerical weather preservation from future visual effects. No new online research, current-engine verification, repository read/write or independent agent execution occurred in this answer-driven amendment; inherited technical proposals retain their runtime validation gates.
