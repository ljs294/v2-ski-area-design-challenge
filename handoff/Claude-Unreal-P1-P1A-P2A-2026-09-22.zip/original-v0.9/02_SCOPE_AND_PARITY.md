# Selected scope ledger — Unreal v0.9

The former full-parity ledger is superseded by Q1/Q18. Original source paths in historical references are starting points, not proof that everything is required. Status labels describe scope, not completion.

| ID | Capability | Scope and owner basis | Proposed delivery / qualification |
|---|---|---|---|
| S01 | Unreal-only Windows application | CURRENT; Q3, Q36 | P0 native bootstrap; no old-app maintenance |
| S02 | Same-window selection/preparation | CURRENT; Q5 | P1.4 host + P1.5/P1.6 preparation + P1.8 packaged end-to-end gate; fixture is not setup |
| S03 | Fixed resort boundary | CURRENT; Q6/F7 | Target 2–10 km per side; qualify footprint and quality together |
| S04 | High-quality real terrain, local content | CURRENT; Q19, Q20, Q23 | P1 with R07 measured residency/quality envelope; explicit coverage and resolution metadata |
| S05 | Terrain materials, camera, analysis overlays | CURRENT; Q20, Q27 | P1/P2; no modeled objects |
| S06 | Lift building/inspection/costs | CURRENT; Q1, Q17 | P2.1 first lift WITH proposal/built boundary and manual save/reopen (R03) |
| S07 | Trail building, nodes, paths, junctions | CURRENT; Q1 | P2 topology and construction |
| S08 | Node map AND node-map viewer | CURRENT; Q1 | P2 explicit interactive/debuggable graph view |
| S09 | Trail grading only | CURRENT; Q21 | P2.4 canonical/derived readiness and one cross-tool committed history (R04/R05) |
| S10 | Blueprint preview and cost while running | CURRENT; Q17 | P2.1 separation; P4.5 actual running integration; explicit Save Blueprint/Load Blueprint in P2.1; mixed trail-pod grouping accepted; building-tool timing is F1_BUILDINGS; F2 safety resolved |
| S11 | Build pauses, user resumes | CURRENT; Q17 | P2 common readiness state machine; P4.5 actual barrier/recovery; F3 Open/Closed accepted, initially Closed; safe transition tests OP01–03 |
| S12 | Basic manual save/load, paused restore | CURRENT; Q29 | P2 onward; save integrity retained |
| S13 | Snowmaking infrastructure design | EARLY PRIORITY; Q1 | P3; F4 accepted nodes/pipes/guns/existing-water sources and verified estimates only |
| S14 | Snow layer map | CURRENT VISUAL TARGET; Q13 | P3 display/data contract; initial data source identified honestly |
| S15 | Player-selected guest spawn/run choice | CURRENT; Q11 | P4 minimum operating loop |
| S16 | Dot guests, no carving/character art | CURRENT; Q9, Q27 | P1 rendering probe; P4 integrated |
| S17 | Individual guests; weighted busy days deferred | CURRENT INDIVIDUAL / FUTURE WEIGHTED; F6 | P4.0 concrete clock demo; P4.3 active-cap/pending-demand handling; no current weighted service |
| S18 | Macro/micro clocks | CURRENT; Q10 | F6 individual direction accepted; P4.0 owner-approved concrete mapping demo before P4.1; familiar dual-clock controls retained |
| S19 | Daily ticket revenue | CURRENT; Q16 | Player-set daily arrivals and fixed per-day ticket price accepted; test once-only admission at P4.4; no cash deductions or price elasticity |
| S20 | Native readable/scalable UI | CURRENT; Q26, Q30, Q31 | P1 proof; delivered with each tool; English only |
| S21 | Screenshots and clean trail map | CURRENT; Q32 | P2/P5; suppress transient UI and restore correctly |
| S22 | Detailed preparation status/ETA, fast reopen | CURRENT; Q24 | P1.5–P1.8 actual production pipeline/status; P2.5 accepted <=30s initial reopen target; F8 High preparation may be longer |
| S23 | Weather engine integration | LATER CORE; Q12 | P6 independent milestone; exact backend/runtime F10 |
| S24 | Natural weather-driven snow/wear completeness | NOT FULLY SPECIFIED; Q12/Q13 | Define with P6; old full-parity gate not inherited |
| S25 | Patrol/injuries, lodging, vehicles, amenities | FUTURE; Q11/Q16 | Not a current release gate |
| S26 | Payroll, power, fuel, debt, maintenance | FUTURE; Q16 | Do not expose invented readouts |
| S27 | Operational snowmaking/pumping/consumption | FUTURE; Q14 | No implicit operations engine in P3 |
| S28 | Grooming dispatch/redistribution | FUTURE; Q14 | No present implementation |
| S29 | Physical snow-depth geometry | FUTURE; Q13 | Keep numerical snow separate from earth |
| S30 | General landscaping, caves, tunnels | FUTURE/NOT REQUESTED; Q21 | Do not select a voxel engine for these |
| S31 | 3D chairs, buildings, characters, trees | EXCLUDED THIS EFFORT; Q9/Q27 | Terrain-only visual scope |
| S32 | Autosave | FUTURE; Q29 | Manual-save integrity is still required |
| S33 | Shareable saves | FUTURE; Q22 | IDs/schema permit later sharing; no exporter now |
| S34 | Land unlocking/expansion | FUTURE; Q6 | No dynamic boundary/online streaming now |
| S35 | Mods | FUTURE OPENNESS; Q34 | Data separation where useful; no scripting runtime |
| S36 | Multiplayer/cloud/accounts | EXCLUDED NOW; Q33/Q35 | Single-player local authority |
| S37 | Roads/buildings/dams/pond construction beyond selected needs | UNCONFIRMED | Do not carry over old P3 breadth; explicit approval required |
| S38 | Full-season/long-soak qualification | NOT DEFAULT; Q40 | Target boundary/retention tests instead |

A feature described as FUTURE is not secretly P5 acceptance work. “Later core” is not permission to block P2–P5 on its model host. Snowmaking design and snowmaking operations are distinct. Existing source can supply characterized calculations, but an agent may not expand scope simply because those functions are coupled in the old application.

## Evidence per selected feature

Record owner question, approved behavior, reference source/fixture (when relevant), intentional deviations, task ID, changed files, test artifacts, reviewer findings, and owner acceptance. Before the owner commits, freeze all writers and identify the full source state including untracked files, engine assets and configuration, compare before/after manifests, and link the build/test/read-only review receipt. R06/R10 prevent changed-input or self-repair approval. No agent-made commit is required.

## Retained external-review scope guard

No DX12-only release, hydraulic operating engine, catenary/load simulation, modeled towers/chairs, snowgrooming deformation, event-sourced state store, floating-origin engine or custom compute terrain is approved by review language. F4 does not commission pump layout or hydraulic **design** sizing; physical snow and new operational mechanics remain future work. Existing selected numerical design algorithms may be retained only with their own source trace/fixtures and scoped scheduling. A future need is not a current gate.

## Unreal-specific clarification

The explicit engine change supersedes all earlier engine/API selections. Runtime terrain import and grading still apply; do not replace them with a prebuilt-only map catalog. The inherited rule against an assumed custom-compute terrain rewrite does not forbid a bounded Unreal runtime tile candidate: that candidate must pass the combined editable/visual proof before adoption. Lumen/Nanite are not automatically available for that candidate. No environmental meshes or higher hardware minimum are authorized by the engine change. U1/U2/U3 specify intended appearance and quality acceptance, U4 addresses conditional dependency spending, and U5 provides a visual reference fixture.

Design blueprints mean construction plans in game data, NOT Unreal Blueprint scripting assets. A material/lighting art preset is not a simulated weather engine. Refer to current P0–P6 sections and current test IDs; historical engine tests do not qualify Unreal.

## Latest five-answer scope changes — v0.9

- Mixed construction blueprints are CURRENT: a saved pod may include lifts, trails, snowmaking and building plan records together. Keep S10 identity. Buildings in plan data do not imply modeled art or amenity mechanics; current footprint-placement delivery versus future tooling is F1_BUILDINGS.
- Player-set daily arrivals and a fixed per-day ticket price are ACCEPTED; no price-demand feedback, cash deductions or full economics. Daily locking/re-entry defaults are engineering-owned within that scope.
- Crystal Mountain, Washington is the selected visual reference, not a restriction of supported terrain selection or a promise of available one-meter data.
- The old laptop is an AVAILABLE_OPTIONAL_PROBE with unknown specifications, not a selected or certified minimum machine.
- Existing numerical weather behavior is retained, language translation is permitted, and new dynamic weather effects/clouds remain FUTURE. No future effect is a P0–P6 completion requirement.
