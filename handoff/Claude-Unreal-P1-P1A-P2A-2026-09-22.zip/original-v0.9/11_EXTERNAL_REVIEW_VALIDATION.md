# Prior external critique — Unreal translation of validated safeguards

The previous critique was about the prior-engine v0.5 plan; its supplied `[cite: 1, 2]` targets and reviewer execution identity were unavailable. It must not be retroactively described as an Unreal source audit. The underlying accepted safeguards survive; engine-specific claims are re-evaluated from current primary research.

| ID | Prior issue / disposition | Active Unreal treatment |
|---|---|---|
| ER01 | Scope/backend premises were overstated | No assumed operating hydraulics/catenaries/physical snow/extra modeled objects. DX12 is now a high-quality candidate because the engine/features changed, not a mandatory hardware promise. F12/U3 qualification governs actual modes. |
| ER02 | Scene-component state contamination was valid; pure boundary needed enforcement | Plain C++ pure sources with no UObject/Engine includes, separate same-source compile, isolated module shim and actual UBT/player checks. Actor/Subsystem can own host lifetime, not people/ledgers. |
| ER03 | Orphan graph/index/undo risk valid; mandatory event sourcing rejected | Stable IDs/revisions across Actors/components/indexes, common Build/readiness, cross-tool undo and portable snapshots. UnrealEd transactions are not the runtime undo mechanism. |
| ER04 | Finite precision real; automatic floating origin not justified | Canonical double ENU meters; explicit north/east/up centimeters adapter and local float buffers; LWC measured with actual shaders/queries; no implicit old-axis reuse or unqualified precision promise. |
| ER05 | Whole-world per-frame mutation risky; inevitable custom-compute requirement unsupported | New engine demands a real runtime mesh/terrain proof. Initial bounded Dynamic Mesh candidate is not final adoption. No universal compute/quadtree or runtime Nanite promise; localized edits and visual/editability must pass together. |
| ER06 | Unbounded analyses in active frames unsafe; workload assumptions unsupported | Changed-input/request-triggered revisioned analysis, cancellation/convergence/resource bounds; F4 design sizing only. No blanket lookup-table approximation or continuous solver scope. |
| ER07 | Agent drift needs mechanical checks; model/API blanket accusations rejected | UBT/module/include/asset/cook tests and negative controls, exclusive asset writers/frozen evidence; legitimate view Tick/BP composition allowed. No stale browser CI described as failed Unreal CI. |
| ER08 | Finish complete headless engine before terrain was rejected | P0 minimal core + native tools; P1 runtime terrain/visual/setup; P2 saved designer; P4.0 then selected simulation. Retained algorithms get fixtures before their translation, not a full legacy suite upfront. |

Sources E02–E07/E10–E19 describe relevant Unreal capabilities. The previous finding that built-in runtime terrain was directly available in the old engine is NOT carried over as proof for Landscape. Conversely Unreal's engine-level LWC is not a reason to abandon explicit source CRS/unit/handedness contracts.

The explicit Unreal selection is implemented in this revision. No engine-comparison vote or side-by-side production app is commissioned. The old archive is historical evidence, and no new independent reviewer executed in this environment.


## v0.9 reconciliation precedence

Use DECISION_STATUS.json and sources/OWNER_FINAL_ANSWERS.md. Mixed multi-item plans, revenue inputs and Crystal Mountain WA are accepted; the older laptop is an optional unqualified probe and weather translation is permitted. F1_BUILDINGS is the sole current product clarification. Laptop inventory, reference shots and weather source identification are implementation evidence tasks, not unanswered broad choices. All runtime proof and independent execution remain NOT_EXECUTED.
