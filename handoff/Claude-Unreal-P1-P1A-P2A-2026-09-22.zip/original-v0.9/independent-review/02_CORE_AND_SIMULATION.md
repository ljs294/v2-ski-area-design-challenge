# Reviewer assignment — Core, coordinates, clocks and people

Read START_HERE_CODEX.md first. Fresh Terra High, effective read-only access, no repairs.

Challenge pure C++ source and registration boundary; actor/Blueprint lifecycle and worker ownership must not become authority.

Check ENU meter to UE centimeter axes/winding/query tolerances and float conversion order.

Verify P4.0 precedes host/lifecycle; preserve F6 open coupling and weighted seats/residuals/waits/ledgers.

Review stale analysis/cancel/checkpoint and tiny-case tests without creating a full legacy engine requirement.

Return only actionable evidence-backed findings or stated remaining uncertainty. Do not use absence of runtime proof to claim an API is impossible; identify the exact scoped proof needed. Distinguish a handled gate from an unhandled contradiction.


## v0.9 focus

F6 direction is accepted: individual-only first, weighted mode future. Audit cap/day-arrival/price identity and the concrete mapping demo; do not demand a weighted engine in P4. Costs are estimates, remaining F5 arrivals policy is not silently approved.

## v0.9 challenge cases

Daily arrivals and fixed per-day price are approved; test once-only admission, price lock, retry and day-boundary cases, not a new finance model. Weather implementation may change language but numerical behavior remains the reference; new visual clouds are future and cannot own RNG/time or gate backend completion. Do not infer gameplay-versus-lab identity without tracing.
