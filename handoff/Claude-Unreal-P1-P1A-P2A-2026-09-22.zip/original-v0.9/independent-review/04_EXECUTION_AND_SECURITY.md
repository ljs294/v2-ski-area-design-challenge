# Reviewer assignment — Agent execution, asset/cook identity, performance and security

Read START_HERE_CODEX.md first. Fresh Terra High, effective read-only access, no repairs.

Verify readonly review also disables mutable Unreal MCP/HTTP/connector capabilities and shipping excludes automation listeners.

Challenge one-owner binary assets, dirty-editor saves, LiveCoding, frozen source/cook inputs and stale test receipts.

Inspect negative controls, zero-test/failing cook handling, cold shader/PSO hitches and entire frame timelines.

Confirm actual model/effort evidence and user-only commit rule; no automatic installs/global configuration or invented independent agents.

Return only actionable evidence-backed findings or stated remaining uncertainty. Do not use absence of runtime proof to claim an API is impossible; identify the exact scoped proof needed. Distinguish a handled gate from an unhandled contradiction.


## v0.9 focus

F11 now requires Sol High coordinating, Terra High implementation/adversarial, Astra exceptional only. Check no old always-Astra parent config, source/asset freeze and effective external-tool restrictions. Compare test definitions across catalog, contracts and phases; existence alone is insufficient.
