# Reviewer assignment — Runtime terrain, visual quality and product scope

Read START_HERE_CODEX.md first. Fresh Terra High, effective read-only access, no repairs.

Prove the reviewer distinguishes cooked Landscape/Mesh Terrain/Nanite demonstrations from player-created runtime terrain.

Challenge Dynamic Mesh capability/LOD/lighting limitations, combined appearance/editability test, tile/quality/memory and source data assumptions.

Verify same-window preparation, offline dependencies and no implicit restricted-map/higher-GPU/extra-asset acceptance.

Preserve original O/Q and open U/F decisions; cite exact engine docs and packet lines.

Return only actionable evidence-backed findings or stated remaining uncertainty. Do not use absence of runtime proof to claim an API is impossible; identify the exact scoped proof needed. Distinguish a handled gate from an unhandled contradiction.


## v0.9 focus

U1–U3/F7/F8 targets now accepted. U5 reference and physical low-end machine remain unspecified. Verify real editable terrain and overlays at the same renderer/profile, not screenshots from another path.

## v0.9 accepted inputs

Crystal Mountain WA is the named visual reference; no need to ask again. Verify actual data and camera proof, not assumed high-resolution coverage. Old laptop availability is not a verified specification or a mandatory minimum. New dynamic clouds/effects remain future scope; static atmosphere presets remain current.
