# Reviewer assignment — Construction, UI, saves and offline content

Read START_HERE_CODEX.md first. Fresh Terra High, effective read-only access, no repairs.

Challenge proposed/built nodes, idempotent commit versus query/render readiness and late callback handling.

Exercise overlapping grades/undo history, in-flight guests and stale graph/picking projection scenarios.

Check runtime UMG node UI, cooked assets versus package data, manual-save generation and previous-valid protection.

Review the complete fresh acquisition/native-activation story rather than an imported fixture alone.

Return only actionable evidence-backed findings or stated remaining uncertainty. Do not use absence of runtime proof to claim an API is impossible; identify the exact scoped proof needed. Distinguish a handled gate from an unhandled contradiction.


## v0.9 focus

Audit explicit Save Blueprint/Load Blueprint independent of Save Game, dirty/concurrent save revision behavior, stale anchors/content hashes, load-not-build and no committed-history reset. Audit Closed/Open/in-flight safety and metadata-only layer visibility.

## v0.9 challenge cases

Challenge mixed lift/trail/snowmaking/building record preservation and complete internal-ID remapping. Ask whether a selected Build can silently include dependencies, drop unsupported members, zero unknown costs, duplicate remaining links or mutate the saved source. Treat simple building-tool timing as open; do not automatically commission art/amenities. Verify direct answer precedence over inherited five-question blocks.
