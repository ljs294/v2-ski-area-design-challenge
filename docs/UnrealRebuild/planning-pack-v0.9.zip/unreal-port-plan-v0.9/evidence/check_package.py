#!/usr/bin/env python3
"""Read-only planning-package checks, Python 3.11+; no network, C++, Unreal or agent calls.
Run from any directory: python evidence/check_package.py
Optional --output PATH writes the requested report (and only that report).
These checks test documents/configuration and illustrative contracts, NOT game implementation.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, math, re, struct, sys, tomllib, zipfile
from pathlib import Path
from typing import Any
ROOT=Path(__file__).resolve().parents[1]
def read(path: str) -> str:return (ROOT/path).read_text(encoding='utf-8')
def load(path: str) -> Any:return json.loads(read(path))
def sha(data: bytes) -> str:return hashlib.sha256(data).hexdigest()
def block(ids: list[str],by: dict[str,Any]) -> str:
    return '\n'.join(f"- **{i}** — {by[i]['requirement']}. **{by[i]['status']}** ({by[i]['applicability']})." for i in ids)
def getblock(s: str) -> str:
    m=re.search(r'<!-- TEST_DEFINITIONS_START -->\n(.*?)\n<!-- TEST_DEFINITIONS_END -->',s,re.S)
    return m.group(1) if m else ''
def f32(v:float)->float:return struct.unpack('<f',struct.pack('<f',v))[0]
def spacing(v:float)->float:
    bits=struct.unpack('<I',struct.pack('<f',v))[0]
    return struct.unpack('<f',struct.pack('<I',bits+1))[0]-f32(v)

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path);args=parser.parse_args()
    results:list[dict[str,Any]]=[];numbers:dict[str,Any]={}
    def ck(name:str,passed:bool,detail:Any=None):results.append({'name':name,'passed':bool(passed),'detail':detail})
    required=['README.md','REVIEW_BRIEF.md','START_HERE_CODEX_PROMPT.md','01_MASTER_PLAN.md','02_SCOPE_AND_PARITY.md','03_PHASE_PLAYBOOKS.md','04_QUESTIONS_AND_DECISIONS.md','05_CODEX_ORCHESTRATION.md','06_ADVERSARIAL_REVIEW.md','07_VERIFICATION_AND_PERFORMANCE.md','08_SOURCES.md','09_FOCUSED_FOLLOW_UP.md','10_AUDIT_INTEGRATION.md','11_EXTERNAL_REVIEW_VALIDATION.md','12_UNREAL_DECISIONS.md','13_SELF_REVIEW.md','14_FINAL_ADVERSARIAL_REVIEW.md','DECISION_STATUS.json','TEST_CASES.json','SECTION_DEPENDENCIES.json','AUDIT_TRACEABILITY.json','FINAL_AUDIT_FINDINGS.json','evidence/PROVENANCE.json','contracts/BLUEPRINT_LIBRARY.md','contracts/WEATHER_AND_EFFECTS.md','15_OWNER_ANSWER_RECONCILIATION.md','contracts/SIMULATION_AUTHORITY.md','templates/AGENTS.md','templates/CLAUDE.md','templates/config.sol-high.toml.example','independent-review/START_HERE_CODEX.md']
    absent=[p for p in required if not (ROOT/p).is_file()];ck('required_active_files',not absent,absent)
    if absent:raise ValueError('Required files missing; remaining checks cannot run.')
    active=[p for p in ROOT.rglob('*.md') if 'sources' not in p.relative_to(ROOT).parts]
    bad=[];count=0
    for p in active:
        for dest in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text()):
            if '://' in dest or dest.startswith('#'):continue
            count+=1;q=p.parent/dest.split('#')[0]
            if not q.is_file():bad.append([str(p.relative_to(ROOT)),dest])
    ck('relative_document_links',not bad,{'checked':count,'errors':bad,'anchors_and_external_urls_not_tested':True})
    js=list(ROOT.rglob('*.json'));errors=[]
    for p in js:
        try:json.loads(p.read_text())
        except (ValueError,OSError) as e:errors.append([str(p),str(e)])
    ck('json_parse',not errors,{'files':len(js),'errors':errors})
    ts=[p for p in (ROOT/'templates').rglob('*') if p.name.endswith(('.toml','.toml.example'))];errors=[]
    for p in ts:
        try:tomllib.loads(p.read_text())
        except (ValueError,OSError) as e:errors.append([str(p),str(e)])
    ck('toml_parse_NOT_routing_or_permission_proof',not errors,{'files':len(ts),'errors':errors})
    prov=load('evidence/PROVENANCE.json');archive=ROOT/prov['input_archive']['path']
    ck('previous_archive_unchanged',sha(archive.read_bytes())==prov['input_archive']['sha256'])
    with zipfile.ZipFile(archive) as z:
        ck('historical_archive_CRC',z.testzip() is None)
        names=[n for n in z.namelist() if n.endswith('/sources/OWNER_RESPONSES.md')]
        ck('original_answers_match_previous_archive',len(names)==1 and z.read(names[0])==(ROOT/'sources/OWNER_RESPONSES.md').read_bytes())
    original=(ROOT/'sources/OWNER_RESPONSES.md').read_bytes()
    ck('original_answers_hash',sha(original)==prov['original_answers_sha256'])
    ck('original_forty_answer_blocks',len(re.findall(r'^## Q\d+\b',original.decode(),re.M))==40 and len(re.findall(r'^Answer:',original.decode(),re.M))==40)
    new=(ROOT/'sources/OWNER_FOLLOW_UP_RESPONSES.md').read_bytes()
    ck('followup_text_hash',sha(new)==prov['follow_up_text_sha256'])
    seen={};current=None
    for line in new.decode().splitlines():
        m=re.match(r'^(U\d+|F\d+)\s+[—–-]',line)
        if m:current=m[1]
        if line.startswith('Answer:') and current:seen[current]=line[len('Answer:'):].strip()
    ck('sixteen_followup_answers_exactly_preserved',len(seen)==16 and seen==load('sources/OWNER_FOLLOW_UP_ANSWERS.json'))
    dec=load('DECISION_STATUS.json');db={x['id']:x for x in dec['entries']}
    ck('eighteen_followup_ids_including_prior_F2_F9',set(db)=={*(f'U{i}' for i in range(1,6)),*(f'F{i}' for i in range(1,14))} and len(db)==len(dec['entries']))
    ck('reconciled_verbatim_answers_equal_source',all(db[k]['verbatim_answer']==v for k,v in seen.items()))
    qrows=re.findall(r'^\| (Q\d+) \|',read('04_QUESTIONS_AND_DECISIONS.md'),re.M)
    ck('forty_original_decisions_remain',len(qrows)==40 and set(qrows)=={f'Q{i}' for i in range(1,41)})
    scope=re.findall(r'^\| (S\d{2}) \|',read('02_SCOPE_AND_PARITY.md'),re.M)
    ck('all_38_scope_rows_retained',scope==[f'S{i:02}' for i in range(1,39)])
    openids={x['id'] for x in dec['open_inputs']}
    expected={'F1_BUILDINGS'}
    ck('only_building_tool_scope_question_remains',openids==expected)
    questions=re.findall(r'^## ((?:U|F)\d+_[A-Z]+)',read('09_FOCUSED_FOLLOW_UP.md'),re.M)
    ck('question_file_exactly_matches_missing_input_ids',len(questions)==1 and set(questions)==openids,questions)
    latest=load('sources/OWNER_FINAL_ANSWERS.json')
    expectedkeys={'F1_GROUPING','F5_REVENUE','U5_REFERENCE','F12_HARDWARE','F10_BACKEND'}
    ck('latest_five_answers_preserved',set(latest)==expectedkeys and len(latest)==5 and all(v in read('sources/OWNER_FINAL_ANSWERS.md') for v in latest.values()))
    ck('latest_answer_source_hashes',sha((ROOT/'sources/OWNER_FINAL_ANSWERS.md').read_bytes())==prov['final_answers_sha256'] and sha((ROOT/'sources/OWNER_FINAL_ANSWERS.json').read_bytes())==prov['final_answer_values_sha256'])
    ck('latest_answer_precedence_not_lost',all(db[k]['latest_answer']==latest[aid] for k,aid in [('F1','F1_GROUPING'),('F5','F5_REVENUE'),('U5','U5_REFERENCE'),('F12','F12_HARDWARE'),('F10','F10_BACKEND')]))
    ck('five_resolved_inputs_retained', {v['id'] for v in dec['resolved_inputs']}==expectedkeys)
    eg={v['id'] for v in dec['engineering_gates']}
    ck('hardware_and_weather_are_technical_gates', {'LAPTOP_INVENTORY','WEATHER_SOURCE_TRACE','CRYSTAL_REFERENCE_SHOTS','TICKET_BOUNDARY_POLICY'}<=eg)
    mainplan=read('01_MASTER_PLAN.md');bl=read('contracts/BLUEPRINT_LIBRARY.md')
    ck('explicit_blueprint_action_and_save_game_exclusion','normal Save Game excludes it' in mainplan and 'Save Game' in bl and 'Capture a coherent' in bl)
    ck('blueprint_load_non_authoritative','no build, clock change, ticket event' in mainplan and 'Load Blueprint never' in read('REVIEW_BRIEF.md'))
    ck('independent_blueprint_generations_and_dirty_revisions','expected-version' in bl and 'latest working revision remains dirty' in bl and 'prior plan and game save intact' in bl)
    ck('blueprint_bindings_and_references','Cross-resort copy/stamping is future scope' in bl and 'garbage collection' in bl and 'fresh working instance' in bl)
    ck('accepted_operations_and_estimates','New construction is Closed' in mainplan and 'Construction costs are estimates only' in mainplan and 'no safe completion/exit' in mainplan)
    ck('individual_direction_and_demo_not_silently_final','F6A selects genuinely individual' in mainplan and 'owner approval of any actual changed rates/semantics' in mainplan)
    ck('weighted_deferral_is_explicit','F6B explicitly defers weighted' in mainplan and 'DEFERRED_BY_OWNER' in read('03_PHASE_PLAYBOOKS.md'))
    cfgpaths=list((ROOT/'templates').glob('config.*.toml.example'))
    cfg=tomllib.loads(read('templates/config.sol-high.toml.example'))
    ck('single_active_Sol_parent_template',len(cfgpaths)==1 and cfg['model']=='gpt-5.6-sol' and cfg['model_reasoning_effort']=='high',[p.name for p in cfgpaths])
    ck('Terra_default_and_bounded_concurrency',cfg['agents']['default_subagent_model']=='gpt-5.6-terra' and cfg['agents']['default_subagent_reasoning_effort']=='high' and cfg['agents']['max_concurrent_threads_per_session']==3)
    rev=tomllib.loads(read('templates/codex-agents/terra_reviewer.toml'))
    ck('Terra_reviewer_readonly_request_external_paths',rev.get('sandbox_mode')=='read-only' and rev['model']=='gpt-5.6-terra' and 'MCP/HTTP/editor/connector' in rev['developer_instructions'])
    astra=tomllib.loads(read('templates/codex-agents/astra_owner.toml'))
    ck('Astra_only_exceptional_consultation','never routine parent' in astra['description'] and astra.get('sandbox_mode')=='read-only')
    ck('user_only_commit_and_canonical_CLAUDE','User owns staging' in read('templates/AGENTS.md') and 'No automatic next section' in read('templates/AGENTS.md') and read('templates/CLAUDE.md').strip()=='@AGENTS.md')
    ck('no_old_always_Astra_pending_policy',not any(re.search(r'F11 (?:still|determines whether|remains OPEN)|cadence awaits F11|Eleven F entries remain open',p.read_text()) for p in active if p.name!='CHANGELOG.md'))
    sections=load('SECTION_DEPENDENCIES.json')['sections'];sb={x['id']:x for x in sections}
    ck('section_ids_unique_all_predecessors_exist',len(sb)==len(sections) and all(p in sb for x in sections for p in x['predecessors']))
    visiting=set();done=set()
    def visit(n):
        if n in visiting:return False
        if n in done:return True
        visiting.add(n);ok=all(visit(p) for p in sb[n]['predecessors']);visiting.remove(n);done.add(n);return ok
    ck('phase_graph_acyclic',all(visit(n) for n in sb),len(sb))
    def ancestors(n):
        a=set(sb[n]['predecessors'])
        for p in tuple(a):a|=ancestors(p)
        return a
    ck('clock_demo_precedes_host_not_terrain','P4.0' in ancestors('P4.1') and 'P4.0' in ancestors('P4.2') and not any(p.startswith('P4') for p in ancestors('P1.1')))
    ck('multi_item_grouping_accepted_and_single_lift_unblocked',not sb['P2.1']['owner_gates'] and not sb['P2.3']['owner_gates'] and 'P2.1' in ancestors('P2.2') and db['F1']['status']=='ACCEPTED_MULTI_ITEM_EXPLICIT_SAVE')
    ck('only_known_missing_owner_gates',all(g in openids for x in sections for g in x['owner_gates']))
    play=read('03_PHASE_PLAYBOOKS.md');pids=set(re.findall(r'^\| (P\d\.\d) /',play,re.M))
    ck('phase_rows_match_machine_graph',pids==set(sb))
    ck('P4_3_is_required_cap_not_weighted',sb['P4.3']['conditional'] is None and sb['P4.3']['test_cases']==['SIM10','SIM11'] and 'P4.3' in ancestors('P4.6'))
    cases=load('TEST_CASES.json');by={x['id']:x for x in cases['cases']}
    ck('test_ids_unique_no_runtime_pass',len(by)==len(cases['cases']) and all(x['status'] in ('NOT_EXECUTED','DEFERRED_BY_OWNER') for x in cases['cases']),len(by))
    ck('weighted_test_dispositions',all(by[i]['status']=='DEFERRED_BY_OWNER' and by[i]['applicability']=='FUTURE_WEIGHTED' for i in ['SIM05','SIM06','SIM07']))
    missing=[]
    for p in active:
        for i in re.findall(r'\b(?:CORE|AN|TER|VIS|UI|IO|BLD|SIM|SEC|PERF|WEA|BP|OP)\d{2}\b',p.read_text()):
            if i not in by:missing.append([str(p.relative_to(ROOT)),i])
    ck('all_document_test_ids_defined',not missing,missing)
    ck('current_phase_tests_do_not_require_future_weighting',all(i in by and by[i]['applicability']!='FUTURE_WEIGHTED' for x in sections for i in x['test_cases']))
    bad=[]
    for file,ids in cases['generated_definition_blocks'].items():
        if getblock(read(file))!=block(ids,by):bad.append(file)
    ck('LOCAL_CANONICAL_DEFINITION_EQUALITY',not bad,{'blocks':len(cases['generated_definition_blocks']),'mismatched':bad})
    canonical=block(cases['generated_definition_blocks']['contracts/SIMULATION_AUTHORITY.md'],by)
    mutated=canonical.replace(by['SIM08']['requirement'],'A conflicting unrelated ticket rule',1)
    ck('LOCAL_MUTATED_DEFINITION_REJECTED',mutated!=canonical and canonical==getblock(read('contracts/SIMULATION_AUTHORITY.md')))
    # Phase test sets must match their leading canonical references; scoping rows specify only descriptions where no tests.
    bad=[]
    for x in sections:
        row=next((l for l in play.splitlines() if l.startswith('| '+x['id']+' /')),None)
        acc=row.split('|')[-2].strip() if row else ''
        prefix=acc.split(':')[0]
        actual=set(re.findall(r'\b(?:CORE|AN|TER|VIS|UI|IO|BLD|SIM|SEC|PERF|WEA|BP|OP)\d{2}\b',prefix)) if ':' in acc else set()
        if x['id']=='P0.4':actual=set() # explicitly inventory-only; later IO08 mention is not an early case gate
        if actual!=set(x['test_cases']):bad.append({'section':x['id'],'row_tests':sorted(actual),'json_tests':x['test_cases']})
    ck('phase_rows_match_test_case_sets',not bad,bad)
    trace=load('AUDIT_TRACEABILITY.json')
    ck('R01_R10_and_ER01_ER08_preserved',{x['id'] for x in trace['findings']}=={f'R{i:02}' for i in range(1,11)} and {x['id'] for x in trace['external_review']}=={f'ER{i:02}' for i in range(1,9)})
    ck('audit_targets_exist',all((ROOT/p).is_file() for x in trace['findings'] for p in x['files']))
    final=load('FINAL_AUDIT_FINDINGS.json')
    ck('seven_final_review_dispositions_present',len(final['findings'])==7 and all((ROOT/p).is_file() for x in final['findings'] for p in x['changes']))
    ck('no_independent_or_game_execution_inferred',not prov['independent_agents_executed'] and not prov['unreal_executed'] and not prov['cpp_game_tests_executed'] and all(x['runtime_status']=='NOT_EXECUTED' and x['independent_review_status']=='NOT_EXECUTED' for x in final['findings']))
    oldapi=[]
    for p in active:
        if p.name=='CHANGELOG.md':continue
        for pattern in [r'noEngineReferences',r'\.asmdef',r'SetHeightsDelayLOD',r'UnityEngine',r'\bMonoBehaviour\b',r'\bNUnit\b']:
            if re.search(pattern,p.read_text()):oldapi.append([str(p.relative_to(ROOT)),pattern])
    ck('no_active_old_engine_API_prescriptions',not oldapi,oldapi)
    terrain=read('contracts/RUNTIME_TERRAIN_AND_VISUALS.md')
    ck('same_runtime_editable_visual_gate_retained','SAME candidate' in terrain and 'Nanite/Lumen' in terrain and 'pre-cooked' in terrain)
    ev=read('contracts/EVIDENCE_AND_REVIEW.md')
    ck('source_asset_freeze_and_external_review_controls','MCP' in ev and 'dirty' in ev and 'shipping' in ev and 'transient mutation' in ev)
    # Illustrative state/numerical checks, not the planned C++ implementation.
    built={'lifts':['built-1'],'revision':1};working={'items':['proposed-2'],'revision':3};game_save={'built':copy.deepcopy(built)}
    library={'generation':1,'snapshot':copy.deepcopy(working)};working['items'].append('later-edit');working['revision']=4
    restored_game=copy.deepcopy(game_save);loaded_proposal=copy.deepcopy(library['snapshot']);before=copy.deepcopy(built)
    ck('illustrative_explicit_plan_save_boundary','working' not in game_save and loaded_proposal['items']==['proposed-2'] and restored_game['built']==before)
    snapshot_rev=library['snapshot']['revision'];dirty=working['revision']!=snapshot_rev
    expected_generation=1;actual_generation=2;stale_write_allowed=expected_generation==actual_generation
    ck('illustrative_save_race_and_dirty_version',dirty and not stale_write_allowed,{'saved_revision':snapshot_rev,'working_revision':working['revision'],'dirty':dirty,'stale_write_allowed':stale_write_allowed})
    ck('illustrative_load_plan_does_not_build',before==built and 'proposed-2' not in built['lifts'])
    cap=3000;active_people=2999;requested=2;admitted=min(cap-active_people,requested);pending=requested-admitted;price=10000;income=admitted*price
    numbers['individual_cap']={'cap':cap,'initial_active':active_people,'requested':requested,'admitted':admitted,'pending':pending,'income_cents':income}
    ck('illustrative_individual_cap_conservation',active_people+admitted==cap and requested==admitted+pending and income==price,numbers['individual_cap'])
    end_not_admitted=pending;pending=0
    ck('illustrative_day_end_no_vanishing_demand',requested==admitted+pending+end_not_admitted)
    origin=(7000000.,5000000.,1000.);point=(7000003.,5000004.,1002.);ue=((point[1]-origin[1])*100,(point[0]-origin[0])*100,(point[2]-origin[2])*100)
    back=(ue[1]/100+origin[0],ue[0]/100+origin[1],ue[2]/100+origin[2]);numbers['coordinates']={'ue_xyz_cm':ue,'roundtrip':back==point}
    ck('illustrative_UNREAL_axes_cm_roundtrip',ue==(400.,300.,200.) and back==point,numbers['coordinates'])
    ck('illustrative_float_spacing',spacing(500000.)==.03125,{'coordinate_cm':500000,'adjacent_spacing_mm':spacing(500000.)*10})
    ck('illustrative_subtract_before_float',f32(1e7+.01)-f32(1e7)==0 and abs(f32((1e7+.01)-1e7)-.01)<1e-8)
    ck('illustrative_terrain_order_of_magnitude',10001**2*4==400080004,{'samples':10001**2,'one_float32_channel_bytes':10001**2*4})
    intervals=[1000/60]*7080+[2000.];order=sorted(intervals);pct=lambda q:order[math.ceil(q*len(order))-1]
    old=pct(.95)<=33.3 and pct(.99)<=50 and sum(x>50 for x in intervals)/len(intervals)<.01
    numbers['stall']={'p95_ms':pct(.95),'p99_ms':pct(.99),'max_ms':max(intervals),'percentiles_pass':old,'with_250ms_backstop_pass':old and max(intervals)<=250}
    ck('illustrative_two_second_stall_rejected',old and not (max(intervals)<=250),numbers['stall'])
    history=[100,110];height=120;after_b=history.pop();after_a=history.pop()
    ck('illustrative_LIFO_overlap',after_b==110 and after_a==100)
    # Future service illustration preserved, explicitly not current required game logic.
    groups=[4,4];seats=6;served=0;residual=[]
    for g in groups:
        n=min(seats,g);served+=n;seats-=n
        if g>n:residual.append(g-n)
    ck('illustrative_future_weighted_case_retained_not_release_gate',served==6 and sum(residual)==2 and by['SIM05']['applicability']=='FUTURE_WEIGHTED')
    ck('mixed_pod_and_building_capability_policy', all(x in bl for x in ['building plan entries','one old-to-new proposal-ID map','Unsupported','Building capability']) and 'F1_BUILDINGS' in bl)
    ck('BP_grouping_current_and_tests_owned', all(by[i]['applicability']=='CURRENT' for i in ['BP08','BP09','BP10','BP11']) and {'BP08','BP09','BP10','BP11'}<=set(sb['P3.4']['test_cases']))
    ck('daily_input_policy_is_accepted',db['F5']['status']=='ACCEPTED' and 'price does not change demand' in by['SIM09']['requirement'] and 'SIM12' in sb['P4.4']['test_cases'])
    ck('named_reference_not_inferred_hardware',db['U5']['status']=='ACCEPTED_CRYSTAL_MOUNTAIN_WA' and db['F12']['status']=='LAPTOP_AVAILABLE_SPECS_UNVERIFIED' and 'Crystal Mountain' in terrain)
    weather=read('contracts/WEATHER_AND_EFFECTS.md')
    ck('weather_translation_preserves_behavior', 'Rewriting it in another language' in weather and 'Pin inputs' in weather and 'WEA04' in sb['P6.2']['test_cases'])
    ck('visual_weather_not_current_gate',by['WEA05']['status']=='DEFERRED_BY_OWNER' and by['WEA05']['applicability']=='FUTURE_WEATHER_EFFECTS' and not any('WEA05' in x['test_cases'] for x in sections))
    ck('all_engineering_gate_references_exist',all(g in eg for x in sections for g in x.get('engineering_gates',[])))
    # Mixed plan is deliberately synthetic: plain records, no game runtime implementation.
    pod={'n':{'kind':'node','refs':[]},'l':{'kind':'lift','refs':['n']},'t':{'kind':'trail','refs':['n']},'s':{'kind':'snowmaking','refs':['n']},'b':{'kind':'building','refs':[],'payload':{'label':'future building','footprint':[[0,0],[1,0],[1,1]]}}}
    saved=json.loads(json.dumps(pod));mapping={k:'fresh_'+k for k in saved}
    loaded={mapping[k]:{**v,'refs':[mapping[q] for q in v['refs']]} for k,v in saved.items()}
    ck('illustrative_mixed_pod_roundtrip_shared_links',set(v['kind'] for v in loaded.values())=={'node','lift','trail','snowmaking','building'} and loaded['fresh_l']['refs']==loaded['fresh_t']['refs']==['fresh_n'] and loaded['fresh_b']['payload']==pod['b']['payload'])
    def closure(ids,graph):
        done=set();pending=list(ids)
        while pending:
            k=pending.pop()
            if k in done:continue
            if k not in graph:raise ValueError('missing dependency')
            done.add(k);pending.extend(graph[k]['refs'])
        return done
    supported={'node','lift','trail','snowmaking'}
    all_set=closure(list(pod),pod);subset=closure(['t'],pod)
    ck('illustrative_unsupported_build_all_blocks_subset_valid',any(pod[k]['kind'] not in supported for k in all_set) and all(pod[k]['kind'] in supported for k in subset) and saved==pod)
    coupled=copy.deepcopy(pod);coupled['t']['refs'].append('b')
    ck('illustrative_unsupported_dependency_not_skipped','b' in closure(['t'],coupled) and any(coupled[k]['kind'] not in supported for k in closure(['t'],coupled)))
    remaining={'t':{'kind':'trail','refs':[{'kind':'proposal','id':'n'}]}};builtmap={'n':'built_n','l':'built_l'}
    for ref in remaining['t']['refs']:
        if ref['kind']=='proposal' and ref['id'] in builtmap:ref.update(kind='built_anchor',id=builtmap[ref['id']])
    ck('illustrative_selected_build_converts_remaining_links',remaining['t']['refs']==[{'kind':'built_anchor','id':'built_n'}] and saved==pod)
    locked_price=10000;next_price=12000;charged=set();ledger=0
    for admission_id in ['arrival-1','arrival-1','arrival-2']:
        if admission_id not in charged:charged.add(admission_id);ledger+=locked_price
    ck('illustrative_daily_price_duplicate_admission',ledger==20000 and next_price==12000 and len(charged)==2)
    amendment=load('AMENDMENT_AUDIT.json')
    ck('amendment_self_review_honest',not amendment['independent_agents_executed'] and not amendment['engine_or_game_tests_executed'] and len(amendment['findings'])==6 and all(v['runtime_status']=='NOT_EXECUTED' for v in amendment['findings']))
    # Detect superseded unanswered claims in active execution documents (historical reviews excluded).
    execution=['01_MASTER_PLAN.md','03_PHASE_PLAYBOOKS.md','04_QUESTIONS_AND_DECISIONS.md','REVIEW_BRIEF.md','README.md','templates/AGENTS.md','contracts/BLUEPRINT_LIBRARY.md','contracts/WEATHER_AND_EFFECTS.md','15_OWNER_ANSWER_RECONCILIATION.md','contracts/SIMULATION_AUTHORITY.md','contracts/RUNTIME_TERRAIN_AND_VISUALS.md']
    stale=[]
    for f in execution:
        for phrase in ['only five missing-input','grouping remains open','grouping still open','supplies no mountain name','names no mountain','daily arrivals/price policy unconfirmed','exact arrival/price policy awaits F5']:
            if phrase in read(f):stale.append([f,phrase])
    ck('no_superseded_answer_gates_in_execution_docs',not stale,stale)
    if (ROOT/'MANIFEST.json').exists():
        man=load('MANIFEST.json');errors=[]
        for e in man['files']:
            p=ROOT/e['path']
            if not p.is_file() or len(p.read_bytes())!=e['bytes'] or sha(p.read_bytes())!=e['sha256']:errors.append(e['path'])
        expectedpaths={e['path'] for e in man['files']}
        actualpaths={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
        ck('delivery_manifest_hashes_and_coverage',not errors and expectedpaths==actualpaths,{'files':len(expectedpaths),'bad_hashes':errors,'coverage_difference':sorted(expectedpaths^actualpaths)})
    out={'version':'0.9','method':'Executed local package/source/configuration checks and illustrative state/numerical examples only','check_count':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'engine_or_game_tests_executed':False,'independent_agents_executed':False,'checks':results,'illustrations':numbers,'not_verified':['Actual C++/UBT/UHT/cook/game behavior','Unreal runtime geometry/shader/collision/visual quality','Hardware frame times/memory/provider acquisition','Effective Codex routing or independent reviewer permissions','Unseen Drive changes or current repository/CI','All external URL freshness by this script']}
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2));return 1 if out['failed'] else 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
        print(f'PACKAGE CHECK ERROR: {exc}',file=sys.stderr);raise SystemExit(2)
